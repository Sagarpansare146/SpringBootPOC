package com.eagleSystem.eagleJob.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.eagleSystem.eagleJob.dao.SubAdminRepository;
import com.eagleSystem.eagleJob.entity.SubAdmin;
import com.eagleSystem.eagleJob.util.Coverter;
import com.eagleSystem.eagleJob.valueObject.CreateSubadmin;

public class SubAdminServiceImpl implements SubAdminService {
	
	@Autowired
	SubAdminRepository subAdminRepository;
	
	public boolean addSubAdmin(CreateSubadmin subadmin) {
		
		boolean flag = true;
		
		try {
			
		SubAdmin subAdmin = (new Coverter()).converSubAdmin(subadmin);
		
		subAdminRepository.save(subAdmin);
		}catch(Exception e) {
			e.printStackTrace();
			flag = false;
		} 
		
		return flag;
	}
}
