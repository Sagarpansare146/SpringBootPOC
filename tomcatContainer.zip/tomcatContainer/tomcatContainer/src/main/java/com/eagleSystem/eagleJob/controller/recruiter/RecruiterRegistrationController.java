package com.eagleSystem.eagleJob.controller.recruiter;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;

@Controller
public class RecruiterRegistrationController {

	@Autowired
	RecruiterService recruiterService; 
	
	public static final String REGISTRATION_MODEL = "request";
	
	@PostMapping(value = URLMapper.RECRUITER_REGISTRATION, produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jRegisterRecruiter(@RequestBody @ModelAttribute(REGISTRATION_MODEL)@Valid RecruiterRegistrationRequest request) {
		
		System.out.println(request);
		boolean flag = false;
		
		flag = recruiterService.regRecruiter(request);
		
		return flag;
	}
	
	@PostMapping(URLMapper.RECRUITER_REGISTRATION)
	public String registerRecruiter(@ModelAttribute(REGISTRATION_MODEL)@Valid RecruiterRegistrationRequest request, BindingResult result, Model model) {
		
		System.out.println(request);
		boolean flag = false;
		
		if(result.hasErrors()) {
			return ViewMapper.RECRUITER_REGISTRATION;
	    }
		
		boolean error = false;
		try {
			flag = jRegisterRecruiter(request);
		}catch(Throwable t) {
			t.printStackTrace();
			model.addAttribute("error", "error");
			error = true;
		}
		
		if(error) {
			return "error";
			
		}
	
		if (flag) {
			model.addAttribute("message", "success");
		return "redirect:"+ URLMapper.RECRUITER_POSTED_JOBS;
		}
		return "error";
	}
	
	
	@GetMapping(URLMapper.RECRUITER_REGISTRATION)
	public String registerForm(@ModelAttribute RecruiterRegistrationRequest request, Model model) {
		
		System.out.println("rec_reg");
		model.addAttribute(REGISTRATION_MODEL, new RecruiterRegistrationRequest());
		return ViewMapper.RECRUITER_REGISTRATION;
	}
	
}
