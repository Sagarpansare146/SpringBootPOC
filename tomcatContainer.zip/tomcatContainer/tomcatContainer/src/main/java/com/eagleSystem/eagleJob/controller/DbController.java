package com.eagleSystem.eagleJob.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.eagleSystem.eagleJob.util.DbBackupUtil;

@Controller
public class DbController {

	@Autowired
	DbBackupUtil backupUtil;
	
	
	@RequestMapping(value = "/getBackup", produces = "application/zip", method = RequestMethod.GET)
	public void downloadResume(HttpServletRequest request, HttpServletResponse response) throws IOException {

		Map<String, Object> map;
		response.setContentType("application/zip");
		response.setStatus(HttpServletResponse.SC_OK);
	
		try {

			map = backupUtil.backup();

	//	response.addHeader("Content-Disposition", "attachment; filename=\"" + map.get("fileName") + ".zip\"");
			
		
			OutputStream fos = response.getOutputStream();
		
				File fileToZip = new File((String) map.get("file"));
				if (!(fileToZip.exists())) {
					System.out.println("file not found");
				}

				FileInputStream fis = new FileInputStream(fileToZip);
				
				System.out.println(fileToZip.getName());
				
				try {
				byte[] bytes = new byte[8096];
				int length;
				while ((length = fis.read(bytes)) >= 0) {
					fos.write(bytes, 0, length);
				}
				
				fis.close();
		
				fos.close();

			/*
			 * } else { System.out.println("Requested " + id + " file not found!!"); }
			 */

		} catch (IOException e) {
			System.out.println("Error:- " + e.getMessage());
		} catch (Exception e) {

			e.printStackTrace();
		}

	}catch (Exception e) {
		e.printStackTrace();
	}
	}
	
}
