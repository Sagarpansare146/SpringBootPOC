package com.eagleSystem.eagleJob.util;

import java.util.Date;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.bussinessObject.JobBO;
import com.eagleSystem.eagleJob.entity.JobPost;
import com.eagleSystem.eagleJob.valueObject.JobPostRequest;
import com.eagleSystem.eagleJob.valueObject.ListJobRequest;
import com.eagleSystem.eagleJob.valueObject.SingleJobRequest;

@Component
public class JobBOPrepareUtil {

	public JobBO prepareJobBO(JobPostRequest request) {
				
		JobBO jobBO = new JobBO();
		
		if(!(request.getPostId() == null)) 
		jobBO.setPostId(request.getPostId());
		jobBO.setCompanyName(request.getCompanyName());
		jobBO.setCompanyEmail(request.getCompanyEmail());
//		jobBO.setCompanyType(request.getCompanyType());
		jobBO.setCity(request.getCity());
		jobBO.setState(request.getState());
		jobBO.setCompanyWebsite(request.getCompanyWebsite());
		jobBO.setContactNumber(request.getContactNumber());
		jobBO.setCompanyAddress(request.getCompanyAddress());
		jobBO.setContactPerson(request.getContactPerson());
		jobBO.setJobCategory(request.getJobCategory());
		jobBO.setExperienceFrom(request.getExperienceFrom());
		jobBO.setExperienceTo(request.getExperienceTo());
		jobBO.setFunctionalArea(request.getFunctionalArea());
		jobBO.setJobDetail(request.getJobDetail());
		jobBO.setJobProfile(request.getJobProfile());
		jobBO.setJobType(request.getJobType());
		jobBO.setLocation(request.getLocation());
		
//		List<String> skill = Arrays.asList(request.getKeySkill().split("\\s*,\\s*"));
		
//		jobBO.setKeySkill((String[]) skill.toArray());
		jobBO.setKeySkill(request.getKeySkill());
	
		jobBO.setWalkinStartDate(request.getWalkinStartDate());
		jobBO.setWalkinEndDate(request.getWalkinEndDate());
		jobBO.setSalary(request.getSalary());
		
		jobBO.setStatus("ACTIVE");
		jobBO.setDeleted(false);
		jobBO.setPostedOn(new Date());
		
		return jobBO;
		
	}
	
	
	public JobPostRequest getJobPost(JobBO jobBO) {
		
		JobPostRequest request = new JobPostRequest();
//		String keySkill = "";
		
		if(!(jobBO.getPostId() == null)) 
		request.setPostId(jobBO.getPostId());
		request.setCompanyName(jobBO.getCompanyName());
		request.setCompanyEmail(jobBO.getCompanyEmail());
//		request.setCompanyType(jobBO.getCompanyType());
		request.setCompanyWebsite(jobBO.getCompanyWebsite());
		request.setContactNumber(jobBO.getContactNumber());
		request.setContactPerson(jobBO.getContactPerson());
		request.setExperienceFrom(jobBO.getExperienceFrom());
		request.setExperienceTo(jobBO.getExperienceTo());
		request.setFunctionalArea(jobBO.getFunctionalArea());
		request.setJobDetail(jobBO.getJobDetail());
		request.setJobProfile(jobBO.getJobProfile());
		request.setJobType(jobBO.getJobType());
		
/*		for (String ks : jobBO.getKeySkill()) {
			keySkill = keySkill + ks;
		}
*/		
		request.setLocation(jobBO.getLocation());
		request.setKeySkill(jobBO.getKeySkill());
		request.setCompanyAddress(jobBO.getCompanyAddress());
		request.setWalkinStartDate(jobBO.getWalkinStartDate());
		request.setWalkinEndDate(jobBO.getWalkinEndDate());
		request.setSalary(jobBO.getSalary());
		
		return request;
		
	}
	
	public JobBO prepareJobBO(JobPost jobPost) {
		
		JobBO jobBO = new JobBO();
		
		
		jobBO.setPostId(jobPost.getId());
		jobBO.setCompanyName(jobPost.getCompanyName());
		jobBO.setCompanyEmail(jobPost.getCompanyEmail());
//		jobBO.setCompanyType(jobPost.getCompanyType());
		jobBO.setCompanyWebsite(jobPost.getCompanyWebsite());
		jobBO.setContactNumber(jobPost.getContactNumber());
		jobBO.setCompanyAddress(jobPost.getCompanyAddress());
		jobBO.setContactPerson(jobPost.getContactPerson());
		jobBO.setExperienceFrom(jobPost.getExperienceFrom());
		jobBO.setExperienceTo(jobPost.getExperienceTo());
		jobBO.setFunctionalArea(jobPost.getFunctionalArea());
		jobBO.setJobDetail(jobPost.getJobDetail());
		jobBO.setJobProfile(jobPost.getJobProfile());
		jobBO.setJobType(jobPost.getJobType());		
		jobBO.setJobCategory(jobPost.getJobCategory());
		jobBO.setLocation(jobPost.getLocation());
		
//		List<String> skill = Arrays.asList(jobPost.getKeySkill().split("\\s*,\\s*"));
		
//		jobBO.setKeySkill((String[]) skill.toArray());
		jobBO.setKeySkill(jobPost.getKeySkill());
		
		
		jobBO.setState(jobPost.getState());
		jobBO.setCity(jobPost.getCity());
		
//		jobBO.setLocation(jobPost.getLocation());
		jobBO.setWalkinStartDate(jobPost.getWalkinStartDate());
		jobBO.setWalkinEndDate(jobPost.getWalkinEndDate());
		jobBO.setSalary(jobPost.getSalary());
		
		jobBO.setDeleted(jobPost.isDeleted());
		jobBO.setPostedOn(jobPost.getPostedOn());
		jobBO.setApplicationCount(jobPost.getApplicationCount());
		jobBO.setStatus(jobPost.getStatus());
		jobBO.setUpdatedOn(jobPost.getUpdatedOn());
		
		return jobBO;
				
	}
	
	public SingleJobRequest PrepareJobRequest(JobBO jobBO) {
		
		SingleJobRequest request = new SingleJobRequest();
//		String keySkill = "";
		
		if(!(jobBO.getPostId() == null)) 
		request.setPostId(jobBO.getPostId());
		request.setCompanyName(jobBO.getCompanyName());
		request.setCompanyEmail(jobBO.getCompanyEmail());
		request.setCompanyWebsite(jobBO.getCompanyWebsite());
		request.setContactNumber(jobBO.getContactNumber());
		request.setContactPerson(jobBO.getContactPerson());
		request.setExperienceFrom(jobBO.getExperienceFrom());
		request.setExperienceTo(jobBO.getExperienceTo());
		request.setJobCategory(jobBO.getJobCategory());
		request.setJobDetail(jobBO.getJobDetail());
		request.setJobProfile(jobBO.getJobProfile());
		request.setJobType(jobBO.getJobType());
		request.setLocation(jobBO.getLocation());
/*		for (String ks : jobBO.getKeySkill()) {
			keySkill = keySkill + ks;
		}
	*/	
		
		request.setKeySkill(jobBO.getKeySkill());
//		request.setLocation(jobBO.getLocation());
		request.setCompanyAddress(jobBO.getCompanyAddress());
		request.setWalkinStartDate(jobBO.getWalkinStartDate());
		request.setWalkinEndDate(jobBO.getWalkinEndDate());
		request.setDeleted(jobBO.isDeleted());
		request.setPostedOn(jobBO.getPostedOn());	
		request.setSalary(jobBO.getSalary());
		return request;
		
	}
	
	public ListJobRequest PrepareListJobRequest(JobBO jobBO) {
		
		ListJobRequest request = new ListJobRequest();
		
		if(!(jobBO.getPostId() == null)) 
		request.setPostId(jobBO.getPostId());
		request.setJobProfile(jobBO.getJobProfile());
		request.setPostedOn(jobBO.getPostedOn());
		request.setResponseCount(jobBO.getApplicationCount());
		request.setStatus(jobBO.getStatus());
		request.setLocation(jobBO.getLocation());
		return request;
				
	}
	
	
	
}
