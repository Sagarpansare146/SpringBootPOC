package com.eagleSystem.eagleJob.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;
import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;
import com.querydsl.core.types.Predicate;

@Component
public class ResumeUtil {

	private static final Logger LOGGER = Logger.getLogger("ResumeUtil");

	@Autowired
	NaukriExcelRepository naukriExcelRepository;

	public boolean filteredExpandZipFile(Path zipLocation, Path outputDirectory) throws Exception {

		java.util.function.Predicate<ZipEntry> p = (entry1 -> check((entry1.getName().substring(0, entry1.getName().indexOf("." + FilenameUtils.getExtension(entry1.getName())))).trim()));

		boolean flag = true;
		String op;

		try (ZipInputStream stream = new ZipInputStream(new FileInputStream(zipLocation.toFile()))) {

			LOGGER.info("Zip file: " + zipLocation.toFile().getName() + " has been opened");

			ZipEntry entry;
			while ((entry = stream.getNextEntry()) != null) {

			/*	String extn = ;

				String fName = ;
*/
				boolean b = p.test(entry);

				LOGGER.info("Matched file " + (entry.getName().substring(0, entry.getName().indexOf("." + FilenameUtils.getExtension(entry.getName())))));
				LOGGER.info("b " + b);			
				

				op = (b ? extractFileFromArchive(stream, entry.getName(), outputDirectory) : "Error");

				if (b && !op.equalsIgnoreCase("Error")) {

					try {
					save(entry.getName().substring(0, entry.getName().indexOf("." + FilenameUtils.getExtension(entry.getName()))), op);
				}catch (Exception e) {
					LOGGER.info("unable to save "+entry.getName().substring(0, entry.getName().indexOf("." + FilenameUtils.getExtension(entry.getName()))));
					LOGGER.log(Level.SEVERE, "while saving", e);
				}
				}

			}

		} catch (IOException ex) {
			LOGGER.log(Level.SEVERE, "Exception reading zip", ex);
			flag = false;
		}

		return flag;
	}

	private void save(String emailId, String resumePath) {

		//Predicate pred = QNaukriExcelRecord.naukriExcelRecord.emailID.contains(emailId);
		NaukriExcelRecord nauk = naukriExcelRepository.findByEmailIDContaining(emailId);
		System.out.println(nauk);
		nauk.setResumePath(resumePath);
		
		naukriExcelRepository.save(nauk);

	}

	private boolean check(String emailId) {
	//	Predicate pred = QNaukriExcelRecord.naukriExcelRecord.emailID.contains(emailId);
		
		NaukriExcelRecord nauk = naukriExcelRepository.findByEmailIDContaining(emailId);
		
		
		return (nauk != null && (nauk.getResumePath() == null || !nauk.getResumePath().equalsIgnoreCase("")) ? true : false );
	}

	private String extractFileFromArchive(ZipInputStream stream, String outputName, Path outputDirectory) {
		// build the path to the output file and then create the file
		String outpath = outputDirectory + "/" + outputName;
		try (FileOutputStream output = new FileOutputStream(outpath)) {

			System.out.println("file output process");
			// create a buffer to copy through
			byte[] buffer = new byte[2048];

			// now copy out of the zip archive until all bytes are copied
			int len;
			while ((len = stream.read(buffer)) > 0) {
				output.write(buffer, 0, len);
			}
		} catch (IOException e) {
			LOGGER.log(Level.SEVERE, "Exception writing file", e);
		}

		return outpath;
	}

	public String fileReader(MultipartFile file, String directory) {

		String fName = "";
		System.out.println(file.getSize() + "  " + file.isEmpty());
		String FileName = file.getOriginalFilename();
		System.out.println("FileName :" + file.getOriginalFilename());
		System.out.println(file.getName());

		String FullPath = directory;

		System.out.println(FileName);

		File dir = new File(FullPath);

		if (!dir.exists()) {
			dir.mkdirs();
		}

		File serveFile = new File(FullPath + File.separator + FileName);
		fName = serveFile.getAbsolutePath();
		System.out.println(serveFile);
		LOGGER.info("file name :" + serveFile);
		LOGGER.info("file path :" + fName);
		try (BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serveFile))) {
			// String ResumePath = "Resume" + File.separator +
			// userRegistrationRequest.getContactNumber();
			stream.write(file.getBytes());
			stream.flush();
			stream.close();
		} catch (IOException io) {
			io.printStackTrace();
		}

		return fName;
	}

	@Async
	public void upload(MultipartFile file) throws Exception {

		String filePath = "";
		Path outputDirectory = Paths.get("c:/BDM_Resume/zip");
		
		String directory = "c:" + File.separator + "BDM_test" + File.separator + "resumeZip";

		boolean ids = false;

		filePath = fileReader(file, directory);
		
		Path zipLocation = Paths.get(filePath);

	//	File file1 = new File(filePath);

	//	String inputFilename = file1.getName();

		/*
		 * switch (inputFilename.substring(inputFilename.lastIndexOf(".") + 1,
		 * inputFilename.length())) { case "zip": ids = zip(filePath); break; default:
		 * System.out.println("Please select valid \"Excel\" File\""); }
		 */

		ids = filteredExpandZipFile(zipLocation, outputDirectory);
		
	}

}
