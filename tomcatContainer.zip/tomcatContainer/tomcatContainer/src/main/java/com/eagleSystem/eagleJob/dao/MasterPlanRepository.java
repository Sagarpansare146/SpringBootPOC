package com.eagleSystem.eagleJob.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagleSystem.eagleJob.entity.MasterPlan;

public interface MasterPlanRepository extends JpaRepository<MasterPlan, Long> {

	
}
