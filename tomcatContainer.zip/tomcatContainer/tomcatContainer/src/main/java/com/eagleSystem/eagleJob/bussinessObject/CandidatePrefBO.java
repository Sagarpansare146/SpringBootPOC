package com.eagleSystem.eagleJob.bussinessObject;

public class CandidatePrefBO {

	private Long cpid;
	private String keySkill;
	private String jobType;
	private String jobCategory;
	private String functionalArea;
	private String topCities;
	private String resume;

	public CandidatePrefBO() {
		super();
	}

	public Long getCpid() {
		return cpid;
	}

	public void setCpid(Long cpid) {
		this.cpid = cpid;
	}

	public String getKeySkill() {
		return keySkill;
	}

	public void setKeySkill(String keySkill) {
		this.keySkill = keySkill;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getJobCategory() {
		return jobCategory;
	}

	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}

	public String getFunctionalArea() {
		return functionalArea;
	}

	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}

	public String getTopCities() {
		return topCities;
	}

	public void setTopCities(String topCities) {
		this.topCities = topCities;
	}

	public String getResume() {
		return resume;
	}

	public void setResume(String resume) {
		this.resume = resume;
	}

}
