package com.eagleSystem.eagleJob.aspect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.dao.RecruiterDownloadRecordsRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.entity.RecruiterDownloadRecords;

@Aspect
@Component
public class RecruiterResumeDownloadAspect {

	@Autowired
	RecruiterRepository recruiterRepository;

	@Autowired
	RecruiterDownloadRecordsRepository recruiterDownloadRecordsRepository;

	@Around("execution(* com.eagleSystem.eagleJob.service.bdm.BdmServiceImpl.recResumeNaukriJobPath(..))")
	public Object checkBeforeDownload(ProceedingJoinPoint pjp) throws Throwable {

		System.out.println("excel aspect");

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		Recruiter rec = recruiterRepository.findByUsername(auth.getName());

		// DbCustomerEntity dbCustomerEntity =
		// dbCustomerRepository.findByUsername(auth.getName());

		Object obj[] = pjp.getArgs();
		Long[] cadId = (Long[]) obj[0];

		/*
		 * Long limit = dbCustomerEntity.getResumeLimit(); Long oldDownloadedCount =
		 * dbCustomerEntity.getResumeDataUsed(); Long canDownloadCount = limit -
		 * oldDownloadedCount; Long count = (long) cadId.length;
		 */

		int limit = rec.getMasterPlan().getDatabaseExcelRecordsLimit();
		int oldDownloadedCount = recruiterDownloadRecordsRepository.findByRecruiter(auth.getName()).stream()
				.filter(e -> e.getDownloadResumeCount() != 0).mapToInt(e -> e.getDownloadResumeCount()).sum();
		int oldDownloadedCount1 = recruiterDownloadRecordsRepository.findByRecruiter(auth.getName()).stream()
				.filter(e -> e.getDownloadExcelCount() != 0).mapToInt(e -> e.getDownloadExcelCount()).sum();

		int canDownloadCount = limit - oldDownloadedCount;
		int count = cadId.length;
		List<Long> lcadId = new ArrayList<>();

		int downloadedCount = 0;

		if (canDownloadCount == 0 && oldDownloadedCount == limit) {
			throw new Exception("You reached your download Limit");
		} else if (canDownloadCount <= count) {

			lcadId = Arrays.stream(cadId).limit(canDownloadCount).collect(Collectors.toList());
			downloadedCount = lcadId.size();

		} else {
			downloadedCount = count;
		}

		
		Object ret = pjp.proceed();

		RecruiterDownloadRecords recruiterDownloadRecords = new RecruiterDownloadRecords();

		recruiterDownloadRecords.setRecruiter(auth.getName());
		recruiterDownloadRecords.setCurrentExcelCount(oldDownloadedCount1);
		recruiterDownloadRecords.setCurrentResumeCount(oldDownloadedCount + downloadedCount);
		recruiterDownloadRecords.setDownloadDate(new Date());
		recruiterDownloadRecords.setDownloadExcelCount(0);
		recruiterDownloadRecords.setDownloadResumeCount(downloadedCount);

		recruiterDownloadRecordsRepository.save(recruiterDownloadRecords);
		/*
		 * dbCustomerEntity.setResumeDataUsed(oldDownloadedCount + downloadedCount);
		 * 
		 * dbCustomerEntity = dbCustomerRepository.save(dbCustomerEntity);
		 * 
		 * CustomerDownloadRecords custRecord = new CustomerDownloadRecords();
		 * 
		 * custRecord.setCustomer(auth.getName());
		 * custRecord.setCurrentExcelCount(dbCustomerEntity.getExcelDataUsed());
		 * custRecord.setCurrentResumeCount(dbCustomerEntity.getResumeDataUsed());
		 * custRecord.setDownloadResumeCount(downloadedCount);
		 * custRecord.setDownloadDate(new Date());
		 * 
		 * customerDownloadRecordsRepository.save(custRecord);
		 */
		return ret;

	}

}
