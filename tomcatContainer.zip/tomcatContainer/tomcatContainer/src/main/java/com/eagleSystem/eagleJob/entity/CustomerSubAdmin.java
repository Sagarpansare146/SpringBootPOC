package com.eagleSystem.eagleJob.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Customer_BDM")
public class CustomerSubAdmin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long cid;
	private String subAdmin;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCid() {
		return cid;
	}
	public void setCid(Long cid) {
		this.cid = cid;
	}
	public String getSubAdmin() {
		return subAdmin;
	}
	public void setSubAdmin(String subAdmin) {
		this.subAdmin = subAdmin;
	}
	@Override
	public String toString() {
		return "CustomerSubAdmin [id=" + id + ", cid=" + cid + ", subAdmin=" + subAdmin + "]";
	}
	public CustomerSubAdmin(Long cid, String subAdmin) {
		super();
		this.cid = cid;
		this.subAdmin = subAdmin;
	}
	

}
