package com.eagleSystem.eagleJob.bussinessObject;

public class CandidateQualBO {

	private Long qid;
	private String degree;
	private String specilization;
	private String university;
	private Float percentage;
	private Integer passout;
	private int experience;
	private int month;

	public String getDegree() {
		return degree;
	}

	public Long getQid() {
		return qid;
	}

	public void setQid(Long qid) {
		this.qid = qid;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getSpecilization() {
		return specilization;
	}

	public void setSpecilization(String specilization) {
		this.specilization = specilization;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public Float getPercentage() {
		return percentage;
	}

	public void setPercentage(Float percentage) {
		this.percentage = percentage;
	}

	public Integer getPassout() {
		return passout;
	}

	public void setPassout(Integer passout) {
		this.passout = passout;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	@Override
	public String toString() {
		return "CandidateQualBO [qid=" + qid + ", degree=" + degree + ", specilization=" + specilization
				+ ", university=" + university + ", percentage=" + percentage + ", passout=" + passout + ", experience="
				+ experience + ", month=" + month + "]";
	}

}
