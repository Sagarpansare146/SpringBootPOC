package com.eagleSystem.eagleJob.controller.subAdmin;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.businessExcel.NaukriDownloadRecord;
import com.eagleSystem.eagleJob.dao.AccountRepository;
import com.eagleSystem.eagleJob.dao.DBCustomerRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.dao.SubAdminRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import com.eagleSystem.eagleJob.entity.SubAdmin;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.service.subAdmin.SubAdminServiceImpl;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.BdmAccount;
import com.eagleSystem.eagleJob.valueObject.FilterInput;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;
import com.eagleSystem.eagleJob.valueObject.SubadminList;

@Controller
public class SubAdminController {

	@Autowired
	RecruiterService recruiterService;
	
	

	@Autowired
	SubAdminServiceImpl subAdminServiceImpl;
	
	@Autowired
	AccountRepository accountRepository;

	@Autowired
	RecruiterRepository recruiterRepository;
	
	@Autowired
	SubAdminRepository subAdminRepository;
	
	@Autowired
	DBCustomerRepository dbCustomerRepository;
	
	@GetMapping("/subadminMonthlyReport")
	public String subadminMonthlyReport(@RequestParam("id") Long id, Model model) {
		model.addAttribute("id", id);
		model.addAttribute("data", accountRepository.findOne(id));
	
		return ViewMapper.SUBADMIN_SUBADMIN_MONTHLYREPORT;
	}
	
	@GetMapping("/subadminRecuiterAccount")
	public String subadminRecuiterAccount() {
		return ViewMapper.SUBADMIN_SUBADMIN_CREATEPOSTINGCUSTOMER;
	}
	
	@GetMapping("/subadminUpdateRec")
	public String subadminUpdateRecruiter(@RequestParam("id") Long id, Model model) {
		
		model.addAttribute("id", id);
		model.addAttribute("record", recruiterService.getRecruiterData(recruiterRepository.findOne(id).getUsername()));
		return ViewMapper.SUBADMIN_SUBADMIN_UPDATEPOSTINGACCOUNT;
	}
	
	@GetMapping("/subadminUpdateCustomer")
	public String subadminUpdateDbC(@RequestParam("id") Long id, Model model) {
		
	//	model.addAttribute("id", id);
		model.addAttribute("record", dbCustomerRepository.findOne(id));
		return ViewMapper.SUBADMIN_SUBADMIN_UPDATECUSTOMER;
	}
	
	@GetMapping("/subadminUpdateAccount")
	public String subadminUpdateAccount(@RequestParam("id") Long id, Model model) {
		
		model.addAttribute("id", id);
		model.addAttribute("record", accountRepository.findOne(id));
		return ViewMapper.SUBADMIN_SUBADMIN_UPDATEACCOUNT;
	}
	
  	@PostMapping(value = URLMapper.SUBADMIN_SUBADMIN_CREATECUSTOMER )
	public String registrationRecruiter(@ModelAttribute @Valid DbCustomerEntity request, Model model) {
		boolean flag = true;
		
		flag = jRegisterDbCustomer(request);
		if(!flag) {
			return "error";
		}
			
		return ViewMapper.SUBADMIN_SUBADMIN_INDEX;
	}
	
	@PostMapping(value = URLMapper.SUBADMIN_SUBADMIN_CREATECUSTOMER , produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jRegisterDbCustomer(@RequestBody @ModelAttribute @Valid DbCustomerEntity request) {
		
		boolean flag = true;
		
		try {
			flag = subAdminServiceImpl.createCustomer(request);
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		
		return flag;
	}
	
	@GetMapping(URLMapper.SUBADMIN_SUBADMIN_CREATECUSTOMER)
	public String subAdminCustReg(Model model) {
		
		model.addAttribute("request", new DbCustomerEntity());
		return ViewMapper.SUBADMIN_SUBADMIN_CREATECUSTOMER;
	}
	
	
	@CrossOrigin
	@GetMapping(value = "/SubAdminBasicProfile", produces = {"application/json"})
	public @ResponseBody SubadminList SubAdminBasicProfile() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		SubAdmin account = subAdminRepository.findByUsername(auth.getName());
		SubadminList subadminList = new SubadminList();
		
			subadminList.setLocation(account.getLocation());
		    subadminList.setName(account.getName());
				return subadminList;
			
	}
	
	@GetMapping(URLMapper.SUBADMIN_SUBADMIN_CREATEACCOUNT)
	public String subAdminRecReg(Model model) {
		
		model.addAttribute("request", new Account());
		return ViewMapper.SUBADMIN_SUBADMIN_CREATEACCOUNT;
	}

	
	@PostMapping(value = URLMapper.SUBADMIN_SUBADMIN_CREATEACCOUNT )
	public String registrationRecruiter(@ModelAttribute @Valid Account request) {
		boolean flag = true;
		
		System.out.println("welcome");
		
		flag = jRegisterRecruiter(request);
		if(!flag) {
			return "error";
		}
		
		return ViewMapper.SUBADMIN_SUBADMIN_CREATEACCOUNT;
	}
	
	
	@PostMapping(value = URLMapper.SUBADMIN_SUBADMIN_CREATEACCOUNT , produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jRegisterRecruiter(@RequestBody @ModelAttribute @Valid Account request) {
		
		boolean flag = false;
		
	try {	
		flag = subAdminServiceImpl.createAccount(request);
	}catch (Exception e) {
		e.printStackTrace();
	}
		return flag;
	}
	
	
}
