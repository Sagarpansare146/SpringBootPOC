package com.eagleSystem.eagleJob.entity;

public interface ClientNaukriPrefLocation {
	
	public String getPreferredLocations();

}
