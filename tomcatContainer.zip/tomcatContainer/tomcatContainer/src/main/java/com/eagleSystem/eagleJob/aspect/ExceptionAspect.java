package com.eagleSystem.eagleJob.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;

public class ExceptionAspect extends AbstractAppPointcut {

	@AfterThrowing(pointcut = "execution(* com.eagleSystem.eagleJob.*.*(..))", throwing = "excep")
	public void exceptionCustomHandle(JoinPoint joinPoint, Throwable excep) throws Throwable {

	}

}
