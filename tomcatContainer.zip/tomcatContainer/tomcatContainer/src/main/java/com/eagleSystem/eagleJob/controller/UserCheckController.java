package com.eagleSystem.eagleJob.controller;

import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.entity.JPUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class UserCheckController {

    @Autowired
    JPUserRepository jpUserRepository;

    @GetMapping(value = "/checkUser", produces = {"application/json"})
    public @ResponseBody boolean checkUser(String username) {

        if(username.equalsIgnoreCase(""))
            return false;

        JPUser jpUser = jpUserRepository.findByUsername(username);

        if(jpUser == null) {
            return false;
        }
        return true;
    }

}
