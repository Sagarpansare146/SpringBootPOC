package com.eagleSystem.eagleJob.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String name;
	private String email;
	private Long contactNumber;
	private String state;
	private String city;
	private String role;
	private Long excelLimit;
	private Long resumeLimit;
	private Long target;
	private Long loaction;
	
	private Long recruiterLimitPerDay;
	private String username;
	private String password;
	private Date joinDate = new Date();
	
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "subAdmin_id")
	private SubAdmin subAdmin;
	
	@OneToMany(mappedBy = "account", fetch = FetchType.LAZY)
	List<DbCustomerEntity> DbCustomer;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Long getExcelLimit() {
		return excelLimit;
	}
	public void setExcelLimit(Long excelLimit) {
		this.excelLimit = excelLimit;
	}
	public Long getResumeLimit() {
		return resumeLimit;
	}
	public void setResumeLimit(Long resumeLimit) {
		this.resumeLimit = resumeLimit;
	}
	public Long getTarget() {
		return target;
	}
	public void setTarget(Long target) {
		this.target = target;
	}
	public Long getLoaction() {
		return loaction;
	}
	public void setLoaction(Long loaction) {
		this.loaction = loaction;
	}
	public Long getRecruiterLimitPerDay() {
		return recruiterLimitPerDay;
	}
	public void setRecruiterLimitPerDay(Long recruiterLimitPerDay) {
		this.recruiterLimitPerDay = recruiterLimitPerDay;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	public SubAdmin getSubAdmin() {
		return subAdmin;
	}
	public void setSubAdmin(SubAdmin subAdmin) {
		this.subAdmin = subAdmin;
	}
	public List<DbCustomerEntity> getDbCustomer() {
		return DbCustomer;
	}
	public void setDbCustomer(List<DbCustomerEntity> dbCustomer) {
		DbCustomer = dbCustomer;
	}
	@Override
	public String toString() {
		return "Account [id=" + id + ", name=" + name + ", email=" + email + ", contactNumber=" + contactNumber
				+ ", state=" + state + ", city=" + city + ", role=" + role + ", excelLimit=" + excelLimit
				+ ", resumeLimit=" + resumeLimit + ", target=" + target + ", loaction=" + loaction
				+ ", recruiterLimitPerDay=" + recruiterLimitPerDay + ", username=" + username + ", password=" + password
				+ ", joinDate=" + joinDate + ", subAdmin=" + subAdmin + ", DbCustomer=" + DbCustomer + "]";
	}
	
	
	
}
