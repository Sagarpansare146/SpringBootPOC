package com.eagleSystem.eagleJob.util;

public interface ViewMapper {

	// common display pages
	
	public static final String HOME = "other/home";
	public static final String LOGIN = "other/login";
	public static final String ADMIN_LOGIN = "other/alogin";
	public static final String CANDIDATE_LOGIN = "other/candidate_login";
	public static final String RECRUITER_LOGIN = "other/recruiter_login";
	public static final String JOB_SEARCH = "other/find_job";
	public static final String FORGOT_PAGE = "other/forgot_page";
	public static final String COMMON_JOB_DETAILS = "other/common_job_details";
	
	public static final String CONTACT_US = "other/contact_us";
	public static final String TERMS_AND_CONDITION = "other/tnc";
	
	// candidate display pages
	
	public static final String CANDIDATE_REGISTRATION = "other/candidate_reg";
	public static final String CANDIDATE_PROFILE = "candidate/candidate_profile";
	public static final String CANDIDATE_VIEW_JOBS = "candidate/candidate_view_jobs";
	public static final String CANDIDATE_APPLIED_JOBS = "candidate/candidate_applied_jobs";
	public static final String CANDIDATE_JOB_DETAILS = "candidate/candidate_job_details";
	
	
	// recruiter display pages
	
	public static final String RECRUITER_REGISTRATION = "other/recruiter_reg";
	public static final String RECRUITER_COMPANY_PROFILE = "recruiter/company_profile";
	public static final String RECRUITER_JOB_POST = "recruiter/recruiter_job_post";
	public static final String RECRUITER_POSTED_JOBS = "recruiter/recruiter_posted_job";
	public static final String RECRUITER_JOB_UPDATE = "recruiter/recruiter_job_post";
	public static final String RECRUITER_JOB_RESPONSES = "recruiter/recruiter_job_responses";
	public static final String RECRUITER_NAUKRIJOBFILTER= "recruiter/recruiter_naukrijobfilter";
	public static final String RECRUITER_JOB_DETAILS = "recruiter/recruiter_job_details";
	public static final String RECRUITER_NAUKRI= "recruiter/recruiter_naukri";


	// Admin display pages
	
	public static final String ADMIN_INDEX = "admin/adminIndex";
	public static final String ADMIN_CREATE_SUBADMIN = "admin/admin_create_subadmin";
	public static final String ADMIN_SUBADMIN_LIST = "admin/admin_subadmin_list";
	public static final String ADMIN_EMPLOYEE_LIST = "admin/admin_employee_list";
	public static final String ADMIN_CUSTOMER_LIST = "admin/admin_customer_list";
	public static final String ADMIN_POSTINGCUSTOMER = "admin/admin_PostingCustomer";
	
	
	
	
	
	
	//BDM Display pages
	
	public static final String BDM_BDM_HOME="bdm/bdm_home";
	public static final String BDM_BDM_GOLDSERVER="bdm/bdm_goldserver";
	public static final String BDM_BDM_SILVER_SERVER="bdm/bdm_silver_server";
	
	public static final String BDM_BDM_REPORT="bdm/bdm_Report";
	public static final String BDM_BDM_VIEW="bdm/bdm_view";
	public static final String BDM_BDM_DEMOREG="bdm/bdm_demoreg";
	public static final String BDM_BDM_DATABASEREPORT="bdm/bdm_databasereport";
	public static final String BDM_BDM_POSTINGREPORT="bdm/bdm_postingreport";
	public static final String BDM_BDM_LATESTDATA="bdm/bdm_latestdata";
	public static final String BDM_BDM_DATABASEREG="bdm/bdm_databasereg";

	
	//User  Display pages
	
	
	public static final String USER_USER_HOME = "user/user_index";
	public static final String USER_USER_UPLOADEXCEL= "user/user_uploadExcel";
	public static final String USER_USER_NAUKRIDOWNLOAD= "user/user_naukridownload";
    public static final String USER_USER_SENDMAIL= "user/user_sendmail";
	public static final String USER_USER_FITCHDATA= "user/user_Fitchdata";
	public static final String USER_USER_SENDMAILATTCH= "user/user_sendmailAttch";



	


	//subadmin  Display pages
	
	public static final String SUBADMIN_SUBADMIN_INDEX = "subadmin/subadminIndex";
	public static final String SUBADMIN_SUBADMIN_CREATEACCOUNT = "subadmin/subadmin_createAccount";
	public static final String SUBADMIN_SUBADMIN_CREATECUSTOMER = "subadmin/subadmin_createCustomer";
	public static final String SUBADMIN_SUBADMIN_DAILYREPORT = "subadmin/subadmin_dailyReport";
	public static final String SUBADMIN_SUBADMIN_MONTHLYREPORT = "subadmin/subadmin_monthlyReport";
	public static final String SUBADMIN_SUBADMIN_DAILYDATABASE = "subadmin/subadmin_dailyDatabase";
	public static final String SUBADMIN_SUBADMIN_DAILYPOSTING = "subadmin/subadmin_dailyPosting";
	public static final String SUBADMIN_SUBADMIN_MONTHLYDATABASE = "subadmin/subadmin_monthlyDatabase";
	public static final String SUBADMIN_SUBADMIN_MONTHLYPOSTING = "subadmin/subadmin_monthlyPosting";
	public static final String SUBADMIN_SUBADMIN_CUSTOMERLIST = "subadmin/subadmin_customerList";
	public static final String SUBADMIN_SUBADMIN_BDMLIST = "subadmin/subadmin_bdmList";
	public static final String SUBADMIN_SUBADMIN_USERLIST = "subadmin/subadmin_userList";
	public static final String SUBADMIN_SUBADMIN_CREATEPOSTINGCUSTOMER = "subadmin/subadmin_createPostingcustomer";
	public static final String SUBADMIN_SUBADMIN_UPDATEACCOUNT = "subadmin/subadmin_updateAccount";
	public static final String SUBADMIN_SUBADMIN_UPDATEPOSTINGACCOUNT = "subadmin/subadmin_updatePostingAccount";
	
	public static final String SUBADMIN_SUBADMIN_UPDATECUSTOMER = "subadmin/subadmin_updatecustomer";
	
	
	//database  Display pages
	public static final String DATABASE_DATABASE_HOME="database/database_home";
	public static final String DATABASE_DATABASE_NAUKRI="database/database_naukri";
	public static final String DATABASE_DATABASE_NAUKRIJOB="database/database_naukrijob";
	public static final String DATABASE_DATABASE_REPORT="database/database_resumereport";
	
	//bdm Display pages
	
	
	
}