package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.eagleSystem.eagleJob.entity.MonsterExcelRecord;

public interface MonsterExcelRepository extends JpaRepository<MonsterExcelRecord, Long> {

	List<MonsterExcelRecord> findByJobCategory(String jobCategory);
	
	List<MonsterExcelRecord>findBycurrentLocation(String location);
	
	
	

	List<MonsterExcelRecord> findByJobCategoryAndCurrentLocation(String JobCategory,String CurrentLocation);
	
	@Query("SELECT DISTINCT p.jobCategory FROM MonsterExcelRecord p")
	List<String> findDistinctjobCategory();
	
	
	@Query("SELECT DISTINCT p.currentLocation FROM MonsterExcelRecord p")
	List<String> findDistinctcurrentLocation();
	
}
