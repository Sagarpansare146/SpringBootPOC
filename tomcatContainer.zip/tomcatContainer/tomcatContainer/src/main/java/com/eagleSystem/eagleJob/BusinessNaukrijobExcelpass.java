package com.eagleSystem.eagleJob;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import com.eagleSystem.eagleJob.entity.Qualification;
import com.eagleSystem.eagleJob.valueObject.CandidateRecords;

public class BusinessNaukrijobExcelpass extends AbstractXlsView  {

	@Override
	protected void buildExcelDocument(Map model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String name = (String) model.get("industry");

		// change the file name
		response.setHeader("Content-Disposition", "attachment; filename=\""+ "NaukrijobExcel"+ "_"+ name + ".xls\"");

		System.out.println(model);
		System.out.println(model.get("records"));
		
		
		@SuppressWarnings("unchecked")
		List<CandidateRecords> records = (List<CandidateRecords>) model.get("records");

		// create excel xls sheet
		Sheet sheet = workbook.createSheet("Job Post Response");

		// create header row
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("Sr. no.");
		header.createCell(1).setCellValue("CandidateName");
		header.createCell(2).setCellValue("Gender");
		header.createCell(3).setCellValue("KeySkill");
		header.createCell(4).setCellValue("Qualification");
		header.createCell(5).setCellValue("TotalExpInYear");
		header.createCell(6).setCellValue("TotalExpInMonth");
		header.createCell(7).setCellValue("Email ID");
		header.createCell(8).setCellValue("Contact Number");
		header.createCell(9).setCellValue("Location");
		header.createCell(10).setCellValue("Job Category");
		
		
		
		int rowCount = 0;                             
		for (CandidateRecords course : records) {               
			Row courseRow = sheet.createRow(++rowCount);
			System.out.println(rowCount);
			courseRow.createCell(0).setCellValue(rowCount);
			courseRow.createCell(1).setCellValue(course.getName());
			courseRow.createCell(2).setCellValue(course.getGender());
			courseRow.createCell(3).setCellValue(course.getKeySkill());
			courseRow.createCell(4).setCellValue(course.getQualification());
			courseRow.createCell(5).setCellValue(course.getTotalExpInYear());
			courseRow.createCell(6).setCellValue(course.getTotalExpInMonth());
			courseRow.createCell(7).setCellValue(course.getEmail());
			courseRow.createCell(8).setCellValue(course.getContactNumber());
			courseRow.createCell(9).setCellValue(course.getLocation());
			courseRow.createCell(10).setCellValue(course.getJobCategory());
			
						
		}

	}
	
}
