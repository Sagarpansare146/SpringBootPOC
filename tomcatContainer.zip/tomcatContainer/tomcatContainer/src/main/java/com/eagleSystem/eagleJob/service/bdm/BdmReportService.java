package com.eagleSystem.eagleJob.service.bdm;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.eagleSystem.eagleJob.dao.AccountRepository;
import com.eagleSystem.eagleJob.dao.BDMRecruiterRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.BDMRecuiterEntity;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import com.eagleSystem.eagleJob.entity.Recruiter;

@Service
public class BdmReportService {

	@Autowired
	AccountRepository accountRepository;

	@Autowired
	BDMRecruiterRepository bdmRecuiterRepository;
	
	@Autowired
	RecruiterRepository recruiterRepository;
	
	public List<DbCustomerEntity> getBdmDbCustomerReport() throws Exception {
		
	//	Map<String, Object> map = new HashMap<>();
		
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		
		if(authentication == null) {
			throw new Exception("Invalid User");
		}
		
		Account account = accountRepository.findByUsername(authentication.getName());
		
		if(account == null) {
			throw new Exception("Invalid operation");
		}
		
		List<DbCustomerEntity> lDbCustomer = account.getDbCustomer();
		
		System.out.println(lDbCustomer);
		
		return (lDbCustomer == null ? new ArrayList<>() : lDbCustomer);
	}
	
	public List<Recruiter> getBdmRecruiterReport() throws Exception {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		
		if(authentication == null) {
			throw new Exception("Invalid User");
		}
		
		Account account = accountRepository.findByUsername(authentication.getName());
		
		if(account == null) {
			throw new Exception("Invalid operation");
		}
		
		List<BDMRecuiterEntity> lBdmRec = bdmRecuiterRepository.findByBdmName(authentication.getName());
		
		List<Recruiter> lRecruiter = lBdmRec.stream().filter(e -> e != null)
				.map(e -> recruiterRepository.findOne(e.getRecuiterId())).collect(Collectors.toList());
		
		System.out.println(lRecruiter.toString());
		
		return (lRecruiter == null ? new ArrayList<>() : lRecruiter);
	}
	
}
