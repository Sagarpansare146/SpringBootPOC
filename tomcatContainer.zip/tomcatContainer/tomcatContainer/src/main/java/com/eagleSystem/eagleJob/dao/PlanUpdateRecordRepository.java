package com.eagleSystem.eagleJob.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagleSystem.eagleJob.entity.PlanUpdateRecord;

public interface PlanUpdateRecordRepository extends JpaRepository<PlanUpdateRecord, Long>{

}
