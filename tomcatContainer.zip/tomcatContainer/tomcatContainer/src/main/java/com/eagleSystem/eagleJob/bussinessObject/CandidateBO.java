package com.eagleSystem.eagleJob.bussinessObject;

import java.util.Date;
import java.util.List;

public class CandidateBO {

	private Long id;
	private String name;
	private String email;
	private long contactNumber;
	private String candidateAddress;
	private String candidateState;
	private String candidateCity;
	private Date dob;
	private String gender;
	private String username;
	private String password;
	private CandidateQualBO qualification;
	private String applicationStatus;
	private CandidatePrefBO CandidatePreference;
	private List<JobBO> appliedJobs;

	private String token = "";
	private boolean notificationStatus;

	public CandidateBO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getCandidateAddress() {
		return candidateAddress;
	}

	public void setCandidateAddress(String candidateAddress) {
		this.candidateAddress = candidateAddress;
	}

	public String getCandidateState() {
		return candidateState;
	}

	public void setCandidateState(String candidateState) {
		this.candidateState = candidateState;
	}

	public String getCandidateCity() {
		return candidateCity;
	}

	public void setCandidateCity(String candidateCity) {
		this.candidateCity = candidateCity;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public CandidateQualBO getQualification() {
		return qualification;
	}

	public void setQualification(CandidateQualBO qualification) {
		this.qualification = qualification;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public CandidatePrefBO getCandidatePreference() {
		return CandidatePreference;
	}

	public void setCandidatePreference(CandidatePrefBO candidatePreference) {
		CandidatePreference = candidatePreference;
	}

	public List<JobBO> getAppliedJobs() {
		return appliedJobs;
	}

	public void setAppliedJobs(List<JobBO> appliedJobs) {
		this.appliedJobs = appliedJobs;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public boolean isNotificationStatus() {
		return notificationStatus;
	}

	public void setNotificationStatus(boolean notificationStatus) {
		this.notificationStatus = notificationStatus;
	}

	@Override
	public String toString() {
		return "CandidateBO [id=" + id + ", name=" + name + ", email=" + email + ", contactNumber=" + contactNumber
				+ ", candidateAddress=" + candidateAddress + ", candidateState=" + candidateState + ", candidateCity="
				+ candidateCity + ", dob=" + dob + ", gender=" + gender + ", username=" + username + ", password="
				+ password + ", qualification=" + qualification + ", applicationStatus=" + applicationStatus
				+ ", CandidatePreference=" + CandidatePreference + ", appliedJobs=" + appliedJobs + ", token=" + token
				+ ", notificationStatus=" + notificationStatus + "]";
	}

}
