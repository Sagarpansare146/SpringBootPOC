package com.eagleSystem.eagleJob.aspect;

import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.dao.BoosterPlanRepository;
import com.eagleSystem.eagleJob.dao.JobRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.BoosterPlan;
import com.eagleSystem.eagleJob.entity.JobPost;
import com.eagleSystem.eagleJob.entity.MasterPlan;
import com.eagleSystem.eagleJob.entity.Recruiter;

@Aspect
@Component
public class ResumeAspect {

	@Autowired
	JobRepository jobRepo;

	@Autowired
	RecruiterRepository recruiterRepository;

	@Autowired
	BoosterPlanRepository bPlanRepo;

	@Around("execution(* com.eagleSystem.eagleJob.service.RecruiterServiceImpl.downloadResume(..))")
	public Object checkBeforeDownload(ProceedingJoinPoint pjp) throws Throwable {

		System.out.println("Resume Aspect");

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		Recruiter rec = recruiterRepository.findByUsername(auth.getName());

		BoosterPlan bp = rec.getBoosterPlan();
		MasterPlan mp = rec.getMasterPlan();

		int fixedLimit = 0;

		if (bp != null)
			fixedLimit = mp.getResumeDownloadLimit() + bp.getResumeDownloadLimit();

		fixedLimit = mp.getResumeDownloadLimit();

		Object obj[] = pjp.getArgs();
		List<Long> cadId = (List<Long>) obj[0];
		Long jobId = (Long) obj[1];

		JobPost jobPost = jobRepo.findOne(jobId);
		int records = cadId.size() + jobPost.getResumeDownloadCount();

		if (records >= fixedLimit) {
			throw new Exception("already 20 resume downloaded");
		}

		Object ret = pjp.proceed();

		jobPost.setResumeDownloadCount(records);
		jobRepo.save(jobPost);

		return ret;
	}

}
