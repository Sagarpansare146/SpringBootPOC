package com.eagleSystem.eagleJob.valueObject;

import java.util.Date;

public class CandidateRecords {

	private Long id;
	private String name;
	private String totalExpInYear;
	private String totalExpInMonth;
	private String location;
	private String gender;
	
	private String jobCategory;
	private String keySkill;
	private String qualification;
	private Long salary;
	private String email;
	 private long contactNumber;
	 private Date dob;
	 private Integer passout;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getTotalExpInYear() {
		return totalExpInYear;
	}
	public void setTotalExpInYear(String totalExpInYear) {
		this.totalExpInYear = totalExpInYear;
	}
	public String getTotalExpInMonth() {
		return totalExpInMonth;
	}
	public void setTotalExpInMonth(String totalExpInMonth) {
		this.totalExpInMonth = totalExpInMonth;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getJobCategory() {
		return jobCategory;
	}
	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}
	public String getKeySkill() {
		return keySkill;
	}
	public void setKeySkill(String keySkill) {
		this.keySkill = keySkill;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public Long getSalary() {
		return salary;
	}
	public void setSalary(Long salary) {
		this.salary = salary;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	public Integer getPassout() {
		return passout;
	}
	public void setPassout(Integer passout) {
		this.passout = passout;
	}
	
	
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	@Override
	public String toString() {
		return "CandidateRecords [id=" + id + ", name=" + name + ", totalExpInYear=" + totalExpInYear
				+ ", totalExpInMonth=" + totalExpInMonth + ", location=" + location + ", gender=" + gender
				+ ", jobCategory=" + jobCategory + ", keySkill=" + keySkill + ", qualification=" + qualification
				+ ", salary=" + salary + ", email=" + email + ", contactNumber=" + contactNumber + ", dob=" + dob
				+ ", passout=" + passout + "]";
	}
	
	
	
	
}
