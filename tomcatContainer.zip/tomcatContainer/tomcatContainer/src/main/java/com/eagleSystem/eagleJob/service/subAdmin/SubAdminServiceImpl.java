package com.eagleSystem.eagleJob.service.subAdmin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eagleSystem.eagleJob.dao.AccountRepository;
import com.eagleSystem.eagleJob.dao.BDMRecruiterRepository;
import com.eagleSystem.eagleJob.dao.CandidateRepository;
import com.eagleSystem.eagleJob.dao.CustomerSubAdminRepository;
import com.eagleSystem.eagleJob.dao.DBCustomerRepository;
import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.dao.SubAdminRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.BDMRecuiterEntity;
import com.eagleSystem.eagleJob.entity.Candidate;
import com.eagleSystem.eagleJob.entity.CustomerSubAdmin;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import com.eagleSystem.eagleJob.entity.JPUser;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.entity.SubAdmin;
import com.eagleSystem.eagleJob.util.Coverter;
import com.eagleSystem.eagleJob.util.Role;
import com.eagleSystem.eagleJob.valueObject.CreateSubadmin;

@Service
public class SubAdminServiceImpl {

	@Autowired
	SubAdminRepository subAdminRepository;

	@Autowired
	AccountRepository accountRepository;

	@Autowired
	BDMRecruiterRepository bdmRecuiterRepository;

	@Autowired
	CustomerSubAdminRepository customerSubAdminRepository;

	@Autowired
	DBCustomerRepository dbCustomerRepository;

	@Autowired
	RecruiterRepository recruiterRepository;

	@Autowired
	JPUserRepository jpUserRepository;

	@Autowired
	CandidateRepository candidateRepository;

	public static Specification getByName(String name) {
		
		return new Specification() {

			@Override
			public Predicate toPredicate(Root root, CriteriaQuery query, CriteriaBuilder cb) {
				// TODO Auto-generated method stub
				
				List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();
				
				if(! name.equals("")) {
					predicates.add(cb.equal(root.get("name"), name ));
				}
				
				return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[0]));
				
			}
		};
		
	}
	
	@Transactional
	public boolean addSubAdmin(CreateSubadmin subadmin) throws Exception {

		boolean flag = true;

		SubAdmin subAdmin = (new Coverter()).converSubAdmin(subadmin);

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}

		JPUser jpUser = jpUserRepository.findByUsernameIgnoreCase(subAdmin.getUsername());

		if (jpUser != null) {
			throw new Exception("Already Register with username : " + subAdmin.getUsername());
		}

		jpUser = new JPUser();

		jpUser.setUsername(subAdmin.getUsername());
		jpUser.setPassword(subAdmin.getPassword());
		jpUser.setEnabled(true);
		jpUser.setRole("subadmin");
		try {
			subAdminRepository.save(subAdmin);
			jpUserRepository.save(jpUser);
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}

		return flag;
	}

	@Transactional
	public boolean createAccount(Account account) throws Exception {

		boolean flag = true;

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}

		JPUser jpUser = jpUserRepository.findByUsernameIgnoreCase(account.getUsername());

		if (jpUser != null) {
			throw new Exception("Already Register with username : " + account.getUsername());
		}

		jpUser = new JPUser();

		jpUser.setUsername(account.getUsername());
		jpUser.setPassword(account.getPassword());
		jpUser.setEnabled(true);
		jpUser.setRole(account.getRole());

		SubAdmin subAdmin = getSubAdmin(authentication.getName());

		account.setSubAdmin(subAdmin);

		try {
			accountRepository.save(account);
			jpUserRepository.save(jpUser);

		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		updateSubAdmin(authentication.getName());

		return flag;

	}

	@Transactional
	public boolean createCustomer(DbCustomerEntity dbCustomerEntity) throws Exception {

		boolean flag = true;    

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}

		JPUser jpUser = jpUserRepository.findByUsernameIgnoreCase(dbCustomerEntity.getUsername());

		if (jpUser != null) {
			throw new Exception("Already Register with username : " + dbCustomerEntity.getUsername());
		}

		jpUser = new JPUser();

		jpUser.setUsername(dbCustomerEntity.getUsername());
		jpUser.setPassword(dbCustomerEntity.getPassword());
		jpUser.setEnabled(true);
		jpUser.setRole(Role.database.name());

		try {
			dbCustomerEntity.setAccount(accountRepository.findByUsername("eagletkInfotech"));
			dbCustomerRepository.save(dbCustomerEntity);
			customerSubAdminRepository.save(new CustomerSubAdmin(dbCustomerEntity.getId(), authentication.getName()));
			jpUserRepository.save(jpUser);
		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
		}
		updateSubAdmin(authentication.getName());

		return flag;

	}

	public List<DbCustomerEntity> getCustomerReport() throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}

	System.out.println(customerSubAdminRepository.getIdBySubAdmin(authentication.getName()));
		
		return customerSubAdminRepository.getIdBySubAdmin(authentication.getName()).stream()
				.map(e2 -> e2.longValue())
				.map(e -> dbCustomerRepository.findOne(e))
				.collect(Collectors.toList());

	}

	public List<DbCustomerEntity> getBDMCustomerReport(Long id) throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		List<DbCustomerEntity> dbCustomer;
		if (authentication == null) {
			throw new Exception("Invalid User");
		}
   
		Optional<Account> account = getSubAdmin(authentication.getName()).getAccount().stream()
				.filter(e -> e.getId() == id).findFirst();

		if (!account.isPresent()) {

			dbCustomer = new ArrayList<>();
		} else {
			dbCustomer = account.get().getDbCustomer();
		}
		return dbCustomer;
	}

	/*
	 * public List<Recruiter> getBDMRecruiterReport(Long id) throws Exception {
	 * 
	 * Authentication authentication =
	 * SecurityContextHolder.getContext().getAuthentication();
	 * 
	 * if (authentication == null) { throw new Exception("Invalid User"); }
	 * 
	 * List<BDMRecuiterEntity> bdmRecuiterEntity =
	 * bdmRecuiterRepository.getIdByBdmName(authentication.getName());
	 * 
	 * return bdmRecuiterEntity.stream().map(e ->
	 * recruiterRepository.findOne(e.getRecuiterId()))
	 * .collect(Collectors.toList());
	 * 
	 * }
	 */

	public boolean updateRecruiter() {

		// recruiterRepository.findBy

		return false;
	}

	public Recruiter getRecruiterProfile(Long id) throws Exception {

		if (id == 0l)
			throw new Exception("Invalid Recruiter id");

		return recruiterRepository.findOne(id);

	}

	public boolean changePassword(Long id, String role, String password) throws Exception {

		boolean flag = true;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		SubAdmin subAdmin = getSubAdmin(authentication.getName());

		switch (authentication.getAuthorities().iterator().next().getAuthority().toString()) {
		case "recruiter":

			Optional<BDMRecuiterEntity> bdmRecuiterEntity = bdmRecuiterRepository
					.findByBdmName(authentication.getName()).stream().filter(e -> e.getId() == id).findFirst();

			if (bdmRecuiterEntity.isPresent()) {
				Recruiter recruiter = recruiterRepository.findOne(bdmRecuiterEntity.get().getRecuiterId());
				JPUser jpUser = jpUserRepository.findByUsername(recruiter.getUsername());

				if (jpUser == null)
					throw new Exception("Invalid recruiter id");

				jpUser.setPassword(password);
				try {
					jpUserRepository.save(jpUser);
				} catch (Exception e) {
					e.printStackTrace();
					flag = false;
				}
			} else {
				flag = false;
			}

			break;

		case "candidate":
			Candidate candidate = null;
			try {
				candidate = candidateRepository.findOne(id);
			} catch (Exception e) {
				e.printStackTrace();
				flag = false;
			}

			if (candidate != null) {

				JPUser jpUser = jpUserRepository.findByUsername(candidate.getUsername());

				if (jpUser == null)
					throw new Exception("Invalid Candidate id");

				jpUser.setPassword(password);
				try {
					jpUserRepository.save(jpUser);
				} catch (Exception e) {
					e.printStackTrace();
					flag = false;
				}
			}
			break;

		default:

			try {
				Optional<Account> account = subAdmin.getAccount().stream().filter(e -> e.getRole().equals(role))
						.filter(e -> e.getId() == id).findFirst();

				if (account.isPresent()) {
					account.get().setPassword(password);
					accountRepository.save(account.get());
				} else {
					flag = false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				flag = false;
			}

			break;
		}
		updateSubAdmin(authentication.getName());

		return flag;

	}

	
	
	
	public Map<String, Object> getAllUsersByRole(String role, int page, int pageSize) {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		Map<String, Object> map = new HashMap<>();

		Pageable pageRequest;

		switch (role) {

		case "candidate":

			pageRequest = new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "id");

			Page<Candidate> dataPage = candidateRepository.findAll(pageRequest);

			map.put("data", dataPage.getContent());
			map.put("totalCount", (dataPage != null ? 0 : dataPage.getTotalElements()));
			map.put("totalPages", (dataPage != null ? 0 : dataPage.getTotalPages()));
			break;

		case "recruiter":

			pageRequest = new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "id");

			Page<BDMRecuiterEntity> dataPage1 = bdmRecuiterRepository.findByBdmName(authentication.getName(),
					pageRequest);
			List l = dataPage1.getContent().stream().map(e -> e.getRecuiterId())
					.map(e -> recruiterRepository.findOne(e)).collect(Collectors.toList());

			map.put("data", l);
			map.put("totalCount", (dataPage1 != null ? 0 : dataPage1.getTotalElements()));
			map.put("totalPages", (dataPage1 != null ? 0 : dataPage1.getTotalPages()));
			break;

		/*
		 * case Role.user.name() :
		 * 
		 * break;
		 * 
		 */
		default:

			pageRequest = new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "id");

			Page<Account> dataPage2 = accountRepository.findBySubAdminUsername(authentication.getName(), pageRequest);
			map.put("data", dataPage2.getContent().stream().filter(e -> e.getRole().equals(role)).collect(Collectors.toList()));
			map.put("totalCount", (dataPage2 != null ? 0 : dataPage2.getTotalElements()));
			map.put("totalPages", (dataPage2 != null ? 0 : dataPage2.getTotalPages()));
			break;
		}

		return map;
	}
	
	public Map<String, Object> searchUsersByNameAndRole(String name, String role, int page, int pageSize) {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		Map<String, Object> map = new HashMap<>();

		Pageable pageRequest;

		switch (role) {

		case "candidate":

			pageRequest = new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "id");

			Page<Candidate> dataPage = candidateRepository.findAll(getByName(name),pageRequest);

			map.put("records", dataPage.getContent());
			map.put("totalCount", (dataPage != null ? 0 : dataPage.getTotalElements()));
			map.put("totalPages", (dataPage != null ? 0 : dataPage.getTotalPages()));
			break;

		case "recruiter":

			pageRequest = new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "id");

			Page<BDMRecuiterEntity> dataPage1 = bdmRecuiterRepository.findByBdmName(authentication.getName(),
					pageRequest);
			List l = dataPage1.getContent().stream()
					.map(e -> e.getRecuiterId())
					.map(e1 -> recruiterRepository.findOne(e1))
					.map(e2 -> recruiterRepository.findByNameContaining(e2.getName()))
					.collect(Collectors.toList());

			map.put("records", l);
			map.put("totalCount", (dataPage1 != null ? 0 : dataPage1.getTotalElements()));
			map.put("totalPages", (dataPage1 != null ? 0 : dataPage1.getTotalPages()));
			break;

		/*
		 * case Role.user.name() :
		 * 
		 * break;
		 * 
		 */
		default:

			pageRequest = new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "id");

			Page<Account> dataPage2 = accountRepository.findBySubAdminUsername(authentication.getName(), pageRequest);
			map.put("records", dataPage2.getContent().stream().filter(e -> e.getName().equalsIgnoreCase(name)).collect(Collectors.toList()));
			map.put("totalCount", (dataPage2 != null ? 0 : dataPage2.getTotalElements()));
			map.put("totalPages", (dataPage2 != null ? 0 : dataPage2.getTotalPages()));
			break;
		}

		return map;
	}

	public boolean disable(Long id, String role, int status) throws Exception {

		boolean flag = true;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		SubAdmin subAdmin = getSubAdmin(authentication.getName());

		switch (authentication.getAuthorities().iterator().next().getAuthority().toString()) {
		case "recruiter":

			Optional<BDMRecuiterEntity> bdmRecuiterEntity = bdmRecuiterRepository
					.findByBdmName(authentication.getName()).stream().filter(e -> e.getId() == id).findFirst();

			if (bdmRecuiterEntity.isPresent()) {
				Recruiter recruiter = recruiterRepository.findOne(bdmRecuiterEntity.get().getRecuiterId());
				JPUser jpUser = jpUserRepository.findByUsername(recruiter.getUsername());

				if (jpUser == null)
					throw new Exception("Invalid recruiter id");

				jpUser.setEnabled((status == 0 ? false : true));
				try {
					jpUserRepository.save(jpUser);
				} catch (Exception e) {
					e.printStackTrace();
					flag = false;
				}
			} else {
				flag = false;
			}

			break;

		case "candidate":
			Candidate candidate = null;
			try {
				candidate = candidateRepository.findOne(id);
			} catch (Exception e) {
				e.printStackTrace();
				flag = false;
			}

			if (candidate != null) {

				JPUser jpUser = jpUserRepository.findByUsername(candidate.getUsername());

				if (jpUser == null)
					throw new Exception("Invalid Candidate id");

				jpUser.setEnabled((status == 0 ? false : true));
				try {
					jpUserRepository.save(jpUser);
				} catch (Exception e) {
					e.printStackTrace();
					flag = false;
				}
			}
			break;

		default:

			try {
				Optional<Account> account = subAdmin.getAccount().stream().filter(e -> e.getRole().equals(role))
						.filter(e -> e.getId() == id).findFirst();

				if (account.isPresent()) {
					
					JPUser jpUser = jpUserRepository.findByUsername(account.get().getUsername());

					if (jpUser == null)
						throw new Exception("Invalid Candidate id");

					jpUser.setEnabled((status == 0 ? false : true));
					
					try {
						jpUserRepository.save(jpUser);
					} catch (Exception e) {
						e.printStackTrace();
						flag = false;
					}
					
				} else {
					flag = false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				flag = false;
			}

			break;
		}
		updateSubAdmin(authentication.getName());

		return flag;
	}

	public List<Account> getBDMReport() throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}
		
		return getSubAdmin(authentication.getName()).getAccount().stream()
				.peek(e -> System.out.println(e))
				.filter(e -> e.getRole().equals(Role.bdm.name()))
				.collect(Collectors.toList());
	}
	
	public List<DbCustomerEntity> getDbCustInBDMReport(Long id) throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}
		
		
		return getSubAdmin(authentication.getName()).getAccount().stream()
				.filter(e -> e.getRole().equals(Role.bdm.name()))
				.filter(e1 -> e1.getId() == id)
				.map(e -> e.getDbCustomer())
				.findFirst().orElse(new ArrayList<>());
	}
	
	public List<Recruiter> getDbRecruiterInBDMReport(Long id) throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}
		
		return getSubAdmin(authentication.getName()).getAccount().stream()
				.filter(e -> e.getRole().equals(Role.bdm.name()))
				.filter(e1 -> e1.getId() == id)
				.map(e -> bdmRecuiterRepository.findByBdmName(e.getUsername()))
				
				.flatMap(e -> e.stream().map(e1 -> e1.getRecuiterId()))
				.map(e -> recruiterRepository.findOne(e)).collect(Collectors.toList());
	}
	
	/*public List<Recruiter> getDbRecruiterDownloadInBDMReport(Long id) throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}
		
		return getSubAdmin(authentication.getName()).getAccount().stream()
				.filter(e -> e.getRole().equals(Role.bdm.name()))
				.map(e -> bdmRecuiterRepository.findByBdmName(e.getUsername()))
				.flatMap(e -> e.stream().map(e1 -> e1.getRecuiterId()))
				.map(e -> recruiterRepository.findOne(e)).collect(Collectors.toList());
	}
	
	
	*/

	@Cacheable(cacheNames = "subAdmin", key = "#username")
	private SubAdmin getSubAdmin(String username) {

		return subAdminRepository.findByUsername(username);

	}

	@CacheEvict(cacheNames = "subAdmin", key = "#username")
	public SubAdmin updateSubAdmin(String username) {
		return subAdminRepository.findByUsername(username);
	}

}
