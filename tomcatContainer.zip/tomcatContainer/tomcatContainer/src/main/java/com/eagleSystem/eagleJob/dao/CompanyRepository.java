package com.eagleSystem.eagleJob.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagleSystem.eagleJob.entity.Company;

public interface CompanyRepository extends JpaRepository<Company, Long> {

}
