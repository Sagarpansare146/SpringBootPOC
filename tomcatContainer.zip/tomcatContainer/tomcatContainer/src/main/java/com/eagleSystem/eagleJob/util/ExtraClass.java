package com.eagleSystem.eagleJob.util;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;

public class ExtraClass {

	/*String Month[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
	
	public static void process() {
		
		 File file = new File("C:\\Users\\Mayank\\Desktop\\1.txt");
         
	        // renaming the file and moving it to a new location
	        if(file.renameTo
	           (new File("C:\\Users\\Mayank\\Desktop\\dest\\newFile.txt")))
	        {
	            // if file copied successfully then delete the original file
	            file.delete();
	            System.out.println("File moved successfully");
	        }
	        else
	        {
	            System.out.println("Failed to move the file");
	        }
	 
		
	}
	

    *//**
     * List all the files and folders from a directory
     * @param directoryName to be listed
     *//*
    public void listFilesAndFolders(String directoryName){
        File directory = new File(directoryName);
        //get all the files from a directory
        File[] fList = directory.listFiles();
        
    //   Arrays.asList(a)
        
        for (File file : fList){
            System.out.println(file.getName());
        }
    }
    *//**
     * List all the files under a directory
     * @param directoryName to be listed
     *//*
    public void listFiles(String directoryName){
        File directory = new File(directoryName);
        //get all the files from a directory
        File[] fList = directory.listFiles();
        for (File file : fList){
            if (file.isFile()){
                System.out.println(file.getName());
            }
        }
    }
    *//**
     * List all the folder under a directory
     * @param directoryName to be listed
     *//*
    public void listFolders(String directoryName){
        File directory = new File(directoryName);
        //get all the files from a directory
        File[] fList = directory.listFiles();
        for (File file : fList){
            if (file.isDirectory()){
                System.out.println(file.getName());
            }
        }
    }
    *//**
     * List all files from a directory and its subdirectories
     * @param directoryName to be listed
     *//*
    public void listFilesAndFilesSubDirectories(String directoryName){
        File directory = new File(directoryName);
        //get all the files from a directory
        File[] fList = directory.listFiles();
        for (File file : fList){
            if (file.isFile()){
                System.out.println(file.getAbsolutePath());
            } else if (file.isDirectory()){
                listFilesAndFilesSubDirectories(file.getAbsolutePath());
            }
        }
    }
    public static void main (String[] args){
        ListFilesUtil listFilesUtil = new ListFilesUtil();
        final String directoryLinuxMac ="/Users/loiane/test";
        //Windows directory example
        final String directoryWindows ="C://test";
        listFilesUtil.listFiles(directoryLinuxMac);
    }
	
public NaukriExcelRecord getNaukriRecord(Map<String, String> map) {
		
	//	Predicate pred = QNaukriExcelRecord.naukriExcelRecord.name.contains((map.get("firstName") != null ? map.get("firstName") : "N/A"));
		//		.and(QNaukriExcelRecord.naukriExcelRecord.currentLocation.contains((map.get("loc") != null ? map.get("loc") : "N/A")))
		//		.and(QNaukriExcelRecord.naukriExcelRecord.dob.contains((map.get("dob") != null ? map.get("dob") : "N/A")));
		
	System.out.println(map.get("fullName")+ map.get("dob") + map.get("loc"));
	
		if(map.get("dob") == null || map.get("dob").equalsIgnoreCase("null"))
			return naukriExcelRepository.findByNameAndCurrentLocationContains(map.get("fullName"), map.get("loc"));
		
			return naukriExcelRepository.findByNameAndCurrentLocationContainsAndDob(map.get("fullName"), map.get("loc"), map.get("dob"));
		
	}
    
    public boolean check(Map<String, String> map) {
    	
    	int i = 1;
    	System.out.println(map);
    	NaukriExcelRecord nauk = null;
    	
    	try {
    	nauk = getNaukriRecord(map);
    	} catch(Exception e) {
    		e.printStackTrace();
    		System.out.println("Double records");
    	}
	try{	
		
		if(nauk == null)
		System.out.println(i);
		i++;
	}catch (Exception e) {
		
	}
		
    	return (nauk != null ? nauk.getResumePath() == null || nauk.getResumePath().equalsIgnoreCase("") ? true : false : false);

    }
    
    public boolean save(Map<String, String> map, String path) {
    	
    	NaukriExcelRecord nauk = getNaukriRecord(map);
    	
    	System.out.println(nauk.toString() + " "+map);
    	if(nauk.getResumePath() == null || nauk.getResumePath().equalsIgnoreCase("")) {
    		System.out.println(nauk.toString() + " "+map);
        	
    		nauk.setResumePath(path);
    		naukriExcelRepository.save(nauk);
    		return true;
    	}
    
    	return false;
    	
    }
    
    
    public Map<String, String> getDetail(String str) {
    	
    	Map<String, String> map = new HashMap<>();
    	
    	List<String> ls = Arrays.stream(str.split("_")).map(s -> s.trim()).collect(Collectors.toList());
        
    	List<String> mon = Arrays.asList(Month);
    	int i = ls.indexOf(new String("Year(s)"));
    
       	Optional<String> OfullName = ls.stream().limit(i-1).reduce((s,s1) -> s + " "+ s1 );
        
    	String d = "";
    	if(ls.stream().anyMatch( s -> mon.contains(s))) {
    	d= getDob(ls, mon);
    	}
    	else {
    		d = "";
    	}
    	Optional<String> Oloc = ls.stream().skip(i+3).limit(1).reduce((s, s1) -> s +"/"+ s1);
    	
    	boolean fullName = ( OfullName.isPresent() ? OfullName.get().equals("") ? false : map.put("fullName", OfullName.get()) != null : false);
    	boolean dob = ( d != null ? d.equals("") ? false : map.put("dob", d) != null : false);
    	boolean loc = ( Oloc.isPresent() ? Oloc.get().equals("") ? false : map.put("loc", Oloc.get()) != null : false);
    	
    	System.out.println(map);
    	
    	return map;
    }
    
    public String getDob(List<String> ls, List<String> mon) {
     	int j = Integer.parseInt(ls.stream().filter(s -> mon.contains(s)).reduce("", (s, s1) -> String.valueOf(ls.indexOf(s)+ls.indexOf(s1))));
    	
    	
        //	Optional<String> exp = ls.stream().skip(i-1).limit(4).reduce((s, s1) -> s +" "+ s1);
        	
        	Optional<String> Odob = ls.stream().skip(j).limit(3).reduce((s, s1) -> s +" "+ s1);
        	
        	String Sdob = Odob.get().substring(0, Odob.get().lastIndexOf(".")).replaceAll(" ", "-");
        	
        	String d = "";
        	try {
    			d = new SimpleDateFormat("dd/MM/yyyy").format(new SimpleDateFormat("dd-MMM-yyyy").parse(Sdob));
    		} catch (ParseException e) {
    			
    			e.printStackTrace();
    		}
        	System.out.println("Before process d :" +d);
        	List<String> lDob = Arrays.stream(d.split("/")).map(s -> s.trim()).collect(Collectors.toList());
        	List<String> finalDob = new ArrayList<>();
            
        	System.out.println(lDob);
        	
        	for(String sd : lDob) {
        		if(sd.substring(0, 1).equals("0")) 
        		{ 
        			sd = sd.replaceAll("0", " ").trim();
        			
        			System.out.println(sd.replaceAll("0", ""));
        			
        			System.out.println("s : " +sd);
        			finalDob.add(sd);
        			
        			} else {
        				finalDob.add(sd);
        			}
        		System.out.println(finalDob);
        	}
        	
        	
        	lDob.forEach(s -> {
        		if(s.substring(0, 1).equals("0")) 
        		{ 
        			s = s.replaceAll("0", " ");
        			
        			System.out.println(s.replaceAll("0", ""));
        			
        			System.out.println("s : " +s);
        			
        		}
        		});
        	
        	System.out.println(finalDob);
        	
        	
        	Optional<String> d1 = finalDob.stream().reduce((s, s1) -> s +"/"+ s1);
        	
        	if(d1.isPresent()) {
        		d = d1.get();
        	}
        
        	System.out.println(d);
        	
        	return d;
        
    }*/
	
}
