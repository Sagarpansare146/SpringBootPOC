package com.eagleSystem.eagleJob.controller.user;


import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.eagleSystem.eagleJob.BusinessExcelBuilder;
import com.eagleSystem.eagleJob.aspect.JobPostAspect;
import com.eagleSystem.eagleJob.dao.MonsterExcelRepository;
import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;
import com.eagleSystem.eagleJob.dao.ShineExcelRepository;
import com.eagleSystem.eagleJob.dao.TimesExcelRepository;
import com.eagleSystem.eagleJob.entity.MonsterExcelRecord;
import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;
import com.eagleSystem.eagleJob.entity.ShineExcelRecord;
import com.eagleSystem.eagleJob.entity.TimesExcelRecord;
import com.eagleSystem.eagleJob.service.UserServiceImpl;
import com.eagleSystem.eagleJob.util.ResumeUtil;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.CandidateRecords;
import com.eagleSystem.eagleJob.BusinessShineExcelBuilder;
import com.eagleSystem.eagleJob.BusinesMonstarExcelBuilder;
import com.eagleSystem.eagleJob.BusiessTimeJobExcelBuilder;
import com.eagleSystem.eagleJob.BusinessNaukrijobExcelpass;


@Controller
public class UserControl {

	private static final Logger LOGGER = LoggerFactory.getLogger(JobPostAspect.class);

	@Autowired
	NaukriExcelRepository naukriExcelRepository;
    @Autowired
    ShineExcelRepository shineExcelRepository;
    @Autowired
    MonsterExcelRepository monsterExcelRepository;
	@Autowired
	TimesExcelRepository timesExcelRepository;
  
	@Autowired
    UserServiceImpl userServiceImpl;
    
	@Autowired
	ResumeUtil resumeUtil;
	
	
	
	@RequestMapping("/userhome")
	public String userindex() {
		return ViewMapper.USER_USER_HOME;
	}
	
	@GetMapping("/userSendAttchEmail")
	public String SendAttchEmail() {
		return ViewMapper.USER_USER_SENDMAILATTCH;
	}

	
	
	@GetMapping("/userSendEmail")
	public String subadminsend() {
		return ViewMapper.USER_USER_SENDMAIL;
	}

	
	@GetMapping("/userNaukriDownload")
	public String NaukriDownload() {
		return ViewMapper.USER_USER_NAUKRIDOWNLOAD;
	}

	

	@GetMapping("/useruploadExcel")
	public String useruploadExcel() {
		return ViewMapper.USER_USER_UPLOADEXCEL;
	}
	
	@RequestMapping(value = "/userDownload", method = RequestMethod.GET)
	public ModelAndView downloadExcelRecords(@RequestParam("jobCategory") String jobCategory,
			@RequestParam("location") String location, Map<String, Object> model) {

		List<NaukriExcelRecord> records = naukriExcelRepository
				.findByJobCategoryAndPreferredLocationsContaining(jobCategory, location);

		System.out.println(records.size());
		// Map<String, Object> model = new HashMap<>();
		LOGGER.info("Total records fetch count :" + records.size());

		model.put("records", records);
		model.put("industry", jobCategory);

		return new ModelAndView(new BusinessExcelBuilder(), "records", records);

	}
	
	@RequestMapping(value = "/usershineDownload", method = RequestMethod.GET)
	public ModelAndView usershineDownload(@RequestParam("jobCategory") String JobCategory,
			@RequestParam("location") String CurrentLocation, Map<String, Object> model) {

		List<ShineExcelRecord> records = shineExcelRepository.findByJobCategoryAndCurrentLocation(JobCategory, CurrentLocation);
						System.out.println(records.size());
		// Map<String, Object> model = new HashMap<>();
		LOGGER.info("Total records fetch count :" + records.size());

		model.put("records", records);
		model.put("industry", JobCategory);

		return new ModelAndView(new BusinessShineExcelBuilder(), "records", records);

	}
	
	
	@RequestMapping(value = "/userTimeJobDownload", method = RequestMethod.GET)
	public ModelAndView userTimeJobDownload(@RequestParam("jobCategory") String JobCategory,
			 Map<String, Object> model) {

		List<TimesExcelRecord> records = timesExcelRepository.findByJobCategory(JobCategory);
						System.out.println(records.size());
		// Map<String, Object> model = new HashMap<>();
		LOGGER.info("Total records fetch count :" + records.size());

		model.put("records", records);
		model.put("industry", JobCategory);

		return new ModelAndView(new BusiessTimeJobExcelBuilder(), "records", records);

	}
	
	
	@RequestMapping(value = "/userMonstarDownload", method = RequestMethod.GET)
	public ModelAndView userMonstarDownload(@RequestParam("jobCategory") String JobCategory,
			@RequestParam("location") String CurrentLocation, Map<String, Object> model) {

		List<MonsterExcelRecord> records = monsterExcelRepository.findByJobCategoryAndCurrentLocation(JobCategory, CurrentLocation);
						System.out.println(records.size());
		// Map<String, Object> model = new HashMap<>();
		LOGGER.info("Total records fetch count :" + records.size());

		model.put("records", records);
		model.put("industry", JobCategory);

		return new ModelAndView(new BusinesMonstarExcelBuilder(), "records", records);

	}
	

	@RequestMapping(value = "/userNaukriJobDownload", method = RequestMethod.GET)
	public ModelAndView userNaukriJobDownload(@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "pageSize",required = false, defaultValue = "7000") int pageSize,
				@RequestParam("jobCategory") String jobCategory,
			@RequestParam("passout") String passout, Map<String, Object> model) {


		Map<String, Object> lNauk= userServiceImpl.filterNaukriJobRecords( page, pageSize ,jobCategory ,  passout);
							
		LOGGER.info("Total records fetch count :" + lNauk.size());

		List<CandidateRecords> cadRec = (List<CandidateRecords>) lNauk.get("records");
		
	//	model.put("records", cadRec);
		model.put("industry", jobCategory);

		return new ModelAndView(new BusinessNaukrijobExcelpass(), "records", cadRec);

	}
	
	


}
