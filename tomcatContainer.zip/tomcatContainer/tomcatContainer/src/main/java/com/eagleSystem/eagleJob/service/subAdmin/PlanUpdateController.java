package com.eagleSystem.eagleJob.service.subAdmin;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.eagleSystem.eagleJob.dao.AccountRepository;
import com.eagleSystem.eagleJob.dao.BDMRecruiterRepository;
import com.eagleSystem.eagleJob.dao.CompanyRepository;
import com.eagleSystem.eagleJob.dao.CustomerSubAdminRepository;
import com.eagleSystem.eagleJob.dao.DBCustomerRepository;
import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.dao.MasterPlanRepository;
import com.eagleSystem.eagleJob.dao.PlanUpdateRecordRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.dao.SubAdminRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.Company;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import com.eagleSystem.eagleJob.entity.MasterPlan;
import com.eagleSystem.eagleJob.entity.PlanUpdateRecord;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;

@Controller
public class PlanUpdateController {

	@Autowired
	SubAdminRepository subAdminRepository;

	@Autowired
	AccountRepository accountRepository;

	@Autowired
	BDMRecruiterRepository bdmRecuiterRepository;

	@Autowired
	CustomerSubAdminRepository customerSubAdminRepository;

	@Autowired
	DBCustomerRepository dbCustomerRepository;

	@Autowired
	RecruiterRepository recruiterRepository;

	@Autowired
	JPUserRepository jpUserRepository;

	@Autowired
	PlanUpdateRecordRepository planUpdateRecordRepository;
	
	@Autowired
	SubAdminServiceImpl subAdminServiceImpl;
	
	@Autowired
	CompanyRepository companyRepositry;
	
	@Autowired
	MasterPlanRepository masterPlanRepository;
	
	
	
	@PutMapping("/subadminUpdateAccount")
	public boolean updateAccount(@ModelAttribute @Valid Account accountupdate) throws Exception {

		boolean flag = true;

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		try {
			if (authentication == null) {
				throw new Exception("Invalid User");
			}

			Account account = accountRepository.findOne(accountupdate.getId());

			if (account != null) {

				account = accountmaper(account, accountupdate);

				accountRepository.save(accountupdate);
				updatePlan(accountupdate.getId(), authentication.getName());
				
				subAdminServiceImpl.updateSubAdmin(authentication.getName());
			}
			else {
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}

	@PutMapping("/subadminUpdateCustomer")
	public boolean update(@ModelAttribute @Valid DbCustomerEntity customerEntity) throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

			boolean flag = true;

		try {
			if (authentication == null) {
				throw new Exception("Invalid User");
			}

			DbCustomerEntity customer = dbCustomerRepository.findOne(customerEntity.getId());
			
			if (customer != null) {

				customer = maperCustomer(customer, customerEntity);

				dbCustomerRepository.save(customer);
				updatePlan(customerEntity.getId(), authentication.getName());
				subAdminServiceImpl.updateSubAdmin(authentication.getName());
			}
			else {
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}
	
	
	@PutMapping("/subadminUpdateRecruiter")
	public boolean updateRecruiter(@ModelAttribute @Valid RecruiterRegistrationRequest recruiterEntty) throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

			boolean flag = true;

		try {
			if (authentication == null) {
				throw new Exception("Invalid User");
			}

			Recruiter recuiter = recruiterRepository.findOne(recruiterEntty.getRecruiterId());
			Company company = companyRepositry.findOne(recruiterEntty.getRecruiterId());
	//		DbCustomerEntity customer = dbCustomerRepository.findOne(customerEntity.getId());
			
			if (recuiter != null && company != null) {

				recuiter = mapRecruiter(recuiter, recruiterEntty);
				company = mapCompany(company, recruiterEntty);
				
				recruiterRepository.save(recuiter);
				companyRepositry.save(company);
				subAdminServiceImpl.updateSubAdmin(authentication.getName());
			}
			else {
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}
	
	
	@GetMapping(value = "/subAdminRecruiterPlan", params = {"applicatoin/json"})
	public @ResponseBody List<MasterPlan> getMasterPlanDetail() {
		
		return masterPlanRepository.findAll();
		
	}
	
	
	@PutMapping("/subadminUpdateRecruiterPlan")
	public boolean updateRecruiter(@RequestParam("id") Long id, @RequestParam("planId") Long planId) throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

			boolean flag = true;

		try {
			if (authentication == null) {
				throw new Exception("Invalid User");
			}

			Recruiter recuiter = recruiterRepository.findOne(id);
			MasterPlan masterPlan = masterPlanRepository.findOne(planId);
			
			if (recuiter != null && masterPlan != null) {

				recuiter.setMasterPlan(masterPlan);
				recruiterRepository.save(recuiter);
				subAdminServiceImpl.updateSubAdmin(authentication.getName());
			}
			else {
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}
	
	
	private Company mapCompany(Company company, RecruiterRegistrationRequest recruiterEntity) {
		
			company.setName(recruiterEntity.getCompanyName());
			company.setType(recruiterEntity.getCompanyType());
			company.setGSTNO(recruiterEntity.getGSTNO());
			company.setCity(recruiterEntity.getCity());
			company.setState(recruiterEntity.getState());
			company.setAddress(recruiterEntity.getCompanyAddress());
		
		return company;
	}

	private Recruiter mapRecruiter(Recruiter recruiter, RecruiterRegistrationRequest recruiterEntity) {
		
			recruiter.setName(recruiterEntity.getRecruiterName());
			recruiter.setEmail(recruiterEntity.getEmail());
			recruiter.setDesignation(recruiterEntity.getDesignation());
			recruiter.setMobNo(recruiterEntity.getMobNo());
			recruiter.setUsername(recruiterEntity.getUsername());		
		return recruiter;
	}

	public boolean updatePlan(Long id, String user) {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		boolean flag = true;
	
		try {

			PlanUpdateRecord record = new PlanUpdateRecord();
			
			record.setHrId(id);
			record.setUpdateDate(new Date());
			record.setRole(user);
			
				planUpdateRecordRepository.save(record);
				subAdminServiceImpl.updateSubAdmin(authentication.getName());
				
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}

	public DbCustomerEntity maperCustomer(DbCustomerEntity customer, DbCustomerEntity customerEntity) {

		customer.setCity(customerEntity.getCity());
		customer.setCompanyName(customerEntity.getCompanyName());
		customer.setCompanyType(customerEntity.getCompanyType());
		customer.setContactNumber(customerEntity.getContactNumber());
		customer.setCustomerName(customerEntity.getCompanyName());
		customer.setEmailId(customerEntity.getEmailId());
		customer.setExcelDataUsed(customerEntity.getExcelDataUsed());
		customer.setExcelLimit(customerEntity.getExcelLimit());
		customer.setId(customerEntity.getId());
		customer.setPassword(customerEntity.getPassword());
		customer.setResumeDataUsed(customerEntity.getResumeDataUsed());
		customer.setResumeLimit(customerEntity.getResumeLimit());
		customer.setState(customerEntity.getState());
		customer.setStatus(customerEntity.getStatus());
		customer.setUsername(customerEntity.getUsername());
		customer.setValadity(customerEntity.getValadity());

		return customer;

	}

	private Account accountmaper(Account account, Account accountupdate) {

		account.setContactNumber(accountupdate.getContactNumber());
		account.setEmail(accountupdate.getEmail());
		account.setExcelLimit(accountupdate.getExcelLimit());
		account.setId(accountupdate.getId());
		account.setLoaction(accountupdate.getLoaction());
		account.setName(accountupdate.getName());
		account.setPassword(accountupdate.getPassword());
		account.setRecruiterLimitPerDay(accountupdate.getRecruiterLimitPerDay());
		account.setResumeLimit(accountupdate.getResumeLimit());
		account.setTarget(accountupdate.getTarget());
		account.setUsername(accountupdate.getUsername());

		return account;
	}

}
