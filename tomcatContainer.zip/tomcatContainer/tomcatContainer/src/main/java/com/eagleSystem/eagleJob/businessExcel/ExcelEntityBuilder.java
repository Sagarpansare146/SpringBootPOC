package com.eagleSystem.eagleJob.businessExcel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.entity.MonsterExcelRecord;
import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;
import com.eagleSystem.eagleJob.entity.ShineExcelRecord;
import com.eagleSystem.eagleJob.entity.TimesExcelRecord;
import com.eagleSystem.eagleJob.entity.ClientNaukriExcelRecord;

@Component
public class ExcelEntityBuilder {
	
	@Autowired
	ExcelExtactor excelExtactor;
	
	public List buildNaukriRecordObj(Iterator<Row> rowIterator, String jobCategory) {

		int j = 1;
		List list = new ArrayList();
		
		for (int i= 0; i <= 4; i++) {
			System.out.println(i);
			rowIterator.next();
			
		}
		while (rowIterator.hasNext()) {

			List obj = new ArrayList();
			// For each row, iterate through each columns

			
			Row row = rowIterator.next();

			System.out.println(j);
			j++;
			
			
			
			NaukriExcelRecord nXlsRec = new NaukriExcelRecord();

			obj = excelExtactor.extractCellData(row);
			
			if(obj != null)
			{
			if(obj.size() < 22) {
				continue;
			}
			}
			
		//	nXlsRec.setSno((long) row.getCell(0).getNumericCellValue());
			nXlsRec.setName((String) obj.get(1));
			nXlsRec.setGender((String) obj.get(2));
			nXlsRec.setPostalAddress((String) obj.get(3));
			nXlsRec.setMobile((String) obj.get(4));
			nXlsRec.setTelephone((String) obj.get(5));
			
			
			nXlsRec.setDob((String) obj.get(6));
			nXlsRec.setEmailID((String) obj.get(7));
			nXlsRec.setDateOfApply((String) obj.get(8));
			nXlsRec.setTotalExperience((String) obj.get(9));
			nXlsRec.setStatus((String) obj.get(10));
			nXlsRec.setResumeTitle((String) obj.get(11));
			nXlsRec.setKeySkills((String) obj.get(12));
			nXlsRec.setFunctionalArea((String) obj.get(13));
			nXlsRec.setCurrentLocation((String) obj.get(14));
			nXlsRec.setPreferredLocations((String) obj.get(15));
			nXlsRec.setCurrentEmployer((String) obj.get(16));
			nXlsRec.setCurrentDesignation((String) obj.get(17));
			nXlsRec.setAnnualSalary((String) obj.get(18));
			nXlsRec.setUgCourse((String) obj.get(19));
			nXlsRec.setUgSpecialization((String) obj.get(20));
			nXlsRec.setUgInstitute((String) obj.get(21));
			nXlsRec.setJobCategory(jobCategory);
			if (nXlsRec != null)
				list.add(nXlsRec);
		}

		return list;
	}
	
	public List buildTimesRecordObj(Iterator<Row> rowIterator, String jobCategory) {

		int j = 1;
		List list = new ArrayList();
		
		for (int i= 0; i <= 4; i++) {
			System.out.println(i);
			rowIterator.next();
			
		}
		while (rowIterator.hasNext()) {

			List obj = new ArrayList();
			// For each row, iterate through each columns

			
			Row row = rowIterator.next();

			System.out.println(j);
			j++;
			
			
			
			TimesExcelRecord tXlsRec = new TimesExcelRecord();

			obj = excelExtactor.extractCellData(row);
				
			if(obj != null)
			{
			if(obj.size() < 6) {
				continue;
			}
			}
			
		//	tXlsRec.setSno((long) row.getCell(0).getNumericCellValue());
			tXlsRec.setName((String) obj.get(0));
			tXlsRec.setEmailId((String) obj.get(1));
			tXlsRec.setMobileNo((String) obj.get(2));
			tXlsRec.setResumeTitle((String) obj.get(3));
			tXlsRec.setWorkExperience((String) obj.get(4));
			
			
			tXlsRec.setCourseHighestEducation((String) obj.get(5));
			
			tXlsRec.setJobCategory(jobCategory);
			if (tXlsRec != null)
				list.add(tXlsRec);
		}

		return list;
	}
	
	public List buildShineRecordObj(Iterator<Row> rowIterator, String jobCategory) {

		int j = 1;
		List list = new ArrayList();
		
		for (int i= 0; i <= 5; i++) {
			System.out.println(i);
			rowIterator.next();
			
		}
		while (rowIterator.hasNext()) {

			List obj = new ArrayList();
			// For each row, iterate through each columns

			
			Row row = rowIterator.next();

			System.out.println(j);
			j++;
			
			
			
			ShineExcelRecord sXlsRec = new ShineExcelRecord();

			obj = excelExtactor.excelShineCell(row);
				
			if(obj != null)
			{
			if(obj.size() < 19) {
				continue;
			}
			}
			
		//	sXlsRec.setSno((long) row.getCell(0).getNumericCellValue());
			sXlsRec.setCandidateName((String) obj.get(1));
			sXlsRec.setDob((String) obj.get(2));
			sXlsRec.setEmailID((String) obj.get(3));
			sXlsRec.setContactNumber((String) obj.get(4));
			sXlsRec.setCurrentLocation((String) obj.get(5));
			
			
			sXlsRec.setGender((String) obj.get(6));
			sXlsRec.setTotalWorkExperience((String) obj.get(7));
			sXlsRec.setCurrentAnnualSalary((String) obj.get(8));
			sXlsRec.setCurrentJobTitle((String) obj.get(9));
			sXlsRec.setCurrentFunctionalArea((String) obj.get(10));
			sXlsRec.setCurrentIndustry((String) obj.get(11));
			sXlsRec.setCurrentCompany((String) obj.get(12));
			sXlsRec.setYearsinCurrentJob((String) obj.get(13));
			sXlsRec.setNoticePeriod((String) obj.get(14));
			sXlsRec.setHighestEducationLevel((String) obj.get(15));
			sXlsRec.setHighestEducationStream((String) obj.get(16));
			sXlsRec.setHighestEducationInstitute((String) obj.get(17));
			sXlsRec.setYearOfPassing((String) obj.get(18));
			
			sXlsRec.setJobCategory(jobCategory);
			
			if (sXlsRec != null)
				list.add(sXlsRec);
		}

		return list;
	}
	
	public List buildMosterRecordObj(Iterator<Row> rowIterator, String jobCategory) {

		int j = 1;
		List list = new ArrayList();
		
		for (int i= 0; i <= 4; i++) {
			System.out.println(i);
			rowIterator.next();
			
		}
		while (rowIterator.hasNext()) {

			List obj = new ArrayList();
			// For each row, iterate through each columns

			
			Row row = rowIterator.next();

			System.out.println(j);
			j++;
			
			
			
			MonsterExcelRecord mXlsRec = new MonsterExcelRecord();

			obj = excelExtactor.extractCellData(row);
				
			if(obj != null)
			{
			if(obj.size() < 24) {
				continue;
			}
			}
			
		//	mXlsRec.setSno((long) row.getCell(0).getNumericCellValue());
			mXlsRec.setName((String) obj.get(1));
			mXlsRec.setDateofBirth((String) obj.get(2));
			mXlsRec.setResumeTitle((String) obj.get(3));
			mXlsRec.setEducation((String) obj.get(4));
			mXlsRec.setExperienceInYears((String) obj.get(5));
			
			
			mXlsRec.setCurrentEmployer((String) obj.get(6));
			mXlsRec.setPreviousEmployer((String) obj.get(7));
			mXlsRec.setKeySkills((String) obj.get(8));
			mXlsRec.setCurrentLocation((String) obj.get(9));
			mXlsRec.setNationality((String) obj.get(10));
			mXlsRec.setWorkAuthorization((String) obj.get(11));
			mXlsRec.setCategory((String) obj.get(12));
			mXlsRec.setRoles((String) obj.get(13));
			mXlsRec.setIndustry((String) obj.get(14));
			mXlsRec.setStatus((String) obj.get(15));
			mXlsRec.setSource((String) obj.get(16));
			mXlsRec.setReceivedDate((String) obj.get(17));
			mXlsRec.setAddress((String) obj.get(18));
			mXlsRec.setEmail((String) obj.get(19));
			mXlsRec.setPhone((String) obj.get(20));
			mXlsRec.setMobile((String) obj.get(21));
			mXlsRec.setMobileVerified((String) obj.get(22));
			mXlsRec.setCurrentAnnualSalary((String) obj.get(23));
			mXlsRec.setJobCategory(jobCategory);
			
			if (mXlsRec != null)
				list.add(mXlsRec);
		}

		return list;
	}
	public List buildClientNaukriRecordObj(Iterator<Row> rowIterator, String jobCategory) {

		int j = 1;
		List list = new ArrayList();
		
		for (int i= 0; i <= 4; i++) {
			System.out.println(i);
			rowIterator.next();
			
		}
		while (rowIterator.hasNext()) {

			List obj = new ArrayList();
			// For each row, iterate through each columns

			
			Row row = rowIterator.next();

			System.out.println(j);
			j++;
			
			
			
			ClientNaukriExcelRecord nXlsRec = new ClientNaukriExcelRecord();

			obj = excelExtactor.extractCellData(row);
			
			if(obj != null)
			{
			if(obj.size() < 22) {
				continue;
			}
			}
			
		//	nXlsRec.setSno((long) row.getCell(0).getNumericCellValue());
			nXlsRec.setName((String) obj.get(1));
			nXlsRec.setGender((String) obj.get(2));
			nXlsRec.setPostalAddress((String) obj.get(3));
			nXlsRec.setMobile((String) obj.get(4));
			nXlsRec.setTelephone((String) obj.get(5));
			
			
			nXlsRec.setDob((String) obj.get(6));
			nXlsRec.setEmailID((String) obj.get(7));
			nXlsRec.setDateOfApply((String) obj.get(8));
			nXlsRec.setTotalExperience((String) obj.get(9));
			nXlsRec.setStatus((String) obj.get(10));
			nXlsRec.setResumeTitle((String) obj.get(11));
			nXlsRec.setKeySkills((String) obj.get(12));
			nXlsRec.setFunctionalArea((String) obj.get(13));
			nXlsRec.setCurrentLocation((String) obj.get(14));
			nXlsRec.setPreferredLocations((String) obj.get(15));
			nXlsRec.setCurrentEmployer((String) obj.get(16));
			nXlsRec.setCurrentDesignation((String) obj.get(17));
			nXlsRec.setAnnualSalary((String) obj.get(18));
			nXlsRec.setUgCourse((String) obj.get(19));
			nXlsRec.setUgSpecialization((String) obj.get(20));
			nXlsRec.setUgInstitute((String) obj.get(21));
			nXlsRec.setJobCategory(jobCategory);
			if (nXlsRec != null)
				list.add(nXlsRec);
		}

		return list;
	}

}
