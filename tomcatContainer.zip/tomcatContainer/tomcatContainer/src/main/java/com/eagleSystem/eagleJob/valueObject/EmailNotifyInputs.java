package com.eagleSystem.eagleJob.valueObject;

import org.springframework.web.multipart.MultipartFile;

public class EmailNotifyInputs {
	
	private MultipartFile file;
	private MultipartFile attchFile; 
	private String subject;
	private String message;
	private String senderName;
	private String from;

	public MultipartFile getFile() {
		return file; 
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public MultipartFile getAttchFile() {
		return attchFile;
	}

	public void setAttchFile(MultipartFile attchFile) {
		this.attchFile = attchFile;
	}

	@Override
	public String toString() {
		return "EmailNotifyInputs [file=" + file + ", subject=" + subject + ", message=" + message + ", senderName="
				+ senderName + ", from=" + from + "]";
	}
	
	

}
