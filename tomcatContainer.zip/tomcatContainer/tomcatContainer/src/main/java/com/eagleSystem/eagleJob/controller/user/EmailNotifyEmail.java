package com.eagleSystem.eagleJob.controller.user;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.internet.InternetAddress;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.eagleSystem.eagleJob.businessExcel.ExcelEntityBuilder;
import com.eagleSystem.eagleJob.businessExcel.ExcelRecordsBusiness;
import com.eagleSystem.eagleJob.businessExcel.ExcelToDb;
import com.eagleSystem.eagleJob.businessExcel.ZipFilteredReader;
import com.eagleSystem.eagleJob.bussinessObject.Email;
import com.eagleSystem.eagleJob.service.EmailService;
import com.eagleSystem.eagleJob.service.ExcelRecordsImpl;
import com.eagleSystem.eagleJob.service.ExcelRecordsToDbImpl;
import com.eagleSystem.eagleJob.util.EmailTemplate;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.EmailNotifyInputs;

@Controller
public class EmailNotifyEmail {

	@Autowired
	EmailService emailService;

	@Autowired
	ExcelRecordsImpl excelRecord;

	@Autowired
	ExcelRecordsToDbImpl excelRecordsToDb;

	@Autowired
	ExcelRecordsBusiness excelRecordsBusiness;

	public static final String A = "Naukri";
	public static final String B = "Shine";
	public static final String C = "Monster";
	public static final String D = "TimesJob";
	public static final String E = "client";
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ExcelRecordsBusiness.class);

	@Autowired
	ExcelEntityBuilder excelEntityBuilder;

	@Autowired
	ExcelToDb excelToDb;

	@Autowired
	ZipFilteredReader zipFilteredReader;

	@RequestMapping("/userSendMail")
	public String emailNotify(HttpServletRequest request, HttpServletResponse response, EmailNotifyInputs inputs,
			Model model) {

		System.out.println(inputs);
		List<String> ids = null;
		int count = 0;
		try {
			ids = excelRecord.excel(request, response, inputs);
		} catch (Exception e) {

			ids = new ArrayList<>();
			e.printStackTrace();
		}

		if (!(ids == null)) {
			count = ids.size();
			System.out.println("Total no of records : " + ids.size());
			emailSender(ids, inputs.getSubject(), inputs.getSenderName(), inputs.getMessage(), inputs.getFrom());

		} else {
			System.out.println("Total no of records : " + count);

		}

		model.addAttribute("request", ids);
		model.addAttribute("count", count);
		return ViewMapper.USER_USER_SENDMAIL;
	}

	@Async
	public void emailSender(List<String> emailIds, String subject, String senderName, String message, String from) {

		System.out.println(emailIds);
		InternetAddress ia = new InternetAddress();
		ia.setAddress(from);

		Email email1 = new Email();

		int success = 0;
		int failed = 0;

		for (String emailId : emailIds) {
			List<String> toList = new ArrayList<>();
			toList.add(emailId);
			try {
				email1.setTo(toList);
				email1.setSubject(subject);
				email1.setMessage(message);
				email1.setFrom(ia);

				emailService.sendPlainTextMail(email1, senderName, from);
				success = success + 1;

			} catch (Exception e) {
				e.printStackTrace();
				failed = failed + 1;
			}
		}

		System.out.println("Total Email successfully send : " + success);
		System.out.println("Total Email failed : " + failed);

	}

	@RequestMapping("/useruploadExcel")
	public String uploadFile(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("file") MultipartFile file, @RequestParam("jobCatagory") String jobCatagory) {

		System.out.println(jobCatagory);

		try {
			excelRecordsToDb.excel(request, response, file, jobCatagory);
		} catch (Exception e) {

			e.printStackTrace();
			return "other/error";
		}

		return ViewMapper.USER_USER_UPLOADEXCEL;

	}

	@GetMapping("/useruploadPage")
	public String uploadBusinessExcel() {
		return ViewMapper.USER_USER_FITCHDATA;
	}

	@PostMapping("/useruploadPage")
	public String uploadBusinessExcel(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("file") MultipartFile file, @RequestParam("jobCatagory") String jobCategory,
			@RequestParam("domain") String domain) {

		System.out.println(domain);

		try {
			upload(request, response, file, domain, jobCategory);
		} catch (Exception e) {

			e.printStackTrace();
			return "error";
		}

		return ViewMapper.USER_USER_FITCHDATA;
	}

	public List upload(HttpServletRequest request, HttpServletResponse response, MultipartFile file, String domain,
			String JobCategory) throws Exception {

		String filePath = "";
		List ids = null;

		filePath = excelRecordsBusiness.fileReader(request, response, file);

		File file1 = new File(filePath);

		String inputFilename = file1.getName();

		switch (inputFilename.substring(inputFilename.lastIndexOf(".") + 1, inputFilename.length())) {
		case "xls":
			ids = excelRecordsBusiness.excel(filePath, domain, JobCategory);
			break;
		case "xlsx":
			ids = excelRecordsBusiness.excel(filePath, domain, JobCategory);
			break;
		case "zip":
			ids = zip(filePath, domain, JobCategory);
			break;
		default:
			System.out.println("Please select valid \"Excel\" File\"");
		}

		return ids;
	}

	public List zip(String filePath, String domain, String JobCategory) throws Exception {

		List ids = null;

		Path outputDirectory = Paths.get("c:/test/zip");
		Path zipLocation = Paths.get(filePath);

		try {
			ids = zipFilteredReader.extractor(zipLocation, outputDirectory, domain, JobCategory);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ids;
	}

}
