package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.eagleSystem.eagleJob.entity.ClientNaukriExcel;
import com.eagleSystem.eagleJob.entity.ClientNaukriExcelRecord;



public  interface ClientNaukriRepository extends JpaRepository<ClientNaukriExcelRecord, Long> , JpaSpecificationExecutor<ClientNaukriExcelRecord> {

	List<ClientNaukriExcel> findByJobCategory(String jobCategory);

	List<ClientNaukriExcelRecord> findByGenderAndJobCategoryAndPreferredLocationsAndTotalExperienceContaining(String gender, String jobCategory, String preferredLocation, String TotalExperience);
	List<ClientNaukriExcelRecord> findByGenderAndJobCategoryAndPreferredLocations(String gender, String jobCategory, String preferredLocation);
	List<ClientNaukriExcelRecord> findByGenderAndJobCategory(String gender, String jobCategory);
	List<ClientNaukriExcelRecord> findByGender(String gender);
	List<ClientNaukriExcelRecord> findByCurrentLocation(String currentLocation);
	List<ClientNaukriExcelRecord> findByannualSalary(String annualSalary);
	
	
	List<ClientNaukriExcel> findByJobCategoryAndPreferredLocationsContaining(String jobCategory, String location);
	
	@Query("SELECT DISTINCT p.preferredLocations FROM ClientNaukriExcelRecord p")
	List<String> findDistinctCity();
	
	@Query("SELECT DISTINCT p.currentLocation FROM ClientNaukriExcelRecord p")
	List<String> findDistinctCurrentLocation();

	@Query("SELECT DISTINCT p.annualSalary FROM ClientNaukriExcelRecord p")
	List<String> findDistinctannualSalary();

	@Query("SELECT DISTINCT p.jobCategory FROM ClientNaukriExcelRecord p")
	List<String> findDistinctJobCategory();

	@Query("SELECT DISTINCT p.keySkills FROM ClientNaukriExcelRecord p")
	List<String> findDistinctKeySkills();

	@Query("SELECT DISTINCT p.ugCourse FROM ClientNaukriExcelRecord p")
	List<String> findDistinctUgCourse();

	@Query("SELECT p.resumePath FROM ClientNaukriExcelRecord p where id in (:ids)")
	List<String> getResumePath(@Param("ids") Long ids[]);
	
	/*@Override
	default boolean exists(Predicate predicate) {
		return (findOne(predicate) != null ? true : false);
	}
	*/
	
	ClientNaukriExcelRecord findByEmailIDContaining(String emailid);
	
	/*@Override
	default long count(Predicate predicate) {	
		return ((List<NaukriExcelRecord>) findAll(predicate)).size();
	}
	*/
	
	ClientNaukriExcelRecord findByNameAndCurrentLocationContainsAndDob(String name, String loc, String Dob); 
	 
	ClientNaukriExcelRecord findByNameAndCurrentLocationContains(String name, String loc); 
	 
	
	/* @Query("SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END FROM NaukriExcelRecord c WHERE c.name = :companyName")
	 boolean existsByName(@Param("companyName") String companyName);
	 */
//	Iterable<NaukriExcelRecord> findAll(Predicate predicate);
	
	
}
