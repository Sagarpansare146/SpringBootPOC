package com.eagleSystem.eagleJob.recruiter;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.service.JobService;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.JobPostRequest;

@Controller
public class RecruiterPostJobController {

	static final String POST_JOB_MODEL = "request";

	@Autowired
	JobService jobService;

	@Autowired
	RecruiterService recruiterService;

	@GetMapping(value = URLMapper.RECRUITER_JOB_POST)
	public String loadPostJobPage(Model model) {
		
		model.addAttribute(POST_JOB_MODEL, new JobPostRequest());
		return ViewMapper.RECRUITER_JOB_POST;
	}

	@RequestMapping(value = URLMapper.RECRUITER_JOB_POST , method = RequestMethod.POST, produces = {"application/json"})
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jPostJob(@RequestBody @ModelAttribute(POST_JOB_MODEL) @Valid JobPostRequest job, BindingResult result, Model model,
			HttpServletRequest request,Authentication auth) {

		boolean flag = false;
		
		flag = jobService.postNewJob(auth.getName(), job);
		
		return flag;
	}
	
	@RequestMapping(value = URLMapper.RECRUITER_JOB_POST, method = RequestMethod.POST)
	public String postJob(@ModelAttribute(POST_JOB_MODEL) @Valid JobPostRequest job, BindingResult result, Model model,
			HttpServletRequest request,Authentication auth) {

		
		// validate the job entry
		if (result.hasErrors()) {
			// the errors will automatically get mapped to form:errors path = ""
			return ViewMapper.RECRUITER_JOB_POST;
		}
		
		
		boolean flag = false;
		boolean error = false;
		try {
			flag = jPostJob(job, result, model, request, auth);
		}catch(Throwable t) {
			t.printStackTrace();
			model.addAttribute("error", "Unable to post new Job");
			error = true;
		}

		
		if(error) {
			return "error";
			
		}
		
		if(!flag) {
			return ViewMapper.RECRUITER_JOB_POST;
		}
		
		model.addAttribute("message", "success");
		return "redirect:" + URLMapper.RECRUITER_POSTED_JOBS;
	}
	
}