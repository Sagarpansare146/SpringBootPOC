package com.eagleSystem.eagleJob.controller.bdm;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.businessExcel.NaukriDownloadRecord;
import com.eagleSystem.eagleJob.dao.BDMRecruiterRepository;
import com.eagleSystem.eagleJob.dao.DBCustomerRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import com.eagleSystem.eagleJob.service.bdm.BdmServiceImpl;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.service.bdm.BDMRecruiterRegService;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.FilterInput;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;

@Controller
public class BDMRecruiterRegController {
	
	@Autowired
	RecruiterService recruiterService; 
	
	@Autowired
	RecruiterRepository recruiterRepository;
	
	@Autowired
	BDMRecruiterRepository bdmRecruiterRepository;
	
	
	@Autowired
	DBCustomerRepository dBCustomerRepository;

	@Autowired
	BdmServiceImpl bdmServiceImpl;
	
	@Autowired
	BDMRecruiterRegService bdmRecruiterRegService;
	
	@Autowired
	NaukriDownloadRecord naukriDownloadRecord;

	
	@GetMapping(URLMapper.BDM_DB_CUSTOMER_REGISTRATION)
	public String bdmDatabaseReg(Model model) {
		
		model.addAttribute("request", new DbCustomerEntity());
		return ViewMapper.BDM_BDM_DATABASEREG;
	}
	
	@PostMapping(value = URLMapper.BDM_DB_CUSTOMER_REGISTRATION )
	public String registrationRecruiter(@ModelAttribute @Valid DbCustomerEntity request, Model model) {
		boolean flag = true;
		
		flag = jRegisterDbCustomer(request);
		if(!flag) {
			return "error";
		}
		
		model.addAttribute("location", naukriDownloadRecord.getLocations());
		model.addAttribute("qualification", naukriDownloadRecord.getQualification());
		model.addAttribute("jobCategory", naukriDownloadRecord.getJobCategory());
		
//		model.addAttribute("experience", IntStream.range(1, 20).boxed().map(i -> String.valueOf(i) + " Year(s)").collect(Collectors.toSet()));
//		model.add
		model.addAttribute("abc", new FilterInput());
		
		return ViewMapper.BDM_BDM_SILVER_SERVER;
	}
	
	@PostMapping(value = URLMapper.BDM_DB_CUSTOMER_REGISTRATION , produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jRegisterDbCustomer(@RequestBody @ModelAttribute @Valid DbCustomerEntity request) {
		
		boolean flag = true;
		
		try {
			flag = bdmServiceImpl.dbCustomerReg(request);
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		
		return flag;
	}
	
	@GetMapping("/bdmdemoReg")
	public String bdmdemoReg(Model model) {
		
		model.addAttribute("request", new RecruiterRegistrationRequest());
		return ViewMapper.BDM_BDM_DEMOREG;
	}
	
	@PostMapping(value = URLMapper.BDM_RECRUITER_REGISTRATION )
	public String registrationRecruiter(@ModelAttribute @Valid RecruiterRegistrationRequest request) {
		boolean flag = true;
		
		flag = jRegisterRecruiter(request);
		if(!flag) {
			return "error";
		}
		
		
		return ViewMapper.BDM_BDM_POSTINGREPORT;
	}
	
	
	@PostMapping(value = URLMapper.BDM_RECRUITER_REGISTRATION , produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jRegisterRecruiter(@RequestBody @ModelAttribute @Valid RecruiterRegistrationRequest request) {
		
		boolean flag = false;
	try {	
		flag = bdmRecruiterRegService.registerRecruiter(request);
	}catch (Exception e) {
		e.printStackTrace();
	}
		return flag;
	}
	

	
}
