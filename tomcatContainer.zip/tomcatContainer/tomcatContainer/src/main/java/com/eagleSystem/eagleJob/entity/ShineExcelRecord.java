package com.eagleSystem.eagleJob.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "SHINE_EXCEL_DATA", uniqueConstraints = {@UniqueConstraint(columnNames={"EmailID"})})
public class ShineExcelRecord {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	private String candidateName;
	private String dob;
	private String emailID;
	private String contactNumber;
	private String currentLocation;
	private String gender;
	private String totalWorkExperience;
	private String currentAnnualSalary;
	private String currentJobTitle;
	private String currentFunctionalArea;
	private String currentIndustry;
	private String currentCompany;
	private String yearsinCurrentJob;
	private String noticePeriod;
	private String highestEducationLevel;
	private String highestEducationStream;
	private String highestEducationInstitute;
	private String yearOfPassing;
	
	private String jobCategory;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCandidateName() {
		return candidateName;
	}

	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getTotalWorkExperience() {
		return totalWorkExperience;
	}

	public void setTotalWorkExperience(String totalWorkExperience) {
		this.totalWorkExperience = totalWorkExperience;
	}

	public String getCurrentAnnualSalary() {
		return currentAnnualSalary;
	}

	public void setCurrentAnnualSalary(String currentAnnualSalary) {
		this.currentAnnualSalary = currentAnnualSalary;
	}

	public String getCurrentJobTitle() {
		return currentJobTitle;
	}

	public void setCurrentJobTitle(String currentJobTitle) {
		this.currentJobTitle = currentJobTitle;
	}

	public String getCurrentFunctionalArea() {
		return currentFunctionalArea;
	}

	public void setCurrentFunctionalArea(String currentFunctionalArea) {
		this.currentFunctionalArea = currentFunctionalArea;
	}

	public String getCurrentIndustry() {
		return currentIndustry;
	}

	public void setCurrentIndustry(String currentIndustry) {
		this.currentIndustry = currentIndustry;
	}

	public String getCurrentCompany() {
		return currentCompany;
	}

	public void setCurrentCompany(String currentCompany) {
		this.currentCompany = currentCompany;
	}

	public String getYearsinCurrentJob() {
		return yearsinCurrentJob;
	}

	public void setYearsinCurrentJob(String yearsinCurrentJob) {
		this.yearsinCurrentJob = yearsinCurrentJob;
	}

	public String getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
	}

	public String getHighestEducationLevel() {
		return highestEducationLevel;
	}

	public void setHighestEducationLevel(String highestEducationLevel) {
		this.highestEducationLevel = highestEducationLevel;
	}

	public String getHighestEducationStream() {
		return highestEducationStream;
	}

	public void setHighestEducationStream(String highestEducationStream) {
		this.highestEducationStream = highestEducationStream;
	}

	public String getHighestEducationInstitute() {
		return highestEducationInstitute;
	}

	public void setHighestEducationInstitute(String highestEducationInstitute) {
		this.highestEducationInstitute = highestEducationInstitute;
	}

	public String getYearOfPassing() {
		return yearOfPassing;
	}

	public void setYearOfPassing(String yearOfPassing) {
		this.yearOfPassing = yearOfPassing;
	}

	public String getJobCategory() {
		return jobCategory;
	}

	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}
	
	
	
}
