package com.eagleSystem.eagleJob.service.bdm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.dao.BDMRecruiterRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.BDMRecuiterEntity;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;

@Component
public class BDMRecruiterRegService {
	
	@Autowired
	RecruiterService recruiterService;
	
	@Autowired
	BDMRecruiterRepository bdmRecruiterRepository;
	
	@Autowired
	RecruiterRepository recruiterRepository;
	
	
	public boolean registerRecruiter(RecruiterRegistrationRequest request) throws Exception {
		
		boolean flag = true;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		
		if( authentication == null ) {
			throw new Exception("Invalid BDM");
		}
		
		flag = recruiterService.regRecruiter(request);
		
		if(flag) {
			bdmRecruiterRepository.save(new BDMRecuiterEntity(recruiterRepository.findByUsername(request.getUsername()).getId(), authentication.getName(), "pending"));
		}
		
		return flag;
	}

	
}