package com.eagleSystem.eagleJob.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import java.lang.String;

public interface DBCustomerRepository extends JpaRepository<DbCustomerEntity, Long> {

	DbCustomerEntity findByUsername(String username);
	
	
}
