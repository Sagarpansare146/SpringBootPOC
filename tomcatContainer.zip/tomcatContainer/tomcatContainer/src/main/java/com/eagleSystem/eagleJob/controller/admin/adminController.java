package com.eagleSystem.eagleJob.controller.admin;


import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.aspect.JobPostAspect;
import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.SubAdmin;
import com.eagleSystem.eagleJob.service.Admin.AdminServiceImpl;
import com.eagleSystem.eagleJob.service.subAdmin.SubAdminServiceImpl;
import com.eagleSystem.eagleJob.util.ResumeUtil;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;

import com.eagleSystem.eagleJob.valueObject.CreateSubadmin;

@Controller
public class adminController {

	
	private static final Logger LOGGER = LoggerFactory.getLogger(JobPostAspect.class);
	@Autowired
	SubAdminServiceImpl subAdminServiceImpl;
	
	@Autowired
	NaukriExcelRepository naukriExcelRepository;

	@Autowired
	ResumeUtil resumeUtil;
	
	@Autowired
	AdminServiceImpl adminService;
	
	
	
	@RequestMapping("/adminIndex")
	public String adminIndex(Model model) {
		
	model.addAttribute("candidateCount", adminService.getCount());
	model.addAttribute("UserAccountCount", adminService.getUser());
	model.addAttribute("subadminAccountCount", adminService.getsubadmin());
	model.addAttribute("bdmAccountCount", adminService.bdmAccount());
	model.addAttribute("dbCustomerCount", adminService.dbCustomer());
	model.addAttribute("getRecruitersCount", adminService.getRecruiters());
	model.addAttribute("getRecruitersCount", adminService.getRecruiters());
	model.addAttribute("getClientnaukriCount", adminService.getClientNaukriCount());
	
		model.addAttribute("naukriCount", adminService.getNaukriCount());
	
		return ViewMapper.ADMIN_INDEX;
	}
	
	@RequestMapping("/adminCreateSubadmin")
	public String adminCreateSubadmin() {
		return ViewMapper.ADMIN_CREATE_SUBADMIN;
	}
	
	
    @RequestMapping("/adminSubadminList")
	public String adminSubadminList() {
		return ViewMapper.ADMIN_SUBADMIN_LIST;
	}
    
    @RequestMapping("/AdminCreateSubadmin")
	public String AdminCreateSubadmin(Model model) {
		
		model.addAttribute("request", new CreateSubadmin());
		return ViewMapper.ADMIN_CREATE_SUBADMIN;
	}
    
	@RequestMapping("/adminEmployeeList")
	public String adminEmployeeList() {
		return ViewMapper.ADMIN_EMPLOYEE_LIST;
	}

	@RequestMapping("/adminCustomerList")
	public String adminCustomerList() {
		return ViewMapper.ADMIN_CUSTOMER_LIST;
	}
	
	

	@RequestMapping("/adminPostCustomerList")
	public String adminPostCustomerList() {
		return ViewMapper.ADMIN_POSTINGCUSTOMER;
	}
	
	
	@PostMapping(value = URLMapper.ADMIN_CREATE_SUBADMIN)
	public String jRegisterSubadmin(CreateSubadmin request) {
		
		boolean flag = false;
		
	try {	
		flag = adminService.addSubAdmin(request);
	}catch (Exception e) {
		e.printStackTrace();
	}
	//	return flag;
		return ViewMapper.ADMIN_CREATE_SUBADMIN;
	}
	
	@GetMapping(value = "/Adminsubadmin", produces = {"application/json"})
	public @ResponseBody Map<String, Object> SubadminReport() throws Exception {
		Map<String, Object> subadminList= new HashMap<>();
		subadminList.put("data" , adminService.getSubadminReport());
		return subadminList;
		
	}
	
	

	@GetMapping(value = "/AdminEmpRoleList", produces = {"application/json"})
	public @ResponseBody Map<String, Object> getAllEmpByRole(@RequestParam("role") String role, 
			@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "pageSize",required = false, defaultValue = "100") int pageSize) throws Exception {
		
		return adminService.getAllEmpByRole(role, page, pageSize);
		
	}   
	
	@GetMapping(value = "/adminDBAList", produces = {"application/json"})
	public @ResponseBody Map<String, Object> customerReport() throws Exception {
		Map<String, Object> DBCustList= new HashMap<>();
		DBCustList.put("data" , adminService.getCustomerReport());
		return DBCustList;
		
	}
	
	@GetMapping(value = "/adminPostingList", produces = {"application/json"})
	public @ResponseBody Map<String, Object> PostingcustomerReport() throws Exception {
		Map<String, Object> PostingCustList= new HashMap<>();
		PostingCustList.put("data" , adminService.getPostingReport());
		return PostingCustList;
		
	}
	
	
}


	
	