package com.eagleSystem.eagleJob.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eagleSystem.eagleJob.bussinessObject.CandidateApplicationBO;
import com.eagleSystem.eagleJob.bussinessObject.JobBO;
import com.eagleSystem.eagleJob.dao.CandidateApplicationRepository;
import com.eagleSystem.eagleJob.dao.CandidateRepository;
import com.eagleSystem.eagleJob.dao.JobRepository;
import com.eagleSystem.eagleJob.entity.Candidate;
import com.eagleSystem.eagleJob.entity.CandidateApplication;
import com.eagleSystem.eagleJob.entity.JobPost;
import com.eagleSystem.eagleJob.util.CandidateBOPrepareUtil;
import com.eagleSystem.eagleJob.util.CandidateModelPrepareUtil;
import com.eagleSystem.eagleJob.util.JobBOPrepareUtil;
import com.eagleSystem.eagleJob.util.JobModelPrepareUtil;
import com.eagleSystem.eagleJob.util.Status;
import com.eagleSystem.eagleJob.valueObject.ListJobForCandidate;

@Transactional
@Service
public class CandidateApplicationServiceImpl implements CandidateApplicationService {

	@Autowired
	JobBOPrepareUtil jobBOPrepareUtil;

	@Autowired
	JobModelPrepareUtil jobModelPrepareUtil;

	@Autowired
	JobRepository jobRepository;

	@Autowired
	CandidateApplicationRepository caRepository;

	@Autowired
	CandidateBOPrepareUtil cadBoUtil;

	@Autowired
	CandidateModelPrepareUtil cadModelUtil;

	@Autowired
	CandidateRepository candidateRepository;

	@Override
	public List<Long> getCandidateIdsByJobId(Long jobId) {

		List<Long> ids = caRepository.findCandidateIdsByJobPost(jobId);
		System.out.println(ids);
		return ids;
	}

	@Override
	public List<CandidateApplicationBO> getJobByCandidateId(Long candidateId) {

		System.out.println(candidateId);
		List<CandidateApplicationBO> applicationBOs = new ArrayList<CandidateApplicationBO>();
		List<CandidateApplication> applications = caRepository.findByCandidateIdOrderByAppliedOnDesc(candidateId);
		for (CandidateApplication app : applications) {

			CandidateApplicationBO appBO = new CandidateApplicationBO();

			appBO.setId(app.getId());
			appBO.setApplicationStatus(app.getApplicationStatus());
			appBO.setRecruiterActionOn(app.getRecruiterActionOn());
			appBO.setAppliedOn(app.getAppliedOn());

			applicationBOs.add(appBO);
		}

		return applicationBOs;
	}

	public Map<String, Object> getCandidateAppliedJobs(Long candidateId, int page, int pageSize) {

		Map<String, Object> map = new HashMap<>();

		List<ListJobForCandidate> appliedJobs = new ArrayList<ListJobForCandidate>();

		List<Long> jobIds1 = new ArrayList<Long>();

		Pageable request = new PageRequest(page - 1, pageSize);

		Page<Long> pjp = caRepository.getAppliedJobIds(candidateId, request);

		jobIds1 = pjp.getContent();

		System.out.println(jobIds1);

		int current = pjp.getNumber() + 1;
		int begin = Math.max(1, current - 5);
		int end = Math.min(begin + 10, pjp.getTotalPages());
		int totalPages = pjp.getTotalPages();

		if (jobIds1 != null) {
			// Map<Long, String> jobIdStatusMap = new HashMap<>();
			for (Long jid : jobIds1) {

				// jobIdStatusMap.put(candidateApplicationBO.getJobBO().getPostId(),
				// candidateApplicationBO.getApplicationStatus());

				Long id = jid.longValue();

				JobPost jobPost = jobRepository.findOne(id);
				if (jobPost == null) {
					break;
				}

				JobBO jobBO = jobBOPrepareUtil.prepareJobBO(jobPost);
				ListJobForCandidate jobRequest = new ListJobForCandidate();

				jobRequest.setPostId(jobBO.getPostId());
				jobRequest.setJobProfile(jobBO.getJobProfile());
				jobRequest.setExperienceFrom(jobBO.getExperienceFrom());
				jobRequest.setExperienceTo(jobBO.getExperienceTo());
				jobRequest.setCompanyName(jobBO.getCompanyName());
				jobRequest.setLocation(jobBO.getCity());
				jobRequest.setPostedOn(jobBO.getPostedOn());

				/*
				 * String keySkill = ""; for (String ks : jobBO.getKeySkill()) { keySkill =
				 * keySkill + ks; }
				 */ jobRequest.setKeySkill(jobBO.getKeySkill());
				appliedJobs.add(jobRequest);

			}
		}
		map.put("current", current);
		map.put("begin", begin);
		map.put("end", end);
		map.put("totalPages", totalPages);
		map.put("jobs", appliedJobs);
		return map;

	}

	public List<CandidateApplicationBO> makeBo(List<CandidateApplication> ca) {

		List<CandidateApplicationBO> cbo = new CopyOnWriteArrayList<CandidateApplicationBO>();

		for (CandidateApplication c : ca) {

			CandidateApplicationBO cadApp = new CandidateApplicationBO();

			cadApp.setId(c.getId());
			cadApp.setCandidateBO(cadModelUtil.getPrepareCandidateBO(c.getCandidate()));
			cadApp.setJobBO(jobBOPrepareUtil.prepareJobBO(c.getJobPost()));
			cadApp.setApplicationStatus(c.getApplicationStatus());
			cadApp.setAppliedOn(c.getAppliedOn());
			cadApp.setRecruiterActionOn(c.getRecruiterActionOn());
			cbo.add(cadApp);

		}

		return cbo;

	}

	@Transactional
	@Override
	public boolean applyJob(Long JobId, Long CandidateId) {

		boolean flag = false;
		CandidateApplication candidateApplication = new CandidateApplication();
		System.out.println(JobId);
		JobPost jobPost = jobRepository.findById(JobId);
		System.out.println(jobPost.getContactNumber());
		System.out.println(candidateRepository.findOne(CandidateId));
		Candidate candidate = candidateRepository.findOne(CandidateId);

		candidateApplication.setAppliedOn(new Date());
		/*
		 * Long applicationCount = jobPost.getApplicationCount(); applicationCount =
		 * applicationCount + 1;
		 */

		if (jobPost.getApplicationCount() == null)
			jobPost.setApplicationCount(0l);

		jobPost.setApplicationCount(jobPost.getApplicationCount() + 1);
		candidateApplication.setApplicationStatus(Status.applied.name());
		candidateApplication.setCandidate(candidate);
		candidateApplication.setJobPost(jobPost);

		caRepository.save(candidateApplication);
		flag = true;

		return flag;
	}

	public JobBOPrepareUtil getJobBOPrepareUtil() {
		return jobBOPrepareUtil;
	}

	public void setJobBOPrepareUtil(JobBOPrepareUtil jobBOPrepareUtil) {
		this.jobBOPrepareUtil = jobBOPrepareUtil;
	}

	public JobRepository getJobRepository() {
		return jobRepository;
	}

	public void setJobRepository(JobRepository jobRepository) {
		this.jobRepository = jobRepository;
	}

	public CandidateApplicationRepository getCaRepository() {
		return caRepository;
	}

	public void setCaRepository(CandidateApplicationRepository caRepository) {
		this.caRepository = caRepository;
	}

	public CandidateRepository getCandidateRepository() {
		return candidateRepository;
	}

	public void setCandidateRepository(CandidateRepository candidateRepository) {
		this.candidateRepository = candidateRepository;
	}

}
