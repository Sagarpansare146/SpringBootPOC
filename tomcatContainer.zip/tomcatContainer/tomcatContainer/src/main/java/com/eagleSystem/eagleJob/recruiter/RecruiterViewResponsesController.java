package com.eagleSystem.eagleJob.recruiter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.dao.CandidateApplicationRepository;
import com.eagleSystem.eagleJob.dao.CandidatePrefRepository;
import com.eagleSystem.eagleJob.service.CandidateApplicationService;
import com.eagleSystem.eagleJob.service.CandidateService;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.CandidateRecords;

@Controller
public class RecruiterViewResponsesController {

	@Autowired
	CandidateApplicationRepository candidateApplicationRepository;

	@Autowired
	CandidateApplicationService candidateApplicationService; 
	
	@Autowired
	CandidatePrefRepository canPrefRepo;
	
	@Autowired
	CandidateService candidateService;
	
	@Autowired
	RecruiterService recruiterService;
	
	@GetMapping(value = URLMapper.RECRUITER_JOB_RESPONSES, produces = {"application/json"})
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody List<CandidateRecords> jLoadResponses(@RequestParam Long jobId, Model model,
			Authentication auth) {
		List<CandidateRecords> appliedCandidates = new ArrayList<CandidateRecords>();
		System.out.println(jobId);
		
	/*	List<CandidateApplication> appliedCandidateIds = candidateApplicationRepository.findByJobPost(jobId);
		System.out.println(appliedCandidateIds);
		if (CollectionUtils.isNotEmpty(appliedCandidateIds)) {
			appliedCandidates = new ArrayList<>();
	
			for (CandidateApplication candidateApp : appliedCandidateIds) {
				Candidate candidate = candidateRepository.findOne(candidateApp.getCandidate().getId());
	//			candidate.setApplicationStatus(candidateApp.getApplicationStatus());
				
				appliedCandidates.add(candidate);
			}
		
		}*/
		
		List<Long> ids = candidateApplicationService.getCandidateIdsByJobId(jobId);
		if(ids != null || !(ids.size() == 0))
		appliedCandidates = candidateService.prepareRecordsObj(ids);
		
		return appliedCandidates;
	}
	
	
	@GetMapping(value = URLMapper.RECRUITER_JOB_RESPONSES)
	public String loadResponses(@RequestParam Long jobId, Model model,
			Authentication auth) {
		
		List<CandidateRecords> appliedCandidates = null;

		try {
			appliedCandidates = jLoadResponses(jobId, model, auth);
		}catch(Throwable th) {
			th.printStackTrace();
			model.addAttribute("error", "Unable to get Responses");
		}
		
		model.addAttribute("request", appliedCandidates);
		model.addAttribute("jobId", jobId);
		
		return ViewMapper.RECRUITER_JOB_RESPONSES;
	}
	
	/*@GetMapping(value = URLMapper.RECRUITER_JOB_BY_LOC)
	public String filterJobsbyLoc(Model model,@RequestParam("jobId") Long jobId, @RequestParam("location") String location ,Authentication auth) {
	
		List<CandidateRecords> cads = recruiterService.jobByLoc(jobId, location);
		
		model.addAttribute("request", cads);
		
		return ViewMapper.RECRUITER_JOB_RESPONSES;
		
	}
	
	@GetMapping(value = URLMapper.RECRUITER_JOB_BY_CATEGORY)
	public String filterJobsbyJobCategory(Model model,@RequestParam("jobId") Long jobId, @RequestParam("jobCategory") String jobCategory ,Authentication auth) {
	
		List<CandidateRecords> cads = recruiterService.jobByJobCategory(jobId, jobCategory);
		
		model.addAttribute("request", cads);
		
		return ViewMapper.RECRUITER_JOB_RESPONSES;
		
	}
	
	@GetMapping(value = URLMapper.RECRUITER_JOB_BY_EXP)
	public String filterJobsbyExp(Model model,@RequestParam("jobId") Long jobId, @RequestParam("experience") Integer experience, Authentication auth) {
	
		
		List<CandidateRecords> cads = recruiterService.jobByExp(jobId, experience);
		
		model.addAttribute("request", cads);
		
		return ViewMapper.RECRUITER_JOB_RESPONSES;
		
	}
	*/
	@GetMapping("/recruiterDownloadFilter")
	public String filterJobs(@RequestParam(value = "jobId") Long jobId, @RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam(value = "from", required = false, defaultValue = "-1" ) int from, @RequestParam(value = "to", required = false, defaultValue = "-1" ) int to, @RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "degree", required = false, defaultValue = "" ) String degree,
			@RequestParam(value = "gender", required = false, defaultValue = "") String gender,
			Model model) {
	
		System.out.println("done");
		
		List<CandidateRecords> cads = recruiterService.filterRecords(jobId, location, from, to, jobCategory, degree, gender);
		
		model.addAttribute("request", cads);
		model.addAttribute("jobId", jobId);
		
		return ViewMapper.RECRUITER_JOB_RESPONSES;
		
	}
	
	@GetMapping(value = "/recruiterDownloadFilter", produces = {"application/json"})
	public @ResponseBody List<CandidateRecords> jFilterJobs(@RequestParam(value = "jobId") Long jobId, @RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam(value = "from", required = false, defaultValue = "-1" ) int from, @RequestParam(value = "to", required = false, defaultValue = "-1" ) int to, @RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "degree", required = false, defaultValue = "" ) String degree,
			@RequestParam(value = "gender", required = false, defaultValue = "") String gender) {
	
		System.out.println("done");
		
		return recruiterService.filterRecords(jobId, location, from, to, jobCategory, degree, gender);	
		
	}
	
	/*@GetMapping(value = "/bdmDownloadFilter", produces = {"application/json"})
	public @ResponseBody List<CandidateRecords> jNaukriFilterJobs(@RequestParam(value = "jobId") Long jobId, @RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam(value = "from", required = false, defaultValue = "-1" ) int from, @RequestParam(value = "to", required = false, defaultValue = "-1" ) int to, @RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "degree", required = false, defaultValue = "" ) String degree) {
	
		System.out.println("done");
		
		return recruiterService.filterRecords(jobId, location, from, to, jobCategory, degree);	
		
	}*/
	
}