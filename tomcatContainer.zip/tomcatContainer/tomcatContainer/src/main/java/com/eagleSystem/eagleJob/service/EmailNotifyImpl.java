package com.eagleSystem.eagleJob.service;

import java.util.List;

public class EmailNotifyImpl {
	
	public boolean send(List<String> ids) {
				
		return true;
	}

}
