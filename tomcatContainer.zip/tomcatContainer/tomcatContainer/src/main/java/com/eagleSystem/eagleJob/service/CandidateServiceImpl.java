package com.eagleSystem.eagleJob.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eagleSystem.eagleJob.bussinessObject.CandidateBO;
import com.eagleSystem.eagleJob.dao.CandidatePrefRepository;
import com.eagleSystem.eagleJob.dao.CandidateRepository;
import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.dao.QualificationRepository;
import com.eagleSystem.eagleJob.entity.Candidate;
import com.eagleSystem.eagleJob.entity.CandidatePreference;
import com.eagleSystem.eagleJob.entity.JPUser;
import com.eagleSystem.eagleJob.entity.Qualification;
import com.eagleSystem.eagleJob.util.CandidateBOPrepareUtil;
import com.eagleSystem.eagleJob.util.CandidateModelPrepareUtil;
import com.eagleSystem.eagleJob.util.Role;
import com.eagleSystem.eagleJob.valueObject.CandidateRecords;
import com.eagleSystem.eagleJob.valueObject.UserRegistrationRequest;

@Service
@Transactional
public class CandidateServiceImpl implements CandidateService {

	@Autowired
	private CandidateRepository candidateRepository;
	@Autowired
	private JPUserRepository jpUserRepository;
	@Autowired
	private CandidateModelPrepareUtil modelprepare;
	@Autowired
	private CandidateBOPrepareUtil boUtil;
	@Autowired
	private CandidatePrefRepository canPrefDao;

	@Autowired
	private QualificationRepository qualification;

	@Autowired
	CandidateService candidateService;

	@Autowired
	QualificationRepository qualRepo;

	public boolean candidateReg(CandidateBO candidateBO) {
		boolean flag = false;

		flag = crosCandidateReg(candidateBO);

		return flag;
	}

	public boolean candidateUpdate(UserRegistrationRequest registrationRequest, Long id) {

		boolean flag = true;

		try {

			Candidate candidate = candidateRepository.findOne(id);
			CandidatePreference candidatePreference = canPrefDao.findOne(id);
			Qualification qual = qualification.findOne(id);

			candidate.setId(id);
			candidate.setName(registrationRequest.getName());
			candidate.setEmail(registrationRequest.getEmail());
			candidate.setDob(registrationRequest.getDob());
			candidate.setGender(registrationRequest.getGender());
			candidate.setCandidateAddress(registrationRequest.getCandidateAddress());
			candidate.setCity(registrationRequest.getCandidateCity());
			candidate.setState(registrationRequest.getCandidateState());
			candidate.setContactNumber(registrationRequest.getContactNumber());
			candidate.setUsername(registrationRequest.getUsername());
			// candidate.setPassword(registrationRequest.getPassword());
			candidate.setNotificationStatus(registrationRequest.isNotificationStatus());
			candidate.setToken(registrationRequest.getToken());
			candidate.setNotificationStatus(registrationRequest.isNotificationStatus());

			qual.setDegree(registrationRequest.getDegree());
			qual.setSpecilization(registrationRequest.getSpecilization());
			qual.setPassout(registrationRequest.getPassout());
			qual.setPercentage(registrationRequest.getPercentage());
			qual.setExperience(registrationRequest.getExperience());
			qual.setMonth(registrationRequest.getMonth());
			qual.setUniversity(registrationRequest.getUniversity());

			String topCities = "";
			String jobCategory = "";

			/*
			 * for (String tc : registrationRequest.getTopCities()) {
			 * if(!(topCities.equals(""))) {
			 * 
			 * topCities = topCities +","+ tc; } else { topCities = topCities + tc;
			 * 
			 * 
			 * } }
			 */

			for (String jc : registrationRequest.getJobCategory()) {

				if (!(jobCategory.equals(""))) {
					jobCategory = jobCategory + "," + jc;

				} else {

					jobCategory = jobCategory + jc;
				}

			}

			candidatePreference.setJobCategory(jobCategory);
			candidatePreference.setFunctionalArea(registrationRequest.getFunctionalArea());
			candidatePreference.setKeySkill(registrationRequest.getKeySkill());
			candidatePreference.setJobType(registrationRequest.getJobType());
			candidatePreference.setLocation(topCities);

			candidateRepository.save(candidate);
			canPrefDao.save(candidatePreference);
			qualification.save(qual);

		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}

		return flag;
	}

	public UserRegistrationRequest getUserData(String username) {

		CandidateBO bo = modelprepare.getPrepareCandidateBO(candidateRepository.findByUsername(username));
		System.out.println("cad" + bo);
		bo.setCandidatePreference(modelprepare.getPrepareCandidatePrefBO(canPrefDao.findOne(bo.getId())));
		System.out.println("cadpref" + bo);
		bo.setQualification(modelprepare.getPrepareQualificationBO(qualification.findOne(bo.getId())));
		System.out.println("cadqual" + bo);
		// bo.setCandidatePreference(modelprepare.getPrepareCandidatePrefBO(candidate.getCandidatePreference()));
		// System.out.println(candidate.getQualification());
		// bo.setQualification(modelprepare.getPrepareQualificationBO(candidate.getQualification()));

		UserRegistrationRequest request = boUtil.getUserRegRequest(bo);

		System.out.println(request);

		return request;

	}

	public List<CandidateRecords> prepareRecordsObj(List<Long> ids) {

		List<CandidateRecords> appliedCandidates = new ArrayList<CandidateRecords>();

		for (Long id : ids) {

			Candidate candidate = candidateRepository.findById(id);
			CandidatePreference canPref = canPrefDao.findOne(id);
			Qualification qualification = qualRepo.findOne(id);
			CandidateRecords records = new CandidateRecords();

			if(candidate == null)
				continue;
			
			records.setId(id);
			records.setName(candidate.getName());
			records.setLocation(candidate.getCity());
			records.setLocation(canPref.getLocation());
			records.setTotalExpInYear((qualification.getExperience() == 0 && qualification.getMonth() == 0 ? "Freshers" : qualification.getExperience()+ " Years"));
			records.setTotalExpInMonth(qualification.getExperience() == 0 && qualification.getMonth() == 0 ? "Freshers" :qualification.getMonth()+ " Months");
			records.setJobCategory(canPref.getJobCategory());
			records.setKeySkill(canPref.getKeySkill());
			records.setQualification(qualification.getDegree());
			records.setGender(candidate.getGender());
			records.setEmail(candidate.getEmail());
			records.setContactNumber(candidate.getContactNumber());
			records.setPassout(qualification.getPassout());
			records.setDob(candidate.getDob());
			
			appliedCandidates.add(records);
		}
		return appliedCandidates;
	}

	public Long getCandidateId(String username) {

		return candidateRepository.getCandidateIdByUsername(username);

	}

	@Override
	public UserRegistrationRequest getCandidate(String username) {

		UserRegistrationRequest request = null;
		Candidate candidate = candidateRepository.findByUsername(username);
		request = boUtil.getUserRegRequest(modelprepare.getPrepareCandidateBO(candidate));
		return request;
	}

	@Override
	public boolean crosCandidateReg(CandidateBO candidateBO) {

		boolean flag = false;

		Candidate candidate = modelprepare.prepareCandidateModel(candidateBO);
		CandidatePreference canPref = modelprepare.preparePrefModel(candidateBO);
		Qualification qual = modelprepare.prepareQualModel(candidateBO);

		JPUser jpUser = new JPUser();

		jpUser.setUsername(candidateBO.getUsername());
		jpUser.setPassword(candidateBO.getPassword());
		jpUser.setEnabled(true);
		jpUser.setRole(Role.candidate.name());

		// candidate.setJpUser(jpUser);

		candidateRepository.save(candidate);

		qual.setCandidate(candidate);
		canPref.setCandidate(candidate);
		canPrefDao.save(canPref);
		qualification.save(qual);

		jpUserRepository.save(jpUser);

		System.out.println(jpUser);
		System.out.println(candidate);
		flag = true;

		return flag;

	}

	public long getCandidateCount() {
		return candidateRepository.count();
	}

	public CandidateRepository getCandidateRepository() {
		return candidateRepository;
	}

	@Autowired
	public void setCandidateRepository(CandidateRepository candidateRepository) {
		this.candidateRepository = candidateRepository;
	}

	public JPUserRepository getJpUserRepository() {
		return jpUserRepository;
	}

	@Autowired
	public void setJpUserRepository(JPUserRepository jpUserRepository) {
		this.jpUserRepository = jpUserRepository;
	}

	public CandidateModelPrepareUtil getModelprepare() {
		return modelprepare;
	}

	@Autowired
	public void setModelprepare(CandidateModelPrepareUtil modelprepare) {
		this.modelprepare = modelprepare;
	}

	public CandidatePrefRepository getCanPrefDao() {
		return canPrefDao;
	}

	public void setCanPrefDao(CandidatePrefRepository canPrefDao) {
		this.canPrefDao = canPrefDao;
	}

	public CandidateBOPrepareUtil getBoUtil() {
		return boUtil;
	}

	public void setBoUtil(CandidateBOPrepareUtil boUtil) {
		this.boUtil = boUtil;
	}

	public QualificationRepository getQualification() {
		return qualification;
	}

	public void setQualification(QualificationRepository qualification) {
		this.qualification = qualification;
	}

}
