package com.eagleSystem.eagleJob.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.eagleSystem.eagleJob.entity.CustomerSubAdmin;
import java.lang.String;
import java.math.BigInteger;
import java.util.List;

public interface CustomerSubAdminRepository extends JpaRepository<CustomerSubAdmin, Long> {

	CustomerSubAdmin findBySubAdmin(String subadmin);

	@Query(value = "select cid from customer_bdm where sub_admin = :subAdmin", nativeQuery = true)
	List<BigInteger> getIdBySubAdmin(@Param("subAdmin") String subAdmin);
	
}