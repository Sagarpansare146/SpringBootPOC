package com.eagleSystem.eagleJob.util;

public interface CustomerEmailMessage {

	
	public static String MSG = "India's No.1 Job portal\n" + 
			"Welcome to NaukriJob.co.in\n" + 
			"\n" + 
			"Dear {{name}},\n" + 
			"\n" + 
			"	You are now connected with over  2 lakh jobs and 2000 recruiters\n" + 
			"on Naukrijob.co.in To start receiving Jobs from recruiters, we recommend you\n" + 
			"to verify your email & mobile number.\n" + 
			"\n" + 
			"\n" + 
			"Login & complete your profile\n" + 
			"\n" + 
			"Download the NaukriJob Mobile App {{apkLink}}\n" + 
			"\n" + 
			"User name : {{username}}\n" + 
			"Password : {{password}}\n" + 
			"\n" + 
			"Login to your profile\n" + 
			"\n" + 
			"Thanks & Regards,\n" + 
			"NaukriJob.co.in Team\n" + 
			"By your positive acts of registering on naukrijob. co.in\n" + 
			"and if you do not agree with any of the provisions of these policies,\n" + 
			"you should not access or use naukrijob.co.in\n" + 
			"\n" + 
			"\n" + 
			"Report a problem\n" + 
			"\n" + 
			"This is a system generated personalized mail regarding your Naukrijob\n" + 
			"account preferences. We have enabled auto-login for your convenience,\n" + 
			"you are strongly advised not to forward this email to protect your\n" + 
			"account from unauthorized access.\n" + 
			"\n" + 
			"Please do not reply to this message.";
}
