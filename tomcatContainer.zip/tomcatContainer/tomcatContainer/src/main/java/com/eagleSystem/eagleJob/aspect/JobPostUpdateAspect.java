package com.eagleSystem.eagleJob.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.bussinessObject.JobBO;
import com.eagleSystem.eagleJob.dao.JobRepository;
import com.eagleSystem.eagleJob.entity.JobPost;

@Aspect
@Component
public class JobPostUpdateAspect extends AbstractAppPointcut {

	@Autowired
	JobRepository jobRepo;

	@Around("UpdateJobPostPointcut()")
	public Object jobPostUpdateCheck(ProceedingJoinPoint pjp) throws Throwable {

		JobPost jobPost = jobRepo.findOne(((JobBO) (pjp.getArgs())[0]).getPostId());

		if ((jobPost == null)) {

			throw new Exception("Invalid job Post !");
		}
		System.out.println(jobPost.getJobProfile());

		return pjp.proceed();

	}

}
