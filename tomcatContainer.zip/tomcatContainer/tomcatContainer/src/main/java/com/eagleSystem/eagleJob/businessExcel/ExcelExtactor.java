package com.eagleSystem.eagleJob.businessExcel;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.entity.ShineExcelRecord;

@Component
public class ExcelExtactor {

	public List extractCellData(Row row) {
		
		List obj = new ArrayList();
		
		 short minColIx = row.getFirstCellNum();
		 short maxColIx = row.getLastCellNum();
		 int i = 1;
		 
		 System.out.println("min :"+ minColIx + "max :"+maxColIx);
		 
		 for(short colIx=minColIx; colIx<maxColIx; colIx++) {
		   Cell cell = row.getCell(colIx);
		   
		   if(cell == null) {
		     continue;
		   }
		   
		   switch(cell.getCellType()) {
		   
			case Cell.CELL_TYPE_BOOLEAN:
				obj.add(String.valueOf(cell.getBooleanCellValue()));
				
//							System.out.print(cell.getBooleanCellValue() + "\t\t");
				break;
				
			case Cell.CELL_TYPE_NUMERIC:
				
				try {
					
					if (DateUtil.isCellDateFormatted(cell))
		            {
		                Date date = cell.getDateCellValue();
		                String cellValue = date.getDate() + "/" + (date.getMonth() + 1) + "/" + (1900 + date.getYear());
		                System.out.println(cellValue);
		                obj.add(cellValue);
		   
		}
					
/*					if(obj.add(String.valueOf(cell.getDateCellValue()))) {
						break;
						}
*/					
					else {
						obj.add(String.valueOf(cell.getNumericCellValue()));
						
					}
				}
				catch (Exception e) {
					e.printStackTrace();
					obj.add(String.valueOf(cell.getNumericCellValue()));
					
				}
				
				
//							System.out.print(cell.getNumericCellValue() + "\t\t");
				break;
				
			case Cell.CELL_TYPE_STRING:
				obj.add(String.valueOf(cell.getStringCellValue()));
				
//							System.out.print(cell.getStringCellValue() + "\t\t");
						break;
			case Cell.CELL_TYPE_BLANK :
				obj.add(new String("NA"));
				
				default:
					
					try {
						if (DateUtil.isCellDateFormatted(cell))
			            {
			                Date date = cell.getDateCellValue();
			                String cellValue = date.getDate() + "/" + (date.getMonth() + 1) + "/" + (1900 + date.getYear());
			                System.out.println(cellValue);
			                obj.add(cellValue);
			   
			}	else {
				obj.add(new String("NA"));
			}
						}catch(Exception e) {
							e.printStackTrace();
							obj.add(new String("NA"));
						}
						
							System.out.println("NA  :"+ obj.size());
							break;
		}
		   
		   //... do something with cell
		 }

		return obj;
	}
	
	public List excelShineCell(Row row) {
		
		
		List obj = new ArrayList();
		
		 short minColIx = row.getFirstCellNum();
		 short maxColIx = row.getLastCellNum();
		 int i = 1;
		 
		 
		 System.out.println("min :"+ minColIx + "max :"+maxColIx);
		 
		 for(short colIx=minColIx; colIx<maxColIx; colIx++) {
			 
		   Cell cell = row.getCell(colIx);
		   
		   if(cell == null) {
		     continue;
		   }
				switch(cell.getCellType()) {
					case Cell.CELL_TYPE_BOOLEAN:
						
						obj.add(cell.getBooleanCellValue());
				//		System.out.print(cell.getBooleanCellValue() + "\t\t");
						break;
					case Cell.CELL_TYPE_NUMERIC:
						
						obj.add(cell.getNumericCellValue());
				//		System.out.print(cell.getNumericCellValue() + "\t\t");
						break;
					case Cell.CELL_TYPE_STRING:
						
						if(cell.getStringCellValue().equals("")) {
						obj.add("NA");
						}else {
						obj.add(cell.getStringCellValue());
						}
				//		System.out.print(cell.getStringCellValue() + "\t\t");
						break;
					case Cell.CELL_TYPE_BLANK :
						obj.add(new String("NA"));
				//		System.out.println("NA");
						break;
						
					case Cell.CELL_TYPE_ERROR :
						obj.add(new String("NA"));
						//		System.out.println("NA");
								break;
					case Cell.CELL_TYPE_FORMULA :
						obj.add(new String("NA"));
						//		System.out.println("NA");
								break;
					default :
						obj.add(new String("NA"));
						break;
				}
			}
//			System.out.println(ids);
			return obj;
		}
		
	public List buildShineRecordObj(Iterator<Row> rowIterator, String jobCategory) {

		int j = 1;
		List list = new ArrayList();
		
		for (int i= 0; i <= 5; i++) {
			System.out.println(i);
			rowIterator.next();
			
		}
		while (rowIterator.hasNext()) {

			List obj = new ArrayList();
			// For each row, iterate through each columns

			
			Row row = rowIterator.next();

			System.out.println(j);
			j++;

			
			ShineExcelRecord sXlsRec = new ShineExcelRecord();

		//	obj = extractCellData(row);
		
				String EmailID = "";
				try {
					EmailID = (String) row.getCell(3).getStringCellValue();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if(EmailID.equals("")) {
					continue;
				}
	
				
			String CandidateName="";
			try {
				CandidateName = (String) row.getCell(1).getStringCellValue();
			} catch (Exception e) {
					e.printStackTrace();
			}
			String DOB="";
			try {
				DOB = (String) row.getCell(2).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			String ContactNumber="";
			try {
				ContactNumber = (String) row.getCell(4).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String CurrentLocation="";
			try {
				CurrentLocation = (String) row.getCell(5).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String Gender="";
			try {
				Gender = (String) row.getCell(6).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String TotalWorkExperience="";
			try {
				TotalWorkExperience = (String) row.getCell(7).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String CurrentAnnualSalary="";
			try {
				CurrentAnnualSalary = (String) row.getCell(8).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String CurrentJobTitle="";
			try {
				CurrentJobTitle = (String) row.getCell(9).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String CurrentFunctionalArea="";
			try {
				CurrentFunctionalArea = (String) row.getCell(10).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String CurrentIndustry="";
			try {
				CurrentIndustry = (String) row.getCell(11).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String CurrentCompany="";
			try {
				CurrentCompany = (String) row.getCell(12).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String YearsinCurrentJob="";
			try {
				YearsinCurrentJob = (String) row.getCell(13).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String NoticePeriod="";
			try {
				NoticePeriod = (String) row.getCell(14).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String HighestEducationLevel="";
			try {
				HighestEducationLevel = (String) row.getCell(15).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String HighestEducationStream="";
			try {
				HighestEducationStream = (String) row.getCell(16).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String HighestEducationInstitute="";
			try {
				HighestEducationInstitute = (String) row.getCell(17).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String YearOfPassing="";
			try {
				YearOfPassing = (String) row.getCell(18).getStringCellValue();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				
		//	sXlsRec.setSno((long) row.getCell(0).getNumericCellValue());
			sXlsRec.setCandidateName(CandidateName.equals("") ? "NA" : CandidateName);
			sXlsRec.setDob( DOB.equals("") ? "NA" : DOB);
			sXlsRec.setEmailID( EmailID.equals("") ? "NA" : EmailID);
			sXlsRec.setContactNumber( ContactNumber.equals("") ? "NA" : ContactNumber);
			sXlsRec.setCurrentLocation( CurrentLocation.equals("") ? "NA" : CurrentLocation);
			
			sXlsRec.setGender( Gender.equals("") ? "NA" : Gender);
			sXlsRec.setTotalWorkExperience( TotalWorkExperience.equals("") ? "NA" : TotalWorkExperience);
			sXlsRec.setCurrentAnnualSalary( CurrentAnnualSalary.equals("") ? "NA" : CurrentAnnualSalary);
			sXlsRec.setCurrentJobTitle( CurrentJobTitle.equals("") ? "NA" : CurrentJobTitle);
			sXlsRec.setCurrentFunctionalArea( CurrentFunctionalArea.equals("") ? "NA" : CurrentFunctionalArea);
			sXlsRec.setCurrentIndustry( CurrentIndustry.equals("") ? "NA" : CurrentIndustry);
			sXlsRec.setCurrentCompany( CurrentCompany.equals("") ? "NA" : CurrentCompany);
			sXlsRec.setYearsinCurrentJob( YearsinCurrentJob.equals("") ? "NA" : YearsinCurrentJob);
			sXlsRec.setNoticePeriod( NoticePeriod.equals("") ? "NA" : NoticePeriod);
			sXlsRec.setHighestEducationLevel( HighestEducationLevel.equals("") ? "NA" : HighestEducationLevel);
			sXlsRec.setHighestEducationStream(HighestEducationStream.equals("") ? "NA" : HighestEducationStream);
			sXlsRec.setHighestEducationInstitute(HighestEducationInstitute.equals("") ? "NA" : HighestEducationInstitute );
			sXlsRec.setYearOfPassing(YearOfPassing.equals("") ? "NA" : YearOfPassing );
			sXlsRec.setJobCategory(jobCategory.equals("") ? "NA" : jobCategory);
			
			if (sXlsRec != null)
				list.add(sXlsRec);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
			
		return list;
	}
	
}
