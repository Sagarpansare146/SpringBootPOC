package com.eagleSystem.eagleJob.controller.bdm;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.eagleSystem.eagleJob.BusinessExcelBuilder;
import com.eagleSystem.eagleJob.ExcelBuilder;
import com.eagleSystem.eagleJob.businessExcel.NaukriDownloadRecord;
import com.eagleSystem.eagleJob.controller.subAdmin.SubAdminManagementController;
import com.eagleSystem.eagleJob.dao.AccountRepository;
import com.eagleSystem.eagleJob.dao.BdmDownloadRecordRepository;
import com.eagleSystem.eagleJob.dao.RecruiterDownloadRecordsRepository;
import com.eagleSystem.eagleJob.dao.SubAdminRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.service.bdm.BdmReportService;
import com.eagleSystem.eagleJob.service.bdm.BdmServiceImpl;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.BdmAccount;
import com.eagleSystem.eagleJob.valueObject.CandidateExcelRecords;
import com.eagleSystem.eagleJob.valueObject.FilterInput;

@CrossOrigin
@Controller
public class BdmController {

	public static final int GOLD_NAUKRI = 1;
	public static final int SILVER_MONSTER = 2;
	public static final int PLATINUM_SHINE = 3;
	public static final int STANDARD_TIMES = 4;

	@Autowired
	BdmServiceImpl bdmServiceImpl;
	
	@Autowired
	RecruiterService recruiterService;
	
	@Autowired
	NaukriDownloadRecord naukriDownloadRecord;

	@Autowired
	BdmReportService bdmReportService;
	
	@Autowired
	AccountRepository accountRepository;

	@Autowired
	BdmDownloadRecordRepository bdmDownloadRecordRepository;
	
	@Autowired
	RecruiterDownloadRecordsRepository recruiterDownloadRecordsRepository;

	@Autowired
	SubAdminManagementController subAdminManagement;
	
	
	@GetMapping("/bdmhome")
	public String bdmhome() {
		return ViewMapper.BDM_BDM_HOME;
	}
	
	
	@GetMapping("/bdmGoldServerPage")
	public String goldServerPage() {
		return ViewMapper.BDM_BDM_GOLDSERVER;
	}
	

	@GetMapping("/bdmReportPage")
	public String bdmReportPage() {
		return ViewMapper.BDM_BDM_REPORT;
	}

	@GetMapping("/bdmViewPage")
	public String bdmViewPage() {
		return ViewMapper.BDM_BDM_VIEW;
	}

	@GetMapping("/bdmDatabaseReport")
	public String bdmdatabaseReport(Model model) throws Exception {
		
		  Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		  model.addAttribute("request",bdmReportService.getBdmDbCustomerReport() );
	/*	
			int excelDataUsed = recruiterDownloadRecordsRepository.findByRecruiter(auth.getName()).stream().filter(e -> e.getDownloadExcelCount() != 0).mapToInt(e -> e.getDownloadExcelCount()).sum();
	        int resumeDataUsed = recruiterDownloadRecordsRepository.findByRecruiter(auth.getName()).stream().filter(e -> e.getDownloadResumeCount() != 0).mapToInt(e -> e.getDownloadResumeCount()).sum();
	        model.addAttribute("excelDataUsed", excelDataUsed);
	        model.addAttribute("resumeDataUsed", resumeDataUsed);
	System.out.println("excelUsed :"+excelDataUsed);	
*/		
		  return ViewMapper.BDM_BDM_DATABASEREPORT;
		
		
	}
	@GetMapping("/bdmPostingReport")
	public String bdmPostingReport(Model model) throws Exception {
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		model.addAttribute("request",bdmReportService.getBdmRecruiterReport() );
		int excelDataUsed = recruiterDownloadRecordsRepository.findByRecruiter(auth.getName()).stream().peek(e -> System.out.println(e)).filter(e -> e.getDownloadExcelCount() != 0).mapToInt(e -> e.getDownloadExcelCount()).sum();
        int resumeDataUsed = recruiterDownloadRecordsRepository.findByRecruiter(auth.getName()).stream().filter(e -> e.getDownloadResumeCount() != 0).mapToInt(e -> e.getDownloadResumeCount()).sum();
        model.addAttribute("excelDataUsed", excelDataUsed);
        model.addAttribute("resumeDataUsed", resumeDataUsed);
System.out.println("excelUsed :"+excelDataUsed);	
		  
		return ViewMapper.BDM_BDM_POSTINGREPORT;
	}
	
	@GetMapping("/bdmLatestdata")
	public String bdmLatestdata() {
		return ViewMapper.BDM_BDM_LATESTDATA;
	}
	
	
	@RequestMapping(value = URLMapper.BDM_NAUKRI_EXCEL_RECORDS, method = RequestMethod.GET)
	public ModelAndView downloadNaukriExcelRecords(Authentication auth, Map<String, Object> model,
			@RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam(value = "experience", required = false, defaultValue = "-1") int experience, 
			@RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "degree", required = false, defaultValue = "") String degree,
			@RequestParam("ids") Long... ids) {

		String s = (experience == -1 ? "" : String.valueOf(experience)) + "_" + (location.equals("") ? "" : location) + "_" + (jobCategory.equals("") ? "" : jobCategory)+ "_" +(degree.equals("") ? "" : degree);
		
		List<NaukriExcelRecord> records = bdmServiceImpl.bdmDownloadBdmNaukriExcelRecord(ids);
		model.put("request", records);
		model.put("industry", "NaukriJobServer1"+ "_" +s);

		return new ModelAndView(new BusinessExcelBuilder(), "records", records);

	}
	
	
	@CrossOrigin
	@GetMapping(value = "/bdmBasicProfile", produces = {"application/json"})
	public @ResponseBody BdmAccount getBdmBasicProfile() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Account account = accountRepository.findByUsername(auth.getName());
		
		Long excelDownloadedCount = bdmDownloadRecordRepository.findByBdm(auth.getName()).stream().filter(e -> e.getDownloadExcelCount() != 0)
				.filter(e -> e.getDownloadDate().getDate() == new Date().getDate() ).mapToLong(e -> e.getDownloadExcelCount()).sum();
		Long resumeDownloadedCount = bdmDownloadRecordRepository.findByBdm(auth.getName()).stream().filter(e -> e.getDownloadResumeCount() != 0)
				.filter(e -> e.getDownloadDate().getDate() == new Date().getDate() ).mapToLong(e -> e.getDownloadResumeCount()).sum();
		System.out.println(excelDownloadedCount);
		BdmAccount bdmAccount = new BdmAccount();
		
		bdmAccount.setEmail(account.getEmail());
		bdmAccount.setExcelLimit(account.getExcelLimit());
		bdmAccount.setLoaction(account.getLoaction());
		bdmAccount.setName(account.getName());
		bdmAccount.setRecruiterLimitPerDay(account.getRecruiterLimitPerDay());
		bdmAccount.setResumeLimit(account.getResumeLimit());
		bdmAccount.setRole(account.getRole());
		bdmAccount.setTarget(account.getTarget());
		bdmAccount.setExcelDownloadedCount(excelDownloadedCount);
		bdmAccount.setResumeDownloadedCount(resumeDownloadedCount);
		return bdmAccount;
			
	}
	
	
	@RequestMapping(value = URLMapper.BDM_NAUKRIJOB_EXCEL_RECORDS, method = RequestMethod.GET)
	public ModelAndView downloadNaukriJobExcelRecords(Authentication auth, Map<String, Object> model,
			@RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam("ids") Long... ids) {

		String s1 = (location.equals("") ? "" : location) + "_" + (jobCategory.equals("") ? "" : jobCategory);
		

		List<CandidateExcelRecords> records = recruiterService.bdmDownloadExcelRecords(ids);
		model.put("request", records);
		model.put("name", "NaukriJobServer2"+ "_" +s1);

		return new ModelAndView(new ExcelBuilder(), "records", records);

	}
	
	@RequestMapping(value = URLMapper.BDM_NAUKRI_RESUME_DOWNLOAD, produces = "application/zip", method = RequestMethod.GET)
	public void downloadResume(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("id") Long... cadId) throws IOException {

//		Map<Long, CandidatePreference> map;
		response.setContentType("application/zip");
		response.setStatus(HttpServletResponse.SC_OK);
	//	JobPost jobPost = jobRepository.findOne(jobId);
		response.addHeader("Content-Disposition", "attachment; filename=\"" + "NaukriJob" + ".zip\"");
		
		try {

	//		map = recruiterService.downloadResume(Arrays.asList(cadId), jobId);

			
			
			List<String> srcFiles = bdmServiceImpl.bdmResumeNaukriPath(cadId);

			if(srcFiles == null)
				new ArrayList<>();
			
			
			System.out.println(srcFiles);
			
/*			for (Long id : Arrays.asList(cadId)) {
				srcFiles.add("c:" + File.separator + map.get(id).getResume());
			}
*/			
	
			OutputStream fos = response.getOutputStream();

			ZipOutputStream zipOut = new ZipOutputStream(fos);
			for (String srcFile : srcFiles) {
				File fileToZip = new File(srcFile);
				if (!(fileToZip.exists())) {
					System.out.println("file not found");
				}

				FileInputStream fis = new FileInputStream(fileToZip);
				ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
				zipOut.putNextEntry(zipEntry);
				System.out.println(zipEntry);
				byte[] bytes = new byte[8096];
				int length;
				while ((length = fis.read(bytes)) >= 0) {
					zipOut.write(bytes, 0, length);

				}
				fis.close();
			}
			zipOut.close();
			fos.close();

		} catch (IOException e) {
			System.out.println("Error:- " + e.getMessage());
		} catch (Exception e) {

			e.printStackTrace();
		}

	}
	
	@RequestMapping(value = URLMapper.BDM_NAUKRIJOB_RESUME_DOWNLOAD, produces = "application/zip", method = RequestMethod.GET)
	public void downloadNaukriJobResume(HttpServletRequest request, HttpServletResponse response, Authentication auth,
			Long... cadId) throws Exception {

		if(auth == null ? true : false) {
			
			throw new Exception("Invalid User");
		}
		
//		Map<Long, CandidatePreference> map;
		response.setContentType("application/zip");
		response.setStatus(HttpServletResponse.SC_OK);
	//	JobPost jobPost = jobRepository.findOne(jobId);
		response.addHeader("Content-Disposition", "attachment; filename=\"" + "NaukriJob" + ".zip\"");
		
		try {

	//		map = recruiterService.downloadResume(Arrays.asList(cadId), jobId);

			
			List<String> filenames = bdmServiceImpl.bdmResumeNaukriJobPath(cadId);

			if(filenames == null)
				filenames = new ArrayList<>();
				
			System.out.println(filenames);
			
/*			for (Long id : Arrays.asList(cadId)) {
				srcFiles.add("c:" + File.separator + map.get(id).getResume());
			}
*/			
			String str = "c:" + File.separator;
			List<String> srcFiles = filenames.stream().map(s -> str + s).collect(Collectors.toList());
	
			System.out.println(srcFiles);
			
			OutputStream fos = response.getOutputStream();

			ZipOutputStream zipOut = new ZipOutputStream(fos);
			for (String srcFile : srcFiles) {
				File fileToZip = new File(srcFile);
				if ((fileToZip.exists())) {
					
					FileInputStream fis = new FileInputStream(fileToZip);
					ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
					zipOut.putNextEntry(zipEntry);
					System.out.println(zipEntry);
					byte[] bytes = new byte[8096];
					int length;
					while ((length = fis.read(bytes)) >= 0) {
						zipOut.write(bytes, 0, length);

					}
					fis.close();
					
				}
				System.out.println("file not found");
				
			}
			zipOut.close();
			fos.close();

		} catch (IOException e) {
			System.out.println("Error:- " + e.getMessage());
		} catch (Exception e) {

			e.printStackTrace();
		}

	}
	
	@RequestMapping(value = URLMapper.BDM_DOWNLOAD, method = RequestMethod.GET)
	public ModelAndView download(HttpServletRequest request, HttpServletResponse response, Authentication auth,
			@RequestParam("action") String action, Map<String, Object> model,
			@RequestParam("id") Long... cadId) throws Exception {

		ModelAndView mav = null;

		try {

			if (action.contains("Excel")) {
				mav = downloadNaukriJobExcelRecords(auth, model, action, action, cadId);

			} else {
				downloadNaukriJobResume(request, response, auth, cadId);
			}
		} catch (IOException e) {
			System.out.println("Error:- " + e.getMessage());
		}
		return mav;
	}
	
	
	@GetMapping("/bdmSilverServerPage")
	public String bdmSilverServerPage(Model model) {
		
	//	model.addAttribute("keySkill", naukriDownloadRecord.getKeySkill());
		model.addAttribute("location", naukriDownloadRecord.getLocations());
		model.addAttribute("qualification", naukriDownloadRecord.getQualification());
		model.addAttribute("jobCategory", naukriDownloadRecord.getJobCategory());
	model.addAttribute("currentlocation", naukriDownloadRecord.getcurrentLocations().stream().map(e -> e.trim()).collect(Collectors.toList()));
		model.addAttribute("annualSalary", naukriDownloadRecord.getannualSalary().stream().filter(e -> e.contains("INR")).collect(Collectors.toList()));
//		model.addAttribute("experience", IntStream.range(1, 20).boxed().map(i -> String.valueOf(i) + " Year(s)").collect(Collectors.toSet()));
//		model.add
		model.addAttribute("abc", new FilterInput());
		return ViewMapper.BDM_BDM_SILVER_SERVER;
	}
	
	
	
	
	@GetMapping(value = URLMapper.BDM_NAUKRI_FILTER , produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody Map<String, Object> jNaukriFilterData(@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "pageSize",required = false, defaultValue = "100") int pageSize,
			@RequestParam(value = "location", required = false, defaultValue = "") String location, 
			@RequestParam(value = "experience", required = false, defaultValue = "-1") int experience,
			@RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "currentlocation", required = false, defaultValue = "") String currentlocation,
			@RequestParam(value = "annualSalary", required = false, defaultValue = "") String annualSalary,
			@RequestParam(value = "gender", required = false, defaultValue = "") String gender,
			@RequestParam(value = "degree", required = false, defaultValue = "") String degree)
	
	
	{
		
		Map<String, Object> lNauk= bdmServiceImpl.filternaukriRecords(page, pageSize, location, experience, jobCategory, degree, gender,currentlocation,annualSalary);
		
	/*	if(lNauk == null || lNauk.size() > 500 ) {
			return lNauk.stream().limit(500).collect(Collectors.toList());
		}*/
		
Map<String, Object> Nauk = new HashMap<>();
		
		Nauk.put("sEcho", page);
		Nauk.put("iTotalRecords", lNauk.get("totalCount"));
		Nauk.put("iTotalDisplayRecords", pageSize);
		Nauk.put("aaData", lNauk.get("request"));
		Nauk.put("totalPages", lNauk.get("totalPages"));
		
		/*
		 * if(lNauk == null || lNauk.size() > 500 ) { return
		 * lNauk.stream().limit(500).collect(Collectors.toList()); }
		 */

		return Nauk;
	}
	
	@PostMapping(value = URLMapper.BDM_NAUKRI_FILTER)
	public String naukriFilterData(@ModelAttribute(name = "abc") FilterInput input, Model model) {
		
		Map<String, Object> col = jNaukriFilterData(input.getPage(), input.getPageSize(), input.getLocation(), input.getExperience(), input.getJobCategory(), input.getQualification(),input.getCurrentlocation(),input.getGender(),input.getAnnualSalary());
		model.addAttribute("request", col.get("request"));
		model.addAttribute("totalPages", col.get("totalPages"));
		model.addAttribute("count", col.get("totalCount"));
		
//		model.addAttribute("keySkill", naukriDownloadRecord.getKeySkill());
			model.addAttribute("location", naukriDownloadRecord.getLocations());
			model.addAttribute("qualification", naukriDownloadRecord.getQualification());
			model.addAttribute("jobCategory", naukriDownloadRecord.getJobCategory());
	//		model.addAttribute("experience", IntStream.range(1, 20).boxed().map(i -> String.valueOf(i) + " Year(s)").collect(Collectors.toSet()));
	//		System.out.println(IntStream.range(1, 20).boxed().map(i -> String.valueOf(i) + " Year(s)").collect(Collectors.toSet()));
//			model.add
			model.addAttribute("abc", new FilterInput());
		
		return ViewMapper.BDM_BDM_SILVER_SERVER;
	
	}
	
	@GetMapping(value = URLMapper.BDM_NAUKRIJOB_FILTER , produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody Map<String, Object> jNaukriJobFilterData(@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "pageSize",required = false, defaultValue = "100") int pageSize,
			@RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam(value = "from", required = false, defaultValue = "-1" ) int from,
			@RequestParam(value = "to", required = false, defaultValue = "-1" ) int to, 
			@RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "gender", required = false, defaultValue = "") String gender,
			@RequestParam(value = "degree", required = false, defaultValue = "" ) String degree) {
		
		Map<String, Object> lNauk= bdmServiceImpl.filterNaukriJobRecords(page, pageSize, location, from, to, jobCategory, degree, gender);
		
Map<String, Object> Nauk = new HashMap<>();
		
		Nauk.put("sEcho", page);
		Nauk.put("iTotalRecords", lNauk.get("totalCount"));
		Nauk.put("iTotalDisplayRecords", pageSize);
		Nauk.put("aaData", lNauk.get("request"));
		Nauk.put("totalPages", lNauk.get("totalPages"));
		
		/*
		 * if(lNauk == null || lNauk.size() > 500 ) { return
		 * lNauk.stream().limit(500).collect(Collectors.toList()); }
		 */

		return Nauk;
		
		
	}
	
	@PostMapping(value = URLMapper.BDM_NAUKRIJOB_FILTER)
	public String naukriJobFilterData(@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "pageSize",required = false, defaultValue = "100") int pageSize,
			@RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam(value = "from", required = false, defaultValue = "-1" ) int from, 
			@RequestParam(value = "to", required = false, defaultValue = "-1" ) int to,
			@RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "gender", required = false, defaultValue = "") String gender,
			@RequestParam(value = "degree", required = false, defaultValue = "" ) String degree, Model model) {
		
		Map<String, Object> col = jNaukriJobFilterData(page, pageSize, location, from, to, jobCategory, degree,gender);
		model.addAttribute("request", col.get("request"));
		model.addAttribute("totalPages", col.get("totalPages"));
		model.addAttribute("count", col.get("totalCount"));
		
		return ViewMapper.BDM_BDM_LATESTDATA;
	
	}
	
	
	
	
	
	/*@GetMapping("/bdmSilverServer")
	public String silverServer(@RequestParam("jobCategory") String jobCategory, @RequestParam("plan") String plan,
			Model model) {
	

		switch (Integer.parseInt(plan)) {
		case 1:
			model.addAttribute("records", bdmService.getNaukriRecordsByJobCategory(jobCategory));
			break;
		case 2:
			model.addAttribute("records", bdmService.getMonsterRecordsByJobCategory(jobCategory));
			break;
		case 3:
			model.addAttribute("records", bdmService.getShineRecordsByJobCategory(jobCategory));
			break;
		case 4:
			model.addAttribute("records", bdmService.getTimesRecordsByJobCategory(jobCategory));
			break;

		default:
			model.addAttribute("records", new ArrayList());
			break;
		}

		return ViewMapper.BDM_BDM_VIEW;
	}
	
	
	@GetMapping(value = "/bdmRecordsFilter")
	public String recordFilter(@RequestParam("jobCategory") String jobCategory, @RequestParam("experience") String experience, @RequestParam("gender") String gender, @RequestParam("location") String location,
			@RequestParam("plan") String plan, Model model) {
		
		
		switch ( (jobCategory.equals("") || experience.equals("") || gender.equals("") ? 1 : jobCategory.equals("") || experience.equals("") || location.equals("") ? 2 : gender.equals("") || experience.equals("") || location.equals("") ? 3 : jobCategory.equals("") || gender.equals("") || location.equals("") ? 4 : 0) ) {

		case 1:

			break;
		case 2:

			break;
		case 3:

			break;
		case 4:

			break;

		default:
			break;
		}
		
		switch (Integer.parseInt(plan)) {
		case 1:
			
			
			model.addAttribute("records", bdmService.getNaukriRecordsByJobCategory(jobCategory));
			break;
		case 2:
			model.addAttribute("records", bdmService.getMonsterRecordsByJobCategory(jobCategory));
			break;
		case 3:
			model.addAttribute("records", bdmService.getShineRecordsByJobCategory(jobCategory));
			break;
		case 4:
			model.addAttribute("records", bdmService.getTimesRecordsByJobCategory(jobCategory));
			break;

		default:
			model.addAttribute("records", new ArrayList());
			break;
		}
				
				return plan; 
		
	}
	
	
	@RequestMapping(value="/bdmSilverServer", produces = { "application/json" })
	@ResponseBody
	public List silverServerJson(@RequestParam("jobCategory") String jobCategory, @RequestParam("plan") String plan) {
	
		System.out.println("output");
		List l = new ArrayList();
		switch (Integer.parseInt(plan)) {
		case 1:
			l =  bdmService.getNaukriRecordsByJobCategory(jobCategory);
			break;
		case 2:
			l =  bdmService.getMonsterRecordsByJobCategory(jobCategory);
			break;
		case 3:
			l =  bdmService.getShineRecordsByJobCategory(jobCategory);
			break;
		case 4:
			l =   bdmService.getTimesRecordsByJobCategory(jobCategory);
			break;

		default:
			l =    new ArrayList();
			break;
		}

		return l;
	}*/
	
	
}
