package com.eagleSystem.eagleJob.valueObject;

import java.util.Date;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class SingleJobRequest {
	
	private Long postId;
	
	@NotEmpty(message = "cannot be blank")
	private String companyName = "";
	
	@Email
	@NotEmpty(message = "cannot be blank")
	private String companyEmail = "";
	
	@NotEmpty(message = "Contact Number cannot be blank")
	private Long contactNumber;
	
	@NotEmpty(message = "Company Website cannot be blank")
	private String companyWebsite = "";
	
	@NotEmpty(message = "Company Address cannot be blank")
	private String companyAddress = "";
	
	@NotEmpty(message = "Functional Area cannot be blank")
	private String jobCategory = "";
	
	@NotEmpty(message = "Job Type cannot be blank")
	private String jobType = "";
	
	@NotEmpty(message = "KeySkill cannot be blank")
	private String keySkill = "";
	
	private int experienceFrom;
	private int experienceTo = 0;
	
	@NotEmpty(message = "Job Title cannot be blank")
	private String jobProfile = "";
	
	@NotEmpty(message = "Job Detail cannot be blank")
	private String jobDetail = "";
	
	private Date walkinStartDate;
	private Date walkinEndDate;
	
	@NotEmpty(message = "Contact Person cannot be blank")
	private String contactPerson = "";
	private Date postedOn; 
	
	private boolean isDeleted;

	private Long salary;
	
	private String location;
	
	public Long getPostId() {
		return postId;
	}
	public void setPostId(Long postId) {
		this.postId = postId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyEmail() {
		return companyEmail;
	}
	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}
	public Long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getCompanyWebsite() {
		return companyWebsite;
	}
	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}
	
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getKeySkill() {
		return keySkill;
	}
	public void setKeySkill(String keySkill) {
		this.keySkill = keySkill;
	}
	public int getExperienceFrom() {
		return experienceFrom;
	}
	public void setExperienceFrom(int experienceFrom) {
		this.experienceFrom = experienceFrom;
	}
	public int getExperienceTo() {
		return experienceTo;
	}
	public void setExperienceTo(int experienceTo) {
		this.experienceTo = experienceTo;
	}
	public String getJobProfile() {
		return jobProfile;
	}
	public void setJobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}
	public String getJobDetail() {
		return jobDetail;
	}
	public void setJobDetail(String jobDetail) {
		this.jobDetail = jobDetail;
	}
	public Date getWalkinStartDate() {
		return walkinStartDate;
	}
	public void setWalkinStartDate(Date walkinStartDate) {
		this.walkinStartDate = walkinStartDate;
	}
	public Date getWalkinEndDate() {
		return walkinEndDate;
	}
	public void setWalkinEndDate(Date walkinEndDate) {
		this.walkinEndDate = walkinEndDate;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	
	public Date getPostedOn() {
		return postedOn;
	}
	public void setPostedOn(Date postedOn) {
		this.postedOn = postedOn;
	}
	
	public SingleJobRequest() {
		super();
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getJobCategory() {
		return jobCategory;
	}
	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}
	public Long getSalary() {
		return salary;
	}
	public void setSalary(Long salary) {
		this.salary = salary;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "SingleJobRequest [postId=" + postId + ", companyName=" + companyName + ", companyEmail=" + companyEmail
				+ ", contactNumber=" + contactNumber + ", companyWebsite=" + companyWebsite + ", companyAddress="
				+ companyAddress + ", jobCategory=" + jobCategory + ", jobType=" + jobType + ", keySkill=" + keySkill
				+ ", experienceFrom=" + experienceFrom + ", experienceTo=" + experienceTo + ", jobProfile=" + jobProfile
				+ ", jobDetail=" + jobDetail + ", walkinStartDate=" + walkinStartDate + ", walkinEndDate="
				+ walkinEndDate + ", contactPerson=" + contactPerson + ", postedOn=" + postedOn + ", isDeleted="
				+ isDeleted + ", salary=" + salary + ", location=" + location + "]";
	}
	
	
}
