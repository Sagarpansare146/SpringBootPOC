package com.eagleSystem.eagleJob.service;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.eagleSystem.eagleJob.valueObject.EmailNotifyInputs;

public interface ExcelRecords {

	public List<String> excel(HttpServletRequest request, HttpServletResponse response, EmailNotifyInputs inputs) throws Exception;
	public String fileReader(HttpServletRequest request, HttpServletResponse response, EmailNotifyInputs inputs);
	public List<String> xlsReader(File fileInput)  throws Exception;
	public List<String> xlsxReader(File fileInput)  throws Exception;
}
