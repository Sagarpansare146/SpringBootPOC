package com.eagleSystem.eagleJob.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.eagleSystem.eagleJob.service.bdm.BdmClientServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eagleSystem.eagleJob.bussinessObject.RecruiterBO;
import com.eagleSystem.eagleJob.dao.CandidateApplicationRepository;
import com.eagleSystem.eagleJob.dao.CandidatePrefRepository;
import com.eagleSystem.eagleJob.dao.CandidateRepository;
import com.eagleSystem.eagleJob.dao.CompanyRepository;
import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.dao.MasterPlanRepository;
import com.eagleSystem.eagleJob.dao.QualificationRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.Candidate;
import com.eagleSystem.eagleJob.entity.CandidatePreference;
import com.eagleSystem.eagleJob.entity.Company;
import com.eagleSystem.eagleJob.entity.JPUser;
import com.eagleSystem.eagleJob.entity.MasterPlan;
import com.eagleSystem.eagleJob.entity.Qualification;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.util.JobBOPrepareUtil;
import com.eagleSystem.eagleJob.util.JobModelPrepareUtil;
import com.eagleSystem.eagleJob.util.RecruiterBOPrepareUtil;
import com.eagleSystem.eagleJob.util.RecruiterModelUtilPrepare;
import com.eagleSystem.eagleJob.util.Role;
import com.eagleSystem.eagleJob.valueObject.CandidateExcelRecords;
import com.eagleSystem.eagleJob.valueObject.CandidateRecords;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;
import com.querydsl.core.types.Predicate;

@Transactional
@Service
public class RecruiterServiceImpl implements RecruiterService {

	@Autowired
	RecruiterBOPrepareUtil recruiterBOPrepareUtil;

	@Autowired
	QualificationRepository qualifactionRepository;

	@Autowired
	RecruiterModelUtilPrepare recruiterModelUtilPrepare;

	@Autowired
	CandidateRepository candidateRepository;

	@Autowired
	CandidateService candidateService;

	@Autowired
	CandidatePrefRepository candidatePrefRepository;

	@Autowired
	JPUserRepository jpUserRepository;

	@Autowired
	RecruiterRepository recruiterRepository;

	@Autowired
	CompanyRepository companyRepository;

	@Autowired
	JobBOPrepareUtil jobUtil;

	@Autowired
	JobModelPrepareUtil modelPrepareUtil;

	@Autowired
	CandidateApplicationRepository candidateApplicationRepository;

	@Autowired
	MasterPlanRepository masterPlanRepository;

	public boolean regRecruiter(RecruiterRegistrationRequest request) {

		boolean flag = false;
		RecruiterBO recruiterBO = recruiterBOPrepareUtil.prepareRecruiterBO(request);
		recruiterBO.setCompany(recruiterBOPrepareUtil.prepareCompanyBO(request));

		Recruiter recruiter = recruiterModelUtilPrepare.getRecruiter(recruiterBO);
		Company company = recruiterModelUtilPrepare.getCompany(recruiterBO.getCompany());

		JPUser jpUser = new JPUser();

		jpUser.setUsername(request.getUsername());
		jpUser.setPassword(request.getPassword());
		jpUser.setEnabled(true);
		jpUser.setRole(Role.recruiter.name());

		MasterPlan mp = masterPlanRepository.findOne(1l);

		// mp.setId(1l);
		// mp.setPName("Trial");
		// mp.setValidity(30);
		// mp.setAmount(0);
		// mp.setResumeDownloadLimit(20);
		// mp.setExcelRecordsLimit(20);

		// masterPlanRepository.save(mp);

		recruiter.setMasterPlan(mp);
		recruiterRepository.save(recruiter);

		company.setRecruiter(recruiter);
		companyRepository.save(company);
		jpUserRepository.save(jpUser);

		System.out.println(recruiter);
		flag = true;

		return flag;
	}

	@Override
	public RecruiterBO getRecruiterByUsername(String username) {

		return recruiterBOPrepareUtil.getRecruiterBO(recruiterRepository.findByUsername(username));
	}

	@Override
	public RecruiterRegistrationRequest getRecruiterData(String username) {

		System.out.println(recruiterRepository.findByUsername(username));
		RecruiterBO recruiterBO = recruiterBOPrepareUtil.getRecruiterBO(recruiterRepository.findByUsername(username));
		recruiterBO.setCompany(recruiterBOPrepareUtil.getCompanyBO(companyRepository.findOne(recruiterBO.getId())));

		RecruiterRegistrationRequest request = recruiterBOPrepareUtil.getRecruiterRequestData(recruiterBO);

		System.out.println(request);

		return request;
	}

	@Override
	public boolean updateRecruiterProfile(RecruiterRegistrationRequest request) {

		boolean flag = false;
		/*
		 * RecruiterBO recruiterBO = recruiterBOPrepareUtil.prepareRecruiterBO(request);
		 * recruiterBO.setCompany(recruiterBOPrepareUtil.prepareCompanyBO(request));
		 * 
		 * Recruiter recruiter = recruiterModelUtilPrepare.getRecruiter(recruiterBO);
		 * Company company =
		 * recruiterModelUtilPrepare.getCompany(recruiterBO.getCompany());
		 * 
		 * recruiterRepository.save(recruiter);
		 * 
		 * company.setRecruiter(recruiter); companyRepository.save(company);
		 */

		Recruiter rec = recruiterRepository.findOne(request.getRecruiterId());
		rec.setId(request.getRecruiterId());
		rec.setEmail(request.getEmail());
		rec.setMobNo(request.getMobNo());
		rec.setName(request.getRecruiterName());
		rec.setDesignation(request.getDesignation());

		Company comp = new Company();

		comp.setId(request.getRecruiterId());
		comp.setAddress(request.getCompanyAddress());
		comp.setCity(request.getCity());
		comp.setDiscription(request.getDetail());
		comp.setGSTNO(request.getGSTNO());
		comp.setName(request.getCompanyName());
		comp.setState(request.getState());
		comp.setType(request.getCompanyType());
		comp.setRecruiter(rec);

		recruiterRepository.save(rec);

		companyRepository.save(comp);

		System.out.println(rec);
		flag = true;

		return flag;

	}

	public List<CandidateExcelRecords> downloadExcelRecords(Long cadId[], Long jobId) {

		return gDownloadExcelRecords(cadId);

	}
	
	public List<CandidateExcelRecords> bdmDownloadExcelRecords(Long cadId[]) {
	return comDownloadExcelRecords(cadId);
	}
	
	public List<CandidateExcelRecords> gDownloadExcelRecords(Long cadId[]) {
	return comDownloadExcelRecords(cadId);
	}
	
	public List<CandidateExcelRecords> recDownloadExcelRecords(Long cadId[]) {
		return comDownloadExcelRecords(cadId);
		}
	
	public List<CandidateExcelRecords> comDownloadExcelRecords(Long cadId[]) {

		List<Long> cIds = Arrays.asList(cadId);
		// List<BigInteger> cIds1 =
		// candidateApplicationRepository.findCandidateIdsByJobPost(jobId);

		List<CandidateExcelRecords> records = new ArrayList<CandidateExcelRecords>();

		/*
		 * for(BigInteger b : cIds) cIds.add(b.longValue());
		 */

		for (Long id : cIds) {

			CandidateExcelRecords canRec = new CandidateExcelRecords();

			Candidate c = candidateRepository.findOne(id);
			CandidatePreference canPref = candidatePrefRepository.findOne(id);
			Qualification qual = qualifactionRepository.findOne(id);

			canRec.setId(c.getId());
			canRec.setName(c.getName());
			canRec.setEmail(c.getEmail());
			canRec.setCandidateCity(c.getCity());
			canRec.setContactNumber(c.getContactNumber());
			canRec.setDegree(qual.getDegree());
			canRec.setExperience(qual.getExperience() + " Years");
			canRec.setGender(c.getGender());
			canRec.setJobCategory(canPref.getJobCategory());
			canRec.setKeySkill(canPref.getKeySkill());
			canRec.setLocation(canPref.getLocation());
			canRec.setMonth(qual.getMonth() + " Months");
			canRec.setPassout(qual.getPassout());
			canRec.setPercentage(qual.getPercentage());
			canRec.setSpecilization(qual.getSpecilization());
			canRec.setUniversity(qual.getUniversity());

			records.add(canRec);
			
		}
		System.out.println(records);
		return records;

	}

	public Map<Long, CandidatePreference> downloadResume(List<Long> ids, Long jobId) {

		Map<Long, CandidatePreference> map = new HashMap<>();
		for (Long id : ids) {
			map.put(id, candidatePrefRepository.findOne(id));
		}

		return map;
	}

	public List<CandidateRecords> jobByLoc(Long jobId, String location) {

		List<Long> jobIds1 = candidateApplicationRepository.findCandidateIdsByJobPost(jobId);
		List<Long> jobIds2 = candidatePrefRepository.findIdByLocation(location);
		List<Long> jobIds = new ArrayList<Long>(jobIds1);

		jobIds.retainAll(jobIds2);

		List<CandidateRecords> cadRec;

		cadRec = candidateService.prepareRecordsObj(jobIds);

		return cadRec;

	}

	/*
	 * public List<CandidateRecords> jobByJobCategory(Long jobId, String
	 * jobCategory) { List<BigInteger> jobIds1 =
	 * candidateApplicationRepository.findCandidateIdsByJobPost(jobId);
	 * List<BigInteger> jobIds2 =
	 * candidatePrefRepository.findIdByJobCategory(jobCategory); List<BigInteger>
	 * jobIds3 = new ArrayList<BigInteger>(jobIds1);
	 * 
	 * jobIds3.retainAll(jobIds2);
	 * 
	 * List<Long> jobIds = new ArrayList<Long>(); List<CandidateRecords> cadRec;
	 * 
	 * for(BigInteger bi : jobIds3) { jobIds.add(bi.longValue()); }
	 * 
	 * cadRec = candidateService.prepareRecordsObj(jobIds);
	 * 
	 * return cadRec;
	 * 
	 * }
	 */

	public List<CandidateRecords> jobByExp(Long jobId, Integer exp) {
		List<Long> jobIds1 = candidateApplicationRepository.findCandidateIdsByJobPost(jobId);
		List<Long> jobIds2 = qualifactionRepository.findIdByExp(exp);
		List<Long> jobIds = new ArrayList<Long>(jobIds1);

		jobIds.retainAll(jobIds2);

		List<CandidateRecords> cadRec;

		cadRec = candidateService.prepareRecordsObj(jobIds);

		return cadRec;

	}

	public List<CandidateRecords> filterRecords(Long jobId, String location, int from, int to, String jobCategory,
			String degree, String gender) {

		List<CandidatePreference> lCad = new ArrayList<>();
		List<Qualification> lQaul = new ArrayList<>();

		
		List<Long> appliedIds = candidateApplicationRepository.findCandidateIdsByJobPost(jobId);

		lCad = candidatePrefRepository.findAll(BdmClientServiceImpl.filterNaukriJobSpecification(location, jobCategory, gender));
		lQaul = qualifactionRepository.findAll(BdmClientServiceImpl.filterNaukriJobSpecification1(from, to, degree));

		Set<Long> jobIds = new HashSet<>();
		List<Long> finalIds = new ArrayList<>();
//		Map<String, Object> map = new HashMap<>();
		
		if (lCad.isEmpty() && lQaul.isEmpty()) {
			finalIds = appliedIds;
		} else if (lQaul.isEmpty()) {
			jobIds = lCad.stream().map(cad -> cad.getCid()).collect(Collectors.toSet());
			finalIds.addAll(jobIds);

		} else {
			System.out.println("else");
			jobIds = lCad.stream().map(cad -> cad.getCid()).collect(Collectors.toSet());
			Set<Long> jobIds1 = lQaul.stream().map(qual -> qual.getQid()).collect(Collectors.toSet());
			finalIds = jobIds.stream().filter(li -> (jobIds1.contains(li))).collect(Collectors.toList());

		}
		finalIds = finalIds.stream().filter(li -> (appliedIds.contains(li))).collect(Collectors.toList());
		List<CandidateRecords> cadRec = candidateService.prepareRecordsObj(finalIds);
		return cadRec;

	}



}
