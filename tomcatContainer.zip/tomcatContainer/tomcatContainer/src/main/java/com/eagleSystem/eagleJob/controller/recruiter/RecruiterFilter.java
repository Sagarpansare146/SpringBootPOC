package com.eagleSystem.eagleJob.controller.recruiter;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.eagleSystem.eagleJob.BusinessClientNaukri;
import com.eagleSystem.eagleJob.ExcelBuilder;
import com.eagleSystem.eagleJob.businessExcel.ClientNaukriExcelDownload;
import com.eagleSystem.eagleJob.entity.ClientNaukriExcelRecord;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.service.bdm.BdmClientServiceImpl;
import com.eagleSystem.eagleJob.service.bdm.BdmReportService;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.CandidateExcelRecords;
import com.eagleSystem.eagleJob.valueObject.FilterInput;


@Controller
public class RecruiterFilter {

	@Autowired
	BdmClientServiceImpl bdmClientServiceImpl;
	
	@Autowired
	RecruiterService recruiterService;
	
	@Autowired
	ClientNaukriExcelDownload clientNaukriExcelDownload;

	@Autowired
	BdmReportService bdmReportService;

	@GetMapping("/recruiterNaukriPage")
	public String bdmSilverServerPage(Model model) {
		
	//	model.addAttribute("keySkill", naukriDownloadRecord.getKeySkill());
		model.addAttribute("location", clientNaukriExcelDownload.getLocations());
		model.addAttribute("qualification", clientNaukriExcelDownload.getQualification());
		model.addAttribute("jobCategory", clientNaukriExcelDownload.getJobCategory());
		model.addAttribute("currentlocation", clientNaukriExcelDownload.getcurrentLocations().stream().map(e -> e.trim()).collect(Collectors.toList()));
				model.addAttribute("annualSalary", clientNaukriExcelDownload.getannualSalary().stream().filter(e -> e.contains("INR")).collect(Collectors.toList()));
;
		
		
      
//		model.addAttribute("experience", IntStream.range(1, 20).boxed().map(i -> String.valueOf(i) + " Year(s)").collect(Collectors.toSet()));
//		model.add
		model.addAttribute("abc", new FilterInput());
		return ViewMapper.RECRUITER_NAUKRI;
	}
	

	@GetMapping("/recruiterNaukriJobFilter")
	public String recruiterNaukriJobFilter() {
		return ViewMapper.RECRUITER_NAUKRIJOBFILTER;
	}

/*	@GetMapping("/recruiterNaukriPage")
	public String recruiterNaukriPage() {
		return ViewMapper.RECRUITER_NAUKRI;
	}*/

	
	@RequestMapping(value = URLMapper.RECRUITER_NAUKRIJOB_EXCEL_RECORDS, method = RequestMethod.GET)
	public ModelAndView downloadNaukriJobExcelRecords(Authentication auth, Map<String, Object> model, 
			@RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam("ids") Long... ids) {

		String s1 = (location.equals("") ? "" : location) + "_" + (jobCategory.equals("") ? "" : jobCategory);
		
		List<CandidateExcelRecords> records = recruiterService.recDownloadExcelRecords(ids);
		model.put("request", records);
		model.put("name", "NaukriJobServer2"+ "_" +s1);

		return new ModelAndView(new ExcelBuilder(), "records", records);

	} 

    @RequestMapping(value = URLMapper.RECRUITER_NAUKRI_EXCEL_RECORDS, method = RequestMethod.GET)
    public ModelAndView downloadNaukriExcelRecords(Authentication auth, Map<String, Object> model, @RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam(value = "experience", required = false, defaultValue = "-1") int experience, 
			@RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "degree", required = false, defaultValue = "") String degree,
			@RequestParam("ids") Long... ids) {

		String s = (experience == -1 ? "" : String.valueOf(experience)) + "_" + (location.equals("") ? "" : location) + "_" + (jobCategory.equals("") ? "" : jobCategory)+ "_" +(degree.equals("") ? "" : degree);
		
	
        List<ClientNaukriExcelRecord> records = bdmClientServiceImpl.recbdmDownloadClientNaukriExcelRecord(ids);
        model.put("request", records);
        model.put("industry", "NaukriJobServer1"+ "_" +s);

        return new ModelAndView(new BusinessClientNaukri(), "records", records);

    }
	
	@RequestMapping(value = URLMapper.RECRUITER_NAUKRIJOB_RESUME_DOWNLOAD, produces = "application/zip", method = RequestMethod.GET)
	public void downloadNaukriJobResume(HttpServletRequest request, HttpServletResponse response, Authentication auth,
			Long... cadId) throws Exception {

		if(auth == null ? true : false) {
			
			throw new Exception("Invalid User");
		}
		
//		Map<Long, CandidatePreference> map;
		response.setContentType("application/zip");
		response.setStatus(HttpServletResponse.SC_OK);
	//	JobPost jobPost = jobRepository.findOne(jobId);
		response.addHeader("Content-Disposition", "attachment; filename=\"" + "NaukriJob" + ".zip\"");
		
		try {

	//		map = recruiterService.downloadResume(Arrays.asList(cadId), jobId);

			
			List<String> filenames = bdmClientServiceImpl.recResumeNaukriJobPath(cadId);

			if(filenames == null)
				filenames = new ArrayList<>();
				
			System.out.println(filenames);
			
/*			for (Long id : Arrays.asList(cadId)) {
				srcFiles.add("c:" + File.separator + map.get(id).getResume());
			}
*/			
			String str = "c:" + File.separator;
			List<String> srcFiles = filenames.stream().map(s -> str + s).collect(Collectors.toList());
	
			System.out.println(srcFiles);
			
			OutputStream fos = response.getOutputStream();

			ZipOutputStream zipOut = new ZipOutputStream(fos);
			for (String srcFile : srcFiles) {
				File fileToZip = new File(srcFile);
				if ((fileToZip.exists())) {
					
					FileInputStream fis = new FileInputStream(fileToZip);
					ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
					zipOut.putNextEntry(zipEntry);
					System.out.println(zipEntry);
					byte[] bytes = new byte[8096];
					int length;
					while ((length = fis.read(bytes)) >= 0) {
						zipOut.write(bytes, 0, length);

					}
					fis.close();
					
				}
				System.out.println("file not found");
				
			}
			zipOut.close();
			fos.close();

		} catch (IOException e) {
			System.out.println("Error:- " + e.getMessage());
		} catch (Exception e) {

			e.printStackTrace();
		}

	}
	
	@RequestMapping(value = URLMapper.RECRUITER_NAUKRIJOBDOWNLOAD , method = RequestMethod.POST)
	public ModelAndView download(HttpServletRequest request, HttpServletResponse response, Authentication auth,
			@RequestParam("action") String action, Map<String, Object> model,
			@RequestParam("id") Long... cadId) throws Exception {

		ModelAndView mav = null;

		try {

			if (action.contains("Excel")) {
				mav = downloadNaukriJobExcelRecords(auth, model, action, action, cadId);

			} else {
				downloadNaukriJobResume(request, response, auth, cadId);
			}
		} catch (IOException e) {
			System.out.println("Error:- " + e.getMessage());
		}
		return mav;
	}
	

	@GetMapping(value = URLMapper.RECRUITER_NAUKRIJOB , produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody Map<String, Object> jNaukriJobFilterData(@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "pageSize",required = false, defaultValue = "100") int pageSize,
			@RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam(value = "from", required = false, defaultValue = "-1" ) int from,
			@RequestParam(value = "to", required = false, defaultValue = "-1" ) int to, 
			@RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "degree", required = false, defaultValue = "" ) String degree,
			@RequestParam(value = "gender", required = false, defaultValue = "") String gender) {
		
		Map<String, Object> lNauk= bdmClientServiceImpl.filterNaukriJobRecords(page, pageSize, location, from, to, jobCategory, degree, gender);

        Map<String, Object> Nauk = new HashMap<>();

        Nauk.put("sEcho", page);
        Nauk.put("iTotalRecords", lNauk.get("totalCount"));
        Nauk.put("iTotalDisplayRecords", pageSize);
        Nauk.put("aaData", lNauk.get("request"));
        Nauk.put("totalPages", lNauk.get("totalPages"));

		return Nauk;
	}
	
	@PostMapping(value = URLMapper.RECRUITER_NAUKRIJOB)
	public String naukriJobFilterData(@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "pageSize",required = false, defaultValue = "100") int pageSize,
			@RequestParam(value = "location", required = false, defaultValue = "") String location,
			@RequestParam(value = "from", required = false, defaultValue = "-1" ) int from, @RequestParam(value = "to", required = false, defaultValue = "-1" ) int to, @RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
			@RequestParam(value = "degree", required = false, defaultValue = "" ) String degree,
			@RequestParam(value = "gender", required = false, defaultValue = "") String gender, Model model) {
		
		Map<String, Object> col = jNaukriJobFilterData(page, pageSize, location, from, to, jobCategory, degree, gender);
		model.addAttribute("request", col.get("request"));
		model.addAttribute("totalPages", col.get("totalPages"));
		model.addAttribute("count", col.get("totalCount"));
		
		return ViewMapper.RECRUITER_NAUKRIJOBFILTER;
	
	}
	
	

	@GetMapping(value = URLMapper.RECRUITER_NAUKRI , produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody Map<String, Object> jNaukriFilterData(@RequestParam(name = "page", required = false, defaultValue = "1") int page,
															   @RequestParam(name = "pageSize",required = false, defaultValue = "100") int pageSize,
															   @RequestParam(value = "location", required = false, defaultValue = "") String location, 
															   @RequestParam(value = "experience", required = false, defaultValue = "-1") int experience,
															   @RequestParam(value = "jobCategory", required = false, defaultValue = "") String jobCategory,
															   @RequestParam(value = "degree", required = false, defaultValue = "") String degree,
															   @RequestParam(value = "currentlocation", required = false, defaultValue = "") String currentlocation,
															   @RequestParam(value = "annualSalary", required = false, defaultValue = "") String annualSalary,
																@RequestParam(value = "gender", required = false, defaultValue = "") String gender) {

		Map<String, Object> lNauk= bdmClientServiceImpl.filternaukriRecords(page, pageSize, location, experience, jobCategory, degree, gender,currentlocation,annualSalary);

		Map<String, Object> Nauk = new HashMap<>();

		Nauk.put("sEcho", page);
		Nauk.put("iTotalRecords", lNauk.get("totalCount"));
		Nauk.put("iTotalDisplayRecords", pageSize);
		Nauk.put("aaData", lNauk.get("request"));
		Nauk.put("totalPages", lNauk.get("totalPages"));

		return Nauk;
	}

/*	@PostMapping(value = URLMapper.RECRUITER_NAUKRI)
	public String naukriFilterData(@ModelAttribute(name = "abc") FilterInput input, Model model) {

		Map<String, Object> col = jNaukriFilterData(input.getPage(), input.getPageSize(), input.getLocation(), input.getExperience(), input.getJobCategory(), input.getQualification());
		model.addAttribute("request", col.get("request"));
		model.addAttribute("totalPages", col.get("totalPages"));
		model.addAttribute("count", col.get("totalCount"));

//		model.addAttribute("keySkill", naukriDownloadRecord.getKeySkill());
		model.addAttribute("location", naukriDownloadRecord.getLocations());
		model.addAttribute("qualification", naukriDownloadRecord.getQualification());
		model.addAttribute("jobCategory", naukriDownloadRecord.getJobCategory());
		//		model.addAttribute("experience", IntStream.range(1, 20).boxed().map(i -> String.valueOf(i) + " Year(s)").collect(Collectors.toSet()));
		//		System.out.println(IntStream.range(1, 20).boxed().map(i -> String.valueOf(i) + " Year(s)").collect(Collectors.toSet()));
//			model.add
		model.addAttribute("abc", new FilterInput());

		return ViewMapper.BDM_BDM_SILVER_SERVER;

	}*/
	
	}
