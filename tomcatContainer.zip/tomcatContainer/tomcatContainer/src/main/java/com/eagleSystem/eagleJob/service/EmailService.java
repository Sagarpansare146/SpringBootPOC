/**
 * 
 */
package com.eagleSystem.eagleJob.service;

import java.io.UnsupportedEncodingException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.bussinessObject.Email;
import com.eagleSystem.eagleJob.util.ApplicationLogger;

/**
 * @author pavan.solapure
 *
 */
@Component
public class EmailService {

	@Autowired
	private JavaMailSender mailSender;

	private static final ApplicationLogger logger = ApplicationLogger.getInstance();

	public void send(Email eParams) throws MessagingException {
		try {
			sendHtmlMail(eParams);
		} catch (UnsupportedEncodingException e) {
			System.out.println("hee haa haa");
			e.printStackTrace();
		}

		/*
		 * if (eParams.isHtml()) { try { sendHtmlMail(eParams); } catch
		 * (MessagingException e) {
		 * logger.error("Could not send email to : {} Error = {}",
		 * eParams.getToAsList(), e.getMessage()); } } else {
		 * sendPlainTextMail(eParams); }
		 */

	}

	private void sendHtmlMail(Email eParams) throws MessagingException, UnsupportedEncodingException {

		boolean isHtml = true;

		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);
		helper.setTo(eParams.getTo().toArray(new String[eParams.getTo().size()]));
		helper.setReplyTo(String.valueOf(eParams.getFrom()));
		helper.setFrom(String.valueOf(eParams.getFrom()));
		helper.setSubject(eParams.getSubject());
		helper.setFrom("career@naukrijob.co.in", eParams.getSenderName());
		helper.setText(eParams.getMessage(), isHtml);

		mailSender.send(message);
	}

	public void sendPlainTextMail(Email eParams, String senderName, String from)
			throws MessagingException, UnsupportedEncodingException {

		// SimpleMailMessage mailMessage = new SimpleMailMessage();

		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper mailMessage = new MimeMessageHelper(message);

		eParams.getTo().toArray(new String[eParams.getTo().size()]);
		mailMessage.setTo(eParams.getTo().toArray(new String[eParams.getTo().size()]));
		// mailMessage.setReplyTo(String.valueOf(eParams.getFrom()));
		// helper.setFrom("Career@naukrijob.co.in", "NaukriJob");

		mailMessage.setFrom(from, senderName);
		mailMessage.setSubject(eParams.getSubject());
		mailMessage.setText(eParams.getMessage());

		if (eParams.getCc().size() > 0) {
			mailMessage.setCc(eParams.getCc().toArray(new String[eParams.getCc().size()]));
		}

		mailSender.send(message);

	}

}
