package com.eagleSystem.eagleJob.businessExcel;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.dao.ClientNaukriRepository;
import com.eagleSystem.eagleJob.dao.MonsterExcelRepository;
import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;
import com.eagleSystem.eagleJob.dao.ShineExcelRepository;
import com.eagleSystem.eagleJob.dao.TimesExcelRepository;
import com.eagleSystem.eagleJob.entity.MonsterExcelRecord;
import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;
import com.eagleSystem.eagleJob.entity.ShineExcelRecord;
import com.eagleSystem.eagleJob.entity.TimesExcelRecord;
import com.eagleSystem.eagleJob.entity.ClientNaukriExcelRecord;


@Component
public class ExcelToDb {
	
	@Autowired
	NaukriExcelRepository naukriExcelRepository;
	
	@Autowired
	ShineExcelRepository shineExcelRepository;
	
	@Autowired
	MonsterExcelRepository monsterExcelRepository;
	
	@Autowired
	TimesExcelRepository timesExcelRepository;
	
	@Autowired
	ClientNaukriRepository clientNaukriRepository;

	
	public int saveNaukriRecords(List record) {
		int errorCount = 0;
		List<NaukriExcelRecord> records = new ArrayList<>(record);

		for (NaukriExcelRecord e : records) {
			try {
				 naukriExcelRepository.save(e);
			} catch (Exception e1) {
				e1.printStackTrace();
				errorCount = errorCount + 1;
			}
		}
		return errorCount;
	}

	public int saveShineRecords(List record) {
		int errorCount = 0;
		List<ShineExcelRecord> records = new ArrayList<>(record);

		for (ShineExcelRecord e : records) {
			try {
				shineExcelRepository.save(e);
			} catch (Exception e1) {
				e1.printStackTrace();
				errorCount = errorCount + 1;
			}
		}
		return errorCount;
	}
	
	public int saveMonsterRecords(List record) {
		int errorCount = 0;
		List<MonsterExcelRecord> records = new ArrayList<>(record);

		for (MonsterExcelRecord e : records) {
			try {
				 monsterExcelRepository.save(e);
			} catch (Exception e1) {
				e1.printStackTrace();
				errorCount = errorCount + 1;
			}
		}
		return errorCount;
	}
	
	public int saveTimesRecords(List record) {
		int errorCount = 0;
		List<TimesExcelRecord> records = new ArrayList<>(record);

		for (TimesExcelRecord e : records) {
			try {
				 timesExcelRepository.save(e);
			} catch (Exception e1) {
				e1.printStackTrace();
				errorCount = errorCount + 1;
			}
		}
		return errorCount;
	}
	
	public int saveClientNaukriRecords(List record) {
		int errorCount = 0;
		List<ClientNaukriExcelRecord> records = new ArrayList<>(record);

		for (ClientNaukriExcelRecord e : records) {
			try {
				clientNaukriRepository.save(e);
			} catch (Exception e1) {
				e1.printStackTrace();
				errorCount = errorCount + 1;
			}
		}
		return errorCount;
	}

}
