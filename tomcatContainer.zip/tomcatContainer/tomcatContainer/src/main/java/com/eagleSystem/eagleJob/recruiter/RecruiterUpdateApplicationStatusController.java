package com.eagleSystem.eagleJob.recruiter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.eagleSystem.eagleJob.dao.CandidateApplicationRepository;

@Controller
public class RecruiterUpdateApplicationStatusController {

	@Autowired
	CandidateApplicationRepository candidateApplicationRepository;

	/*@RequestMapping(value = URLMapper.EMPLOYER_UPDATE_APPLICATION_STATUS)
	public String updateStatus(
			@RequestParam("jobId") Long jobId,
			@RequestParam("candidateId") Long candidateId,
			@RequestParam("status") String status,
			Authentication auth
			){
		CandidateApplication candidateApplication = candidateApplicationRepository.
				findByJobPostAndCandidate(jobId, candidateId);

		candidateApplication.setApplicationStatus(status);
//		candidateApplication.setEmployerActionOn(new Date());

		candidateApplicationRepository.save(candidateApplication);

		return "redirect:"+URLMapper.EMPLOYER_VIEW_JOB_RESPONSES+"?jobId="+jobId;
	}*/
}