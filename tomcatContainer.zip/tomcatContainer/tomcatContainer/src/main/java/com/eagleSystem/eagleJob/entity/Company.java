package com.eagleSystem.eagleJob.entity;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "COMPANY", uniqueConstraints = {@UniqueConstraint(columnNames = {"name", "GSTNO"})})
public class Company {

	@Id
	@GeneratedValue(generator = "foreign_gen")
	@GenericGenerator(name="foreign_gen", strategy = "foreign", parameters=
	@Parameter(name="property", value="recruiter"))
	private Long id;
	
	@Column(name = "TYPE")
	private String type;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "CITY")
	private String city;
	
	@Column(name = "STATE")
	private String state;
	
	@Column(name = "ADDRESS")
	private String address;
	
	@Column(name ="DISCRIPTION")
	private String discription;
	
	@Column(name = "GSTNO")
	private String GSTNO;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private Recruiter recruiter;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	public String getGSTNO() {
		return GSTNO;
	}

	public void setGSTNO(String gSTNO) {
		GSTNO = gSTNO;
	}

	public Recruiter getRecruiter() {
		return recruiter;
	}

	public void setRecruiter(Recruiter recruiter) {
		this.recruiter = recruiter;
	}

	@Override
	public String toString() {
		return "Company [id=" + id + ", type=" + type + ", name=" + name + ", city=" + city + ", state=" + state
				+ ", address=" + address + ", discription=" + discription + ", GSTNO=" + GSTNO + ", recruiter="
				+ recruiter + "]";
	}

	
}
 