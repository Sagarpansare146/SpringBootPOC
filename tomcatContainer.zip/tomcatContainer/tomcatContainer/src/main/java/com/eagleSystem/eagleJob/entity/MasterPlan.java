package com.eagleSystem.eagleJob.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "MASTER_PLAN")
public class MasterPlan {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PID")
	private Long id;
	
	@Column(name = "PNAME")
	private String PName;
	
	@Column(name = "EXCEL_RECORDS_LIMIT")
	private int excelRecordsLimit;
	
	@Column(name = "RESUME_DOWNLOAD_LIMIT")
	private int resumeDownloadLimit;
	
	@Column(name = "Amount")
	private int Amount;
	
	@Column(name = "Validity")
	private int Validity;
	
	@Column(name = "JOB_POST_LIMIT")
	private int jobPostLimit;

	private int databaseExcelRecordsLimit = 10;
	
	private int databaseResumeDownloadLimit = 10; 
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPName() {
		return PName;
	}

	public void setPName(String pName) {
		PName = pName;
	}

	
	public int getExcelRecordsLimit() {
		return excelRecordsLimit;
	}

	public void setExcelRecordsLimit(int excelRecordsLimit) {
		this.excelRecordsLimit = excelRecordsLimit;
	}

	public int getResumeDownloadLimit() {
		return resumeDownloadLimit;
	}

	public void setResumeDownloadLimit(int resumeDownloadLimit) {
		this.resumeDownloadLimit = resumeDownloadLimit;
	}

	public int getAmount() {
		return Amount;
	}

	public void setAmount(int amount) {
		Amount = amount;
	}

	public int getValidity() {
		return Validity;
	}

	public void setValidity(int validity) {
		Validity = validity;
	}

	public int getJobPostLimit() {
		return jobPostLimit;
	}

	public void setJobPostLimit(int jobPostLimit) {
		this.jobPostLimit = jobPostLimit;
	}

	public int getDatabaseExcelRecordsLimit() {
		return databaseExcelRecordsLimit;
	}

	public void setDatabaseExcelRecordsLimit(int databaseExcelRecordsLimit) {
		this.databaseExcelRecordsLimit = databaseExcelRecordsLimit;
	}

	public int getDatabaseResumeDownloadLimit() {
		return databaseResumeDownloadLimit;
	}

	public void setDatabaseResumeDownloadLimit(int databaseResumeDownloadLimit) {
		this.databaseResumeDownloadLimit = databaseResumeDownloadLimit;
	}

	
}
