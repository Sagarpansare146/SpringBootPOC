package com.eagleSystem.eagleJob.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.eagleSystem.eagleJob.bussinessObject.JobBO;
import com.eagleSystem.eagleJob.valueObject.JobPostRequest;
import com.eagleSystem.eagleJob.valueObject.ListJobForCandidate;
import com.eagleSystem.eagleJob.valueObject.ListJobRequest;

public interface JobService {

	Map<String, Object> postedJobByRecruiter(Long recruiterId, int page, int pageSize);

	Map<String, Object> allJobs(int page, int pageSize);
	
	Map<String, Object> getJobByCity(String location, int page, int pageSize);
	
	List<ListJobRequest> activeJobsByRercruiter(Long recruiterId, Boolean isDeleted);
	
//	List<ListJobRequest> allActiveJobs(boolean isDeleted);
	
	Map<String, Object> searchedJob(String keySkill, String location, String jobCategory, String functionalArea, int page, int pageSize);
	
	boolean postNewJob(String username, JobPostRequest request);

	JobBO getJobBOById(Long id);
	
	boolean updateJob(JobBO jobBO);
	
	public Map<String, Object> getJobForYou(Long candidateId, String keySkill, String location, String jobCategory, String functionalArea, String[] topCities, int page, int pageSize);
	
	public boolean deletePostedJob(Long jobId, Long recruiterId);
	
	public List<ListJobForCandidate> recommondedJobs(Date d1, Date d2);

//	Map<String, Object> getJobForYou(String inputSearch, String location, Integer page);
}
