package com.eagleSystem.eagleJob.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.Qualification;

import java.lang.String;
import java.util.List;

public interface AccountRepository extends JpaRepository<Account, Long>, JpaSpecificationExecutor<Account>{

	Account findByUsername(String username);
	Page<Account> findBySubAdminUsername(String username, Pageable pageable);
	
List<Account> findByRole(String role);
	
}
