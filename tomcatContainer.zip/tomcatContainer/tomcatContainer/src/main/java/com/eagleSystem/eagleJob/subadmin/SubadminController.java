package com.eagleSystem.eagleJob.subadmin;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.eagleSystem.eagleJob.util.ViewMapper;

@Controller
public class SubadminController {
	@RequestMapping("/subadminhome")
	public String updateSubadmin() {
		return ViewMapper.SUBADMIN_SUBADMIN_INDEX;
	}

	/*
	 * @RequestMapping("/subadminCreateAccount") public String
	 * subadminCreateAccount() { return ViewMapper.SUBADMIN_SUBADMIN_CREATEACCOUNT;
	 * }
	 * 
	 * @RequestMapping("/subadminCreateCustomer") public String
	 * subadminCreateCustomer() { return
	 * ViewMapper.SUBADMIN_SUBADMIN_CREATECUSTOMER; }
	 */
	@RequestMapping("/subadminDailyReport")
	public String subadminDailyReport() {
		return ViewMapper.SUBADMIN_SUBADMIN_DAILYREPORT;
	}

	@RequestMapping("/subadminMonthlyReport")
	public String subadminMonthlyReport() {
		return ViewMapper.SUBADMIN_SUBADMIN_MONTHLYREPORT;
	}

	@RequestMapping("/subadminDailyDatabase")
	public String subadminDailyDatabase() {
		return ViewMapper.SUBADMIN_SUBADMIN_DAILYDATABASE;
	}

	@RequestMapping("/subadminDailyPosting")
	public String subadminDailyPosting() {
		return ViewMapper.SUBADMIN_SUBADMIN_DAILYPOSTING;
	}

	@RequestMapping("/subadminMonthlyDatabase")
	public String subadminMonthlyDatabase() {
		return ViewMapper.SUBADMIN_SUBADMIN_MONTHLYDATABASE;
	}

	@RequestMapping("/subadminMonthlyPosting")
	public String subadminMonthlyPosting() {
		return ViewMapper.SUBADMIN_SUBADMIN_MONTHLYPOSTING;
	}

	@RequestMapping("/subadminCustomerList")
	public String subadminCustomerList() {
		return ViewMapper.SUBADMIN_SUBADMIN_CUSTOMERLIST;
	}

	@RequestMapping("/subadminBdmList")
	public String subadminBdmList() {
		return ViewMapper.SUBADMIN_SUBADMIN_BDMLIST;
	}

	@RequestMapping("/subadminUserList")
	public String subadminUserList() {
		return ViewMapper.SUBADMIN_SUBADMIN_USERLIST;
	}

}
