package com.eagleSystem.eagleJob.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.eagleSystem.eagleJob.UserDetailServiceImpl;
import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.entity.JPUser;

@Controller
public class LoginController {

	@Autowired
	JPUserRepository userRepository;

	@Autowired
	protected AuthenticationManager authenticationManager;

	@Autowired
	public UserDetailServiceImpl userDetailsService;
	 
	/**
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/ABC", produces = {"application/json"})
	@ResponseBody
	public String login(@RequestParam("username") String username,@RequestParam("password") String password ,HttpServletRequest request, HttpServletResponse response){

		/*String username = request.getParameter("username");
		String password = request.getParameter("password");
		*/// HttpSession session = request.getSession();

		JPUser user = userRepository.findByUsernameIgnoreCase(username);
		
		

		// session.setAttribute("user", user);

		// User user = (User) session.getAttribute("user");

		// write code wen user not found
		if (user != null && user.getPassword().equals(password)) {

			
		/*	  if (user.getRole().equalsIgnoreCase("employer")) {
			  
			  // employer login mv = new ModelAndView("employerDashboard", "employer",
			  user);
			  
			  } else if (user.getRole().equalsIgnoreCase("candidate")) {
			  
			  // candidate login mv = new ModelAndView("candidateDashboard", "candidate",
			  user);
		*/
			 
			authenticateUserAndSetSession(username, password, request);
			
			
			System.out.println("done");
		} else {

			// admin login

			 return "other/400";

		}
			 return "success";
	}

	private void authenticateUserAndSetSession(String username, String passwordFromForm, HttpServletRequest request) {

		System.out.println("username:  " + username + " password: " + passwordFromForm);

		UserDetails userDetails = userDetailsService.loadUserByUsername(username);

		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
				username, passwordFromForm, userDetails.getAuthorities());
		HttpSession session = request.getSession();

		System.out.println("Line Authentication 1");

		usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetails(request));

		System.out.println("Line Authentication 2");

		Authentication authenticatedUser = authenticationManager.authenticate(usernamePasswordAuthenticationToken);

		System.out.println("Line Authentication 3");

		if (usernamePasswordAuthenticationToken.isAuthenticated()) {
			SecurityContextHolder.getContext().setAuthentication(authenticatedUser);
			System.out.println("Line Authentication 4");

		}

		request.getSession().setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY,
				SecurityContextHolder.getContext());// creates context for that session.

		System.out.println("Line Authentication 5");

		session.setAttribute("username", username);

		System.out.println("Line Authentication 6");

		session.setAttribute("authorities", usernamePasswordAuthenticationToken.getAuthorities());

		System.out.println("username:  " + username + "password: " + passwordFromForm + "authorities: "
				+ usernamePasswordAuthenticationToken.getAuthorities());

		// user = userDAO.validate(user.getUsername(), user.getPassword());
		// log.debug("You are successfully register");

	}

}
