package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.query.Param;

import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;
import com.eagleSystem.eagleJob.entity.NaukriExcelRecordProj;
import com.querydsl.core.types.Predicate;
import java.lang.String;

public interface NaukriExcelRepository extends JpaRepository<NaukriExcelRecord, Long> , JpaSpecificationExecutor<NaukriExcelRecord>{

	List<NaukriExcelRecordProj> findByJobCategory(String jobCategory);
	List<NaukriExcelRecord> findByGenderAndJobCategoryAndPreferredLocationsAndTotalExperienceContaining(String gender, String jobCategory, String preferredLocation, String TotalExperience);
	List<NaukriExcelRecord> findByGenderAndJobCategoryAndPreferredLocations(String gender, String jobCategory, String preferredLocation);
	List<NaukriExcelRecord> findByGenderAndJobCategory(String gender, String jobCategory);
	List<NaukriExcelRecord> findByGender(String gender);
	List<NaukriExcelRecord> findByCurrentLocation(String currentLocation);
	List<NaukriExcelRecord> findByannualSalary(String annualSalary);
	
	
	List<NaukriExcelRecord> findByJobCategoryAndPreferredLocationsContaining(String jobCategory, String location);
	
	@Query("SELECT DISTINCT p.preferredLocations FROM NaukriExcelRecord p")
	List<String> findDistinctCity();
	
	@Query("SELECT DISTINCT p.currentLocation FROM NaukriExcelRecord p")
	List<String> findDistinctCurrentLocation();

	@Query("SELECT DISTINCT p.annualSalary FROM NaukriExcelRecord p")
	List<String> findDistinctannualSalary();

	@Query("SELECT DISTINCT p.jobCategory FROM NaukriExcelRecord p")
	List<String> findDistinctJobCategory();

	@Query("SELECT DISTINCT p.keySkills FROM NaukriExcelRecord p")
	List<String> findDistinctKeySkills();

	@Query("SELECT DISTINCT p.ugCourse FROM NaukriExcelRecord p")
	List<String> findDistinctUgCourse();

	@Query("SELECT p.resumePath FROM NaukriExcelRecord p where id in (:ids)")
	List<String> getResumePath(@Param("ids") Long ids[]);
	
	/*@Override
	default boolean exists(Predicate predicate) {
		return (findOne(predicate) != null ? true : false);
	}
	*/
	
	NaukriExcelRecord findByEmailIDContaining(String emailid);
	
	/*@Override
	default long count(Predicate predicate) {	
		return ((List<NaukriExcelRecord>) findAll(predicate)).size();
	}
	*/
	
	NaukriExcelRecord findByNameAndCurrentLocationContainsAndDob(String name, String loc, String Dob); 
	 
	NaukriExcelRecord findByNameAndCurrentLocationContains(String name, String loc); 
	 
	
	/* @Query("SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END FROM NaukriExcelRecord c WHERE c.name = :companyName")
	 boolean existsByName(@Param("companyName") String companyName);
	 */
//	Iterable<NaukriExcelRecord> findAll(Predicate predicate);
	
}
