package com.eagleSystem.eagleJob;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import com.eagleSystem.eagleJob.entity.MonsterExcelRecord;

public class BusinesMonstarExcelBuilder extends AbstractXlsView  {

	@Override
	protected void buildExcelDocument(Map model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String name = (String) model.get("industry");

		// change the file name
		response.setHeader("Content-Disposition", "attachment; filename=\""+ "Monstar"+ "_"+ name + ".xls\"");

		@SuppressWarnings("unchecked")
		List<MonsterExcelRecord> records = (List<MonsterExcelRecord>) model.get("records");

		// create excel xls sheet
		Sheet sheet = workbook.createSheet("Job Post Response");

		// create header row
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("Sr. no.");
		header.createCell(1).setCellValue("CandidateName");
		header.createCell(2).setCellValue("DateofBirth");
		header.createCell(3).setCellValue("ResumeTitle");
		header.createCell(4).setCellValue("Education");
		header.createCell(5).setCellValue("ExperienceInYears");
		header.createCell(6).setCellValue("CurrentEmployer");
		header.createCell(7).setCellValue("PreviousEmployer");
		header.createCell(8).setCellValue("KeySkills");
		header.createCell(9).setCellValue("CurrentLocation");
		header.createCell(10).setCellValue("Nationality");
		header.createCell(11).setCellValue("WorkAuthorization");
		header.createCell(12).setCellValue("Category");	
		header.createCell(13).setCellValue("Roles");
		header.createCell(14).setCellValue("Industry");
		header.createCell(15).setCellValue("Status");
		header.createCell(16).setCellValue("Source");
		header.createCell(17).setCellValue("ReceivedDate");
		header.createCell(18).setCellValue("Address");
		header.createCell(19).setCellValue("EmailID");
		header.createCell(20).setCellValue("Phone");
		header.createCell(21).setCellValue("Mobile");
    	header.createCell(22).setCellValue("MobileVerified");
	    header.createCell(23).setCellValue("CurrentAnnualSalary");
	   header.createCell(24).setCellValue("JobCategory");
	
		int rowCount = 0;                             
		for (MonsterExcelRecord course : records) {               
			Row courseRow = sheet.createRow(++rowCount);
			System.out.println(rowCount);
			courseRow.createCell(0).setCellValue(rowCount);
			courseRow.createCell(1).setCellValue(course.getName());
			courseRow.createCell(2).setCellValue(course.getDateofBirth());
			courseRow.createCell(3).setCellValue(course.getResumeTitle());
			courseRow.createCell(4).setCellValue(course.getEducation());
			courseRow.createCell(5).setCellValue(course.getExperienceInYears());
			courseRow.createCell(6).setCellValue(course.getCurrentEmployer());
			courseRow.createCell(7).setCellValue(course.getPreviousEmployer());
			courseRow.createCell(8).setCellValue(course.getKeySkills());
			courseRow.createCell(9).setCellValue(course.getCurrentLocation());
			courseRow.createCell(10).setCellValue(course.getNationality());
			courseRow.createCell(11).setCellValue(course.getWorkAuthorization());
			courseRow.createCell(12).setCellValue(course.getCategory());
			courseRow.createCell(13).setCellValue(course.getRoles());
			courseRow.createCell(14).setCellValue(course.getIndustry());
			courseRow.createCell(15).setCellValue(course.getStatus());
			courseRow.createCell(16).setCellValue(course.getSource());
			courseRow.createCell(17).setCellValue(course.getReceivedDate());
			courseRow.createCell(18).setCellValue(course.getAddress());
			courseRow.createCell(19).setCellValue(course.getEmail());
			courseRow.createCell(20).setCellValue(course.getPhone());
			courseRow.createCell(21).setCellValue(course.getMobile());
			courseRow.createCell(22).setCellValue(course.getMobileVerified());
			courseRow.createCell(23).setCellValue(course.getCurrentAnnualSalary());
			courseRow.createCell(24).setCellValue(course.getJobCategory());
		
		}

	}
	
}