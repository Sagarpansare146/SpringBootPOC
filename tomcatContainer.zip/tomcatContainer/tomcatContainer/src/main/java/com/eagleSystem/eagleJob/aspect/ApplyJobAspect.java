package com.eagleSystem.eagleJob.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.dao.CandidateApplicationRepository;
import com.eagleSystem.eagleJob.dao.JobRepository;
import com.eagleSystem.eagleJob.entity.CandidateApplication;
import com.eagleSystem.eagleJob.entity.JobPost;

@Aspect
@Component
public class ApplyJobAspect extends AbstractAppPointcut {

	@Autowired
	CandidateApplicationRepository cadAppRepo;

	@Autowired
	JobRepository jobRepository;

	@Around("applyJobPointcut()")
	public Object apply(ProceedingJoinPoint pjp) throws Throwable {
		boolean flag = false;
		CandidateApplication candidateApplication = null;
		JobPost job = null;
		Object obj[] = pjp.getArgs();

		Long jid = (Long) obj[0];
		Long cid = (Long) obj[1];
		System.out.println("check before apply");

		try {
			candidateApplication = cadAppRepo.findByJobPostIdAndCandidateId(jid, cid);
			job = jobRepository.findById(jid);
		} catch (Exception e) {
			System.out.println("error in applyJobAspect class");
			flag = true;
		}

		if (!(candidateApplication == null)) {
			if (flag) {
				throw new Exception("Invalid job");
			}
			System.out.println(candidateApplication.getAppliedOn());
			throw new Exception("Already Applied for this job");
		}

		if (job == null) {
			throw new Exception("Invalid Job");
		}

		return pjp.proceed();

	}

}
