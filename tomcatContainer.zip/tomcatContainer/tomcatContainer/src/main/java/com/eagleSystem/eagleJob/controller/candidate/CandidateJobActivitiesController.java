package com.eagleSystem.eagleJob.controller.candidate;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.dao.CandidateRepository;
import com.eagleSystem.eagleJob.service.CandidateApplicationService;
import com.eagleSystem.eagleJob.service.CandidateService;
import com.eagleSystem.eagleJob.service.JobService;
import com.eagleSystem.eagleJob.service.JpUserService;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.util.JobBOPrepareUtil;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.ListJobForCandidate;
import com.eagleSystem.eagleJob.valueObject.UserRegistrationRequest;

@Controller
public class CandidateJobActivitiesController {

	@Autowired
	JobService jobService;

	@Autowired
	JobBOPrepareUtil prepareJobRequest;

	@Autowired
	CandidateApplicationService candidateApplicationService;

	@Autowired
	CandidateService candidateService;

	@Autowired
	RecruiterService recruiterService;

	@Autowired
	JpUserService jpUserService;

	ThreadLocal<Map<String, Object>> threadLocal = new ThreadLocal<>();

	@GetMapping(value = URLMapper.CANDIDATE_VIEW_JOBS, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody Map<String, Object> jCandidateViewAllJobs(Model model, Authentication auth,
			@RequestParam(required = false, defaultValue = "1") String page,
			@RequestParam(required = false, defaultValue = "10") String pageSize) {

		System.out.println(candidateService);
		System.out.println(auth.getName());
		UserRegistrationRequest candidate = candidateService.getUserData(auth.getName());
		System.out.println(candidate);
		/** Manipulation for Applied Jobs. Cant apply to Already Applied Jobs */

		// List<ListJobForCandidate> allActiveJobs =
		// candidateApplicationService.getCandidateAppliedJobs(candidate.getId(), page);

		Integer count = null;

		String[] topCities = candidate.getTopCities();

		String jobCategory = "";

		for (String jc : candidate.getJobCategory()) {
			jobCategory = jobCategory + jc;
		}

		Map<String, Object> map = jobService.getJobForYou(candidate.getId(), candidate.getKeySkill(),
				candidate.getCandidateCity(), jobCategory, candidate.getFunctionalArea(), topCities,
				Integer.parseInt(page), Integer.parseInt(pageSize));

		List<ListJobForCandidate> jobs = (List<ListJobForCandidate>) map.get("jobs");

		if (threadLocal.get() == null) {
			Map<String, Object> mapth = new HashMap<String, Object>();
			mapth.put("count", count);
			threadLocal.set(mapth);
		}

		if (threadLocal.get().get("count") == null) {
			if (jobs == null) {
				count = 0;
				return new HashMap<String, Object>();
			}
			count = jobs.size();
			Map<String, Object> mth = threadLocal.get();
			mth.put("count", count);
		}

		return map;
	}

	@GetMapping(value = URLMapper.CANDIDATE_VIEW_JOBS)
	public String candidateViewAllJobs(Model model, Authentication auth,
			@RequestParam(required = false, defaultValue = "1") String page,
			@RequestParam(required = false, defaultValue = "10") String pageSize) {

		List<ListJobForCandidate> jobs = null;
		List<ListJobForCandidate> rJobs = null;
		Integer count = 0;
		Map<String, Object> map = new HashMap<>();
		boolean flag = false;
		try {
			map = jCandidateViewAllJobs(model, auth, page, pageSize);
			rJobs = jobService.recommondedJobs(new Date(), yesterday());
			count = rJobs.size();
		} catch (Throwable t) {
			t.printStackTrace();
			model.addAttribute("error", "Unable to get Recommanded Jobs");
			flag = true;
		}

		if (flag) {

			return "error";
		}

		System.out.println(jobs);
		System.out.println(count);

		model.addAttribute("beginIndex", map.get("begin"));
		model.addAttribute("endIndex", map.get("end"));
		model.addAttribute("currentIndex", map.get("current"));
		model.addAttribute("totalPages", map.get("totalPages"));
		model.addAttribute("request", map.get("jobs"));

		model.addAttribute("count", count);
		model.addAttribute("notification", rJobs);
		return ViewMapper.CANDIDATE_VIEW_JOBS;
	}

	private Date yesterday() {
		final Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		return cal.getTime();
	}
	/*
	 * @RequestMapping(value = URLMapper.CANDIDATE_PROFILE, produces =
	 * {"application/json"}) public UserRegistrationRequest jCandidateProfile(Model
	 * model, Authentication auth) {
	 * 
	 * UserRegistrationRequest candidate =
	 * candidateService.getCandidate(auth.getName());
	 * 
	 * return candidate; }
	 * 
	 * 
	 * @RequestMapping(value = URLMapper.CANDIDATE_PROFILE) public String
	 * candidateProfile(Model model, Authentication auth) {
	 * 
	 * UserRegistrationRequest candidate = jCandidateProfile(model, auth);
	 * 
	 * model.addAttribute("request", candidate); return
	 * ViewMapper.CANDIDATE_PROFILE; }
	 */

	@GetMapping(value = URLMapper.CANDIDATE_APPLY_JOB)
	public String candidateApplyJobs(@RequestParam(value = "jobId", required = true) Long jobId, Authentication auth,
			Model model, HttpServletResponse response) {
		boolean flag = false;
		boolean error = false;
		try {
			flag = jCandidateApplyJobs(jobId, auth, model, response);
		} catch (Throwable t) {
			model.addAttribute("error", "Unable to Apply Job");
			t.printStackTrace();
			error = true;
		}

		if (error) {
			return "error";

		}

		if (!flag)
			return "error";

		return "redirect:" + URLMapper.CANDIDATE_VIEW_JOBS;
	}

	@RequestMapping(value = URLMapper.CANDIDATE_APPLY_JOB, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jCandidateApplyJobs(@RequestParam(value = "jobId", required = true) Long jobId,
			Authentication auth, Model model, HttpServletResponse response) {

		System.out.println(jobId);
		UserRegistrationRequest candidate = candidateService.getCandidate(auth.getName());
		boolean flag = true;
		try {
			candidateApplicationService.applyJob(jobId, candidate.getId());
		} catch (Exception e) {
			response.setHeader("error", "503");
			flag = false;
		}

		return flag;
	}

	@GetMapping(value = URLMapper.CANDIDATE_APPLIED_JOBS, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody Map<String, Object> jCandidateViewAppliedJobs(Model model, Authentication auth,
			@RequestParam(required = false, defaultValue = "1") String page,
			@RequestParam(required = false, defaultValue = "10") String pageSize) {

		UserRegistrationRequest candidate = candidateService.getUserData(auth.getName());

		Map<String, Object> map = candidateApplicationService.getCandidateAppliedJobs(candidate.getId(),
				Integer.parseInt(page), Integer.parseInt(pageSize));

		return map;
	}

	@GetMapping(value = URLMapper.CANDIDATE_APPLIED_JOBS)
	public String candidateViewAppliedJobs(Model model, Authentication auth,
			@RequestParam(required = false, defaultValue = "1") String page,
			@RequestParam(required = false, defaultValue = "10") String pageSize) {

		Map<String, Object> map = new HashMap<>();
		List<ListJobForCandidate> jobs = null;

		boolean flag = false;
		try {
			map = jCandidateViewAppliedJobs(model, auth, page, pageSize);
		} catch (Throwable t) {
			t.printStackTrace();
			flag = true;
			model.addAttribute("error", "Unable to get Applied Jobs");
		}

		if (flag) {
			return "error";
		}

		System.out.println(jobs);
		model.addAttribute("request", jobs);

		model.addAttribute("beginIndex", map.get("begin"));
		model.addAttribute("endIndex", map.get("end"));
		model.addAttribute("currentIndex", map.get("current"));
		model.addAttribute("totalPages", map.get("totalPages"));
		model.addAttribute("request", map.get("jobs"));

		return ViewMapper.CANDIDATE_APPLIED_JOBS;
	}

	@GetMapping(value = URLMapper.GET_COUNT, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody Long getCountCandidate() {

		return candidateService.getCandidateCount();
	}

}