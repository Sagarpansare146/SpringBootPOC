package com.eagleSystem.eagleJob.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Size;

@Entity
@Table(name = "OLD_EXCEL_DATA", uniqueConstraints = {@UniqueConstraint(columnNames={"EMAIL"})})
public class OldExcel {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "EMAIL")
	private String emailId;
	
	@Column(name = "LOC")
	@Size(max = 25000)
	private String location;
	
	@Column(name = "JOB_CATAGORY")
	private String jobCatagory;

	public OldExcel(String emailId, String location, String jobCatagory) {
		super();
		this.emailId = emailId;
		this.location = location;
		this.jobCatagory = jobCatagory;
	}
	
	

	public OldExcel() {
		super();
	}



	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getJobCatagory() {
		return jobCatagory;
	}

	public void setJobCatagory(String jobCatagory) {
		this.jobCatagory = jobCatagory;
	}
	
	
}
