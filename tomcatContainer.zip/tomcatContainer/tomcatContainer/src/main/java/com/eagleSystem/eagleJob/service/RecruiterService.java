package com.eagleSystem.eagleJob.service;

import java.util.List;
import java.util.Map;

import com.eagleSystem.eagleJob.bussinessObject.RecruiterBO;
import com.eagleSystem.eagleJob.entity.CandidatePreference;
import com.eagleSystem.eagleJob.valueObject.CandidateExcelRecords;
import com.eagleSystem.eagleJob.valueObject.CandidateRecords;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;

public interface RecruiterService {

	public boolean regRecruiter(RecruiterRegistrationRequest request);
	public RecruiterRegistrationRequest getRecruiterData(String username);
	
	
	public RecruiterBO getRecruiterByUsername(String username);
	public boolean updateRecruiterProfile(RecruiterRegistrationRequest request);
	public List<CandidateExcelRecords> downloadExcelRecords(Long cadId[], Long jobId);
	public List<CandidateExcelRecords> gDownloadExcelRecords(Long cadId[]);
	public Map<Long, CandidatePreference> downloadResume(List<Long> ids, Long jobId);
	public List<CandidateRecords> jobByExp(Long jobId, Integer exp);
//	public List<CandidateRecords> jobByJobCategory(Long jobId, String jobCategory);
	public List<CandidateRecords> jobByLoc(Long jobId, String location);
	public List<CandidateRecords> filterRecords(Long jobId, String location, int from, int to, String jobCategory,
			String degree, String gender);
	public List<CandidateExcelRecords> recDownloadExcelRecords(Long cadId[]);
	
	public List<CandidateExcelRecords> bdmDownloadExcelRecords(Long cadId[]);
}
