package com.eagleSystem.eagleJob.util;

public interface URLMapper {

	// common display pages

	public static final String HOME = "/home";
	public static final String LOGIN = "/login";
	public static final String ADMIN_LOGIN = "/AdminLogin";
	public static final String CANDIDATE_LOGIN = "/candidateLogin";
	public static final String RECRUITER_LOGIN = "/recruiterLogin";
	public static final String TERMS_AND_CONDITION = "/tnc";
	public static final String FORGOT_PASSWORD = "/forgetPassword";
	public static final String FORGOT_PAGE = "/forgotPage"; 
	public static final String JOB_DETAIL = "/jobDetail";
	
	//public static final String CONTACT_US = "/contactUs";

	public static final String VERIFT_EMAIL = "/verifyEmail";
	public static final String SEND_OTP = "/sendOTP";

	public static final String GET_COUNT = "/getCount";

	public static final String EMAIL_FROM = "career@naukriJob.co.in";
	// candidate display pages

	public static final String CANDIDATE_REGISTRATION = "/candidateReg";
	public static final String CANDIDATE_PROFILE = "/candidateProfile";
	public static final String CANDIDATE_PROFILE_UPDATE = "/candidateProfile";
	public static final String CANDIDATE_VIEW_JOBS = "/candidateViewJobs";
	public static final String CANDIDATE_APPLIED_JOBS = "/candidateAppliedJobs";
	public static final String CANDIDATE_JOB_DETAILS = "/candidateJobDetails";
	public static final String COMMON_JOB_DETAILS = "/candidateJobDetails";

	public static final String CANDIDATE_APPLY_JOB = "/candidateApplyJobs";

	public static final String UPLOAD_RESUME = "/candidateUploadResume";

	// recruiter display pages

	public static final String RECRUITER_REGISTRATION = "/recruiterReg";
	public static final String RECRUITER_COMPANY_PROFILE = "/companyProfile";
	public static final String RECRUITER_JOB_POST = "/recruiterJobPost";
	public static final String RECRUITER_POSTED_JOBS = "/recruiterPostedJob";
	public static final String RECRUITER_JOB_UPDATE = "/jobUpdate";
	public static final String RECRUITER_JOB_RESPONSES = "/recruiterJobResponses";
	public static final String RECRUITER_DELETE_JOB_URL = "/recruiterDeleteJob";

	public static final String RECRUITER_JOB_BY_LOC = "/recruiterJobByLoc";
	public static final String RECRUITER_JOB_BY_CATEGORY = "/recruiterJobByCategory";
	public static final String RECRUITER_JOB_BY_EXP = "/recruiterJobByExp";
	public static final String RECRUITER_EXCEL_RECORDS = "/recruiterDownloadRecords";
	public static final String RECRUITER_RESUME_DOWNLOAD = "/recruiterDownloadResume";
	public static final String RECRUITER_DOWNLOAD = "/recruiterDownload";
	
	public static final String RECRUITER_NAUKRIJOBDOWNLOAD = "/recruiterNaukrijobDownload";
	
	public static final String RECRUITER_NAUKRIJOB = "/recruiterNaukriJob";
	public static final String RECRUITER_NAUKRIJOB_FILTER = "/recruiterNaukriJobFilter";

	public static final String RECRUITER_NAUKRI="/recruiterNaukri";

	public static final String RECRUITER_NAUKRI_EXCEL_RECORDS = "/recruiterDownloadNaukriExcel";
	public static final String RECRUITER_NAUKRIJOB_EXCEL_RECORDS = "/recruiterDownloadNaukriJobExcel";
	public static final String RECRUITER_NAUKRI_RESUME_DOWNLOAD = "/recruiterDownloadNaukriResume";
	public static final String RECRUITER_NAUKRIJOB_RESUME_DOWNLOAD = "/recruiterDownloadNaukriJobResume";


	// BDM display pages
	
	public static final String BDM_BDM_HOME = "/bdmhome";
	public static final String BDM_RECRUITER_REGISTRATION = "/bdmRecruiterReg";
	public static final String BDM_NAUKRI_FILTER = "/bdmNaukriFilter";
	public static final String BDM_NAUKRIJOB_FILTER = "/bdmNaukriJobFilter";
	public static final String BDM_DB_CUSTOMER_REGISTRATION = "/bdmDBCustomerReg";
	public static final String BDM_NAUKRI_EXCEL_RECORDS = "/bdmDownloadNaukriExcel";
	public static final String BDM_NAUKRIJOB_EXCEL_RECORDS = "/bdmDownloadNaukriJobExcel";
	public static final String BDM_NAUKRI_RESUME_DOWNLOAD = "/bdmDownloadNaukriResume";
	public static final String BDM_NAUKRIJOB_RESUME_DOWNLOAD = "/bdmDownloadNaukriJobResume";
	public static final String BDM_DOWNLOAD = "/bdmDownload";
	public static final String BDM_BDM_SILVER_SERVER="/bdmNaukriDb";
	
	public static final String BDM_BDM_DATABASEREPORT="/bdmDatabaseReport";
	// Subadmin Display pages
	public static final String SUBADMIN_SUBADMIN_INDEX = "/subadminhome";
	public static final String SUBADMIN_SUBADMIN_CREATEACCOUNT = "/subadminCreateAccount";
	public static final String SUBADMIN_SUBADMIN_CREATECUSTOMER = "/subadminCreateCustomer";
	public static final String SUBADMIN_SUBADMIN_DAILYREPORT = "/subadminDailyReport";
	public static final String SUBADMIN_SUBADMIN_MONTHLYREPORT = "/subadminMonthlyReport";
	public static final String SUBADMIN_SUBADMIN_DAILYDATABASE = "/subadminDailyDatabase";
	public static final String SUBADMIN_SUBADMIN_DAILYPOSTING = "/subadminDailyPosting";
	public static final String SUBADMIN_SUBADMIN_MONTHLYDATABASE = "/subadminMonthlyDatabase";
	public static final String SUBADMIN_SUBADMIN_MONTHLYPOSTING = "/subadminMonthlyPosting";
	public static final String SUBADMIN_SUBADMIN_CUSTOMERLIST = "/subadminCustomerList";
	public static final String SUBADMIN_SUBADMIN_BDMRLIST = "/subadminBdmList";
	public static final String SUBADMIN_SUBADMIN_USERLIST = "/subadminUserList";
	public static final String SUBADMIN_SUBADMIN_CREATEPOSTINGCUSTOMER="/subadminRecuiterAccount";
	public static final String SUBADMIN_SUBADMIN_UPDATEACCOUNT = "subadmin/subadminUpdateAccount";
	public static final String SUBADMIN_SUBADMIN_UPDATECUSTOMER  = "subadmin/subadminUpdateCustomer";
	public static final String SUBADMIN_SUBADMIN_UPDATEPOSTINGACCOUNT = "subadmin/subadminupdatePostingAccount";

	// Admin urls
	
	public static final String ADMIN_CREATE_SUBADMIN = "/AdminCreateSubadmin";
	
	// Databse urls
	public static final String DATABASE_DATABASE_HOME="/databasehome";
	public static final String DATABASE_DATABASE_NAUKRI="/databaseNaukri";
	public static final String DATABASE_DATABASE_NAUKRIJOB="/databaseNaukrijob";
	public static final String DATABASE_DATABASE_REPORT="/databaseResumereport";
	public static final String DATABASE_NAUKRI_EXCEL_RECORDS = "/databaseDownloadNaukriExcel";
	public static final String DATABASE_NAUKRI_RESUME_DOWNLOAD = "/databaseDownloadNaukriResume";
	public static final String DATABASE_NAUKRIJOB_EXCEL_RECORDS = "/databaseDownloadNaukriJobExcel";
	public static final String DATABASE_NAUKRIJOB_RESUME_DOWNLOAD = "/databaseDownloadNaukriJobResume";
	public static final String DATABASE_DOWNLOAD = "/databaseDownload";
	

}