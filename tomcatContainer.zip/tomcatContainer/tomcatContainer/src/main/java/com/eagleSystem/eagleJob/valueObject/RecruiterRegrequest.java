package com.eagleSystem.eagleJob.valueObject;

public class RecruiterRegrequest {
	
	

}
