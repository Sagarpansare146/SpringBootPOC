package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.query.Param;

import com.eagleSystem.eagleJob.entity.CandidatePreference;

public interface CandidatePrefRepository extends JpaRepository<CandidatePreference, Long>, JpaSpecificationExecutor<CandidatePreference> {

	@Query("SELECT cp.cid, cp.keySkill, cp.location FROM CandidatePreference cp WHERE cp.cid = :candidateId")
	Object getCandidatePrefRecord(@Param("candidateId") Long candidateId);

	@Query("select cp.cid from CandidatePreference cp where location like %:location%")
	List<Long> findIdByLocation(@Param("location") String location);

	@Query("select cp.cid from CandidatePreference cp where (cp.jobCategory like %:jobCategory%  And cp.location like %:location% )")
	List<Long> findIdByJobCategory(@Param("jobCategory") String jobCategory, @Param("location") String location);

//	Iterable<CandidatePreference> findAll(Predicate predicate);
	
	@Query("SELECT p.resume FROM CandidatePreference p where p.cid in (:ids)")
	List<String> getResumePath(@Param("ids") Long ids[]);
	
	@Query("SELECT DISTINCT p.jobCategory FROM CandidatePreference p")
	List<String> findDistinctjobCategory();
}
