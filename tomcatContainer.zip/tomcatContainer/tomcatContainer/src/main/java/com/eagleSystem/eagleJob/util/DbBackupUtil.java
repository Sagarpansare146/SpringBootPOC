package com.eagleSystem.eagleJob.util;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.stereotype.Component;

import com.smattme.MysqlExportService;

@Component
public class DbBackupUtil {
	
	public Map<String, Object> backup() throws ClassNotFoundException, IOException, SQLException {
		
		//required properties for exporting of db
		Properties properties = new Properties();
		properties.setProperty(MysqlExportService.DB_NAME, "eagle_job");
		properties.setProperty(MysqlExportService.DB_USERNAME, "root");
		properties.setProperty(MysqlExportService.DB_PASSWORD, "root");
		properties.setProperty(MysqlExportService.DELETE_EXISTING_DATA, "false");
		properties.setProperty(MysqlExportService.DROP_TABLES, "false");
		properties.setProperty(MysqlExportService.ADD_IF_NOT_EXISTS, "true");
		properties.setProperty(MysqlExportService.JDBC_DRIVER_NAME, "com.mysql.jdbc.Driver");
		properties.setProperty(MysqlExportService.JDBC_CONNECTION_STRING, "jdbc:mysql://localhost:3306/eagle_job");
		properties.setProperty(MysqlExportService.PRESERVE_GENERATED_ZIP, "true");
		       
	/*	//properties relating to email config
		properties.setProperty(MysqlExportService.EMAIL_HOST, "smtp.mailtrap.io");
		properties.setProperty(MysqlExportService.EMAIL_PORT, "25");
		properties.setProperty(MysqlExportService.EMAIL_USERNAME, "mailtrap-username");
		properties.setProperty(MysqlExportService.EMAIL_PASSWORD, "mailtrap-password");
		properties.setProperty(MysqlExportService.EMAIL_FROM, "test@smattme.com");
		properties.setProperty(MysqlExportService.EMAIL_TO, "backup@smattme.com");
*/
		//set the outputs temp dir
		properties.setProperty(MysqlExportService.TEMP_DIR, new File("external").getPath());

		MysqlExportService mysqlExportService = new MysqlExportService(properties);

		mysqlExportService.export();
		
		File file = mysqlExportService.getGeneratedZipFile();
		
		mysqlExportService.clearTempFiles(true);
		
		String generatedSql = mysqlExportService.getGeneratedSql();
		
		Map<String, Object> map = new HashMap<>();
		
		map.put("file", file.getAbsolutePath());
	//	map.put("fileName", generatedSql);
		
		return map;
	}

}
