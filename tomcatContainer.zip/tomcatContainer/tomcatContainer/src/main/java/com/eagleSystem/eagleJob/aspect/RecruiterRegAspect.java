package com.eagleSystem.eagleJob.aspect;

import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.InternetAddress;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.bussinessObject.Email;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.service.EmailService;
import com.eagleSystem.eagleJob.util.EmailTemplate;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;

@Aspect
@Component
public class RecruiterRegAspect extends AbstractAppPointcut {

	@Autowired
	EmailService emailService;

	@Autowired
	RecruiterRepository RecruiterRepo;

	@Around("RecRegpointcut()")
	public Object cadRegCheck(ProceedingJoinPoint pjp) throws Throwable {
		System.out.println("check reg");
		Object obj[] = pjp.getArgs();
		String email = ((RecruiterRegistrationRequest) obj[0]).getEmail();

		Recruiter recruiter = RecruiterRepo.findByEmail(email);
		if (!(recruiter == null)) {
			System.out.println(recruiter.getName());
			throw new Exception("Mobile Number or Email id already registered");
		}

		boolean flag = (boolean) pjp.proceed();

		try {
			InternetAddress ia = new InternetAddress();
			ia.setAddress("registration@naukriJob.co.in");

			String to = email;
			String subject = "Welcome to NaukriJob";

			EmailTemplate template = new EmailTemplate("email-templates/RecruiterLogin.txt");
			// template.setTemplate(CustomerEmailMessage.MSG);

			Map<String, String> replacements = new HashMap<String, String>();
			replacements.put("${username}", ((RecruiterRegistrationRequest) obj[0]).getUsername());
			replacements.put("${password}", ((RecruiterRegistrationRequest) obj[0]).getPassword());
			replacements.put("${name}", ((RecruiterRegistrationRequest) obj[0]).getRecruiterName());
			replacements.put("apkLink",
					"https://play.google.com/store/apps/details?id=naukrijobs.eaglesystem.naukrijobs");

			String message = template.getHtmlTemplate(replacements);

			Email email1 = new Email(ia, to, subject, message);
			email1.setHtml(true);
			emailService.send(email1);
		} catch (Throwable th) {
			System.out.println("sorry email cant be sent");
		}

		return flag;
	}

}
