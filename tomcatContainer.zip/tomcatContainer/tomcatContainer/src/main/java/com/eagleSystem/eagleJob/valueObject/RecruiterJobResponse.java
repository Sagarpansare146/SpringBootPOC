package com.eagleSystem.eagleJob.valueObject;

public class RecruiterJobResponse {

}
