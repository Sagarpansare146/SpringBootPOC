package com.eagleSystem.eagleJob.businessExcel;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;


@Component
public class ExcelRecordsBusiness {

	public static final String A = "Naukri";
	public static final String B = "Shine";
	public static final String C = "Monster";
	public static final String D = "Times";
	public static final String E = "client";

	private static final Logger LOGGER = LoggerFactory.getLogger(ExcelRecordsBusiness.class);

	@Autowired
	ExcelEntityBuilder excelEntityBuilder;
	
	@Autowired
	ExcelToDb excelToDb;	
	
	@Autowired
	ExcelExtactor excelExtactor;
	

	public List excel(String filePath, String domain, String JobCategory) throws Exception {
		List ids = null;

		File file1 = new File(filePath);

		String inputFilename = file1.getName();

		switch (inputFilename.substring(inputFilename.lastIndexOf(".") + 1, inputFilename.length())) {
		case "xls":
			ids = xlsReader(file1, domain, JobCategory);
			break;
		case "xlsx":
			ids = xlsxReader(file1, domain, JobCategory);
			break;
		default:
			System.out.println("Please select valid \"Excel\" File\"");
		}

		return ids;

	}

	public String fileReader(HttpServletRequest request, HttpServletResponse response, MultipartFile file) {
		String fName = "";
		System.out.println(file.getSize()+ "  "+ file.isEmpty());
		String FileName = file.getOriginalFilename();
		System.out.println("FileName :"+file.getOriginalFilename());
		System.out.println(file.getName());
		String FullPath = "c:"+ File.separator +"test" + File.separator + "excelFiles";

		System.out.println(FileName);

		try {
			File dir = new File(FullPath);

			if (!dir.exists()) {
				dir.mkdirs();
			}

			String extn = FilenameUtils.getExtension(FileName);

			File serveFile = new File(FullPath + File.separator + FileName);
			fName = serveFile.getAbsolutePath();
			System.out.println(serveFile);
			LOGGER.info("file name :"+serveFile);
			LOGGER.info("file path :"+fName);
			BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serveFile));
			// String ResumePath = "Resume" + File.separator +
			// userRegistrationRequest.getContactNumber();
			stream.write(file.getBytes());
			stream.flush();
			stream.close();
		} catch (IOException io) {
			io.printStackTrace();
		}

		return fName;
	}

	public List xlsReader(File fileInput, String domain,
			String JobCategory) throws Exception {

		List ids = new ArrayList();
		try {
			FileInputStream file = new FileInputStream(fileInput);

			// HSSFWorkbook workbook = new HSSFWorkbook(file);

			HSSFWorkbook workbook = new HSSFWorkbook(file);

			// Get first sheet from the workbook
			HSSFSheet sheet = workbook.getSheetAt(0);

			// Get iterator to all the rows in current sheet
			Iterator<Row> rowIterator = sheet.iterator();

			switch (domain) {
			case A:
				ids = excelEntityBuilder.buildNaukriRecordObj(rowIterator, JobCategory);

				break;
			case B:
				ids = excelEntityBuilder.buildShineRecordObj(rowIterator, JobCategory);
				break;
			case C:
				ids = excelEntityBuilder.buildMosterRecordObj(rowIterator, JobCategory);
				break;
			case D:
				ids = excelEntityBuilder.buildTimesRecordObj(rowIterator, JobCategory);
				break;
			case E:
				ids = excelEntityBuilder.buildClientNaukriRecordObj(rowIterator, JobCategory);
				break;
			default:
				break;
			}
			file.close();
			exportExcelToDb(ids, domain);
		} catch (

		FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(ids.size());

		return ids;
	}

	public List xlsxReader(File fileInput, String domain,
			String JobCategory) throws Exception {

		List ids = new ArrayList();
		try {
			FileInputStream file = new FileInputStream(fileInput);

			// HSSFWorkbook workbook = new HSSFWorkbook(file);

			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// Get iterator to all the rows in current sheet
			Iterator<Row> rowIterator = sheet.iterator();

			switch (domain) {
			case A:
				ids = excelEntityBuilder.buildNaukriRecordObj(rowIterator, JobCategory);

				break;
			case B:
				ids = excelExtactor.buildShineRecordObj(rowIterator, JobCategory);
				break;
			case C:
				ids = excelEntityBuilder.buildMosterRecordObj(rowIterator, JobCategory);
				break;
			case D:
				ids = excelEntityBuilder.buildTimesRecordObj(rowIterator, JobCategory);
				
				break;
				
			case E:
				ids = excelEntityBuilder.buildClientNaukriRecordObj(rowIterator, JobCategory);
				
				break;

			default:
				break;
			}
			System.out.println(ids);
			file.close();
			exportExcelToDb(ids, domain);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(ids.size());

		return ids;

	}
	
	


	@Async
	public void exportExcelToDb(List records, String domain) {

		int errorCount = 0;

		try {
			if (records != null)
				switch (domain) {
				case A:
					errorCount = excelToDb.saveNaukriRecords(records);
					break;
				case B:
					errorCount = excelToDb.saveShineRecords(records);
					break;
				case C:
					errorCount = excelToDb.saveMonsterRecords(records);
					
					break;
				case D:
					errorCount = excelToDb.saveTimesRecords(records);
					break;
					
				case E:
					errorCount = excelToDb.saveClientNaukriRecords(records);
					break;

				default:
					break;
				}

			/*
			 * for (OldExcel e : records) { try { oldExcelRepository.save(e); } catch
			 * (Exception e1) { errorCount = errorCount + 1; }
			 * 
			 * }
			 */
			// records.forEach(oldExcelRepository::save);
			// oldExcelRepository.save(records);
		} catch (

		Exception e) {
			errorCount = errorCount + 1;
		}
		System.out.println("Error : " + errorCount);
	}

	

}
