package com.eagleSystem.eagleJob.util;

import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.bussinessObject.CompanyBO;
import com.eagleSystem.eagleJob.bussinessObject.RecruiterBO;
import com.eagleSystem.eagleJob.entity.Company;
import com.eagleSystem.eagleJob.entity.Recruiter;

@Component
public class RecruiterModelUtilPrepare {

	public Recruiter getRecruiter(RecruiterBO recruiterBO) {
		
		Recruiter recruiter = new Recruiter();
		
		if(!(recruiterBO.getId() == null))
		recruiter.setId(recruiterBO.getId());
		recruiter.setName(recruiterBO.getName());
		recruiter.setEmail(recruiterBO.getEmail());
		recruiter.setDesignation(recruiterBO.getDesignation());
		recruiter.setMobNo(recruiterBO.getMobNo());
		recruiter.setUsername(recruiterBO.getUsername());
		
		return recruiter;
	}
	
	
	public Company getCompany(CompanyBO companyBO) {
		
		Company company = new Company();
		if(!(companyBO.getId() == null))
		company.setId(companyBO.getId());
		company.setName(companyBO.getName());
		company.setType(companyBO.getType());
		company.setGSTNO(companyBO.getGSTNO());
		company.setCity(companyBO.getCity());
		company.setState(companyBO.getState());
		company.setAddress(companyBO.getAddress());
		
	//	company.setDiscription(recruiterBO.getCompany().getDiscription());
		
		return company;
	}
	
}
