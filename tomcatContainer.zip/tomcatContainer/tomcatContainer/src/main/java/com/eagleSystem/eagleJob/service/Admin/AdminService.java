package com.eagleSystem.eagleJob.service.Admin;

import com.eagleSystem.eagleJob.valueObject.CreateAdmin;

public  interface AdminService {
	public boolean addSubAdmin(CreateAdmin admin);
}
