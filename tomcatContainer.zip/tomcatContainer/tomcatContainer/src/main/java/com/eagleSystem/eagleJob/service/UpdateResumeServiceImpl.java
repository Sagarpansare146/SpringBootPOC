package com.eagleSystem.eagleJob.service;

public class UpdateResumeServiceImpl {

	public boolean updateResume(String ResumePath) {
		
		boolean flag = false;
		
		
		
		return flag;
	}
}
