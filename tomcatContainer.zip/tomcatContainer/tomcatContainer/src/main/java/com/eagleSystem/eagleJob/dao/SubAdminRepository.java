package com.eagleSystem.eagleJob.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.eagleSystem.eagleJob.entity.Qualification;
import com.eagleSystem.eagleJob.entity.SubAdmin;
import java.lang.String;
import java.math.BigInteger;
import java.util.List;

public interface SubAdminRepository extends JpaRepository<SubAdmin, Long>, JpaSpecificationExecutor<Qualification>{
	
	SubAdmin findByUsername(String username);
 
}
