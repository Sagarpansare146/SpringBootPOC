package com.eagleSystem.eagleJob.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Database_Customer")
public class DbCustomerEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String companyName;
	private String companyType;
	private String customerName;
	private String emailId;
	private Long contactNumber;
	private String state;
	private String city;
	private String location;
	private String website;
	private Long excelLimit = 10l;
	private Long resumeLimit = 10l;
	private Long Posting;
	private Date joinDate = new Date();
	
	private int valadity = 30;
	
	private String status;
	
	private String username;
	
	private Long excelDataUsed = 0l;
	
	private Long resumeDataUsed = 0l;
	
	private Long prices;
	
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_id")
	private Account account;
	
	@Transient
	private String password;
	
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Long getExcelLimit() {
		return excelLimit;
	}
	public void setExcelLimit(Long excelLimit) {
		this.excelLimit = excelLimit;
	}
	public Long getResumeLimit() {
		return resumeLimit;
	}
	public void setResumeLimit(Long resumeLimit) {
		this.resumeLimit = resumeLimit;
	}
	public int getValadity() {
		return valadity;
	}
	public void setValadity(int valadity) {
		this.valadity = valadity;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getExcelDataUsed() {
		return excelDataUsed;
	}
	public void setExcelDataUsed(Long excelDataUsed) {
		this.excelDataUsed = excelDataUsed;
	}
	
	
	
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public Long getPosting() {
		return Posting;
	}
	public void setPosting(Long posting) {
		Posting = posting;
	}
	public Long getPrices() {
		return prices;
	}
	public void setPrices(Long prices) {
		this.prices = prices;
	}
	public Long getResumeDataUsed() {
		return resumeDataUsed;
	}
	public void setResumeDataUsed(Long resumeDataUsed) {
		this.resumeDataUsed = resumeDataUsed;
	}
	@Override
	public String toString() {
		return "DbCustomerEntity [id=" + id + ", companyName=" + companyName + ", companyType=" + companyType
				+ ", customerName=" + customerName + ", emailId=" + emailId + ", contactNumber=" + contactNumber
				+ ", state=" + state + ", city=" + city + ", location=" + location + ", website=" + website
				+ ", excelLimit=" + excelLimit + ", resumeLimit=" + resumeLimit + ", Posting=" + Posting + ", joinDate="
				+ joinDate + ", valadity=" + valadity + ", status=" + status + ", username=" + username
				+ ", excelDataUsed=" + excelDataUsed + ", resumeDataUsed=" + resumeDataUsed + ", prices=" + prices
				+ ", password=" + password + "]";
	}

	
	
}
