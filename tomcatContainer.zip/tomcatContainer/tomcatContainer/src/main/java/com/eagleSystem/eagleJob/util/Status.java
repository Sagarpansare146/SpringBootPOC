package com.eagleSystem.eagleJob.util;


public enum Status {
	applied, 
	accepted, 
	rejected
}