package com.eagleSystem.eagleJob.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.mail.MessagingException;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MultipartFile;

import com.eagleSystem.eagleJob.UserDetailServiceImpl;
import com.eagleSystem.eagleJob.bussinessObject.CandidateBO;
import com.eagleSystem.eagleJob.dao.CandidatePrefRepository;
import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;
import com.eagleSystem.eagleJob.service.CandidateService;
import com.eagleSystem.eagleJob.service.EmailService;
import com.eagleSystem.eagleJob.util.CandidateBOPrepareUtil;
import com.eagleSystem.eagleJob.util.OTPgenerateUtil;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.UserRegistrationRequest;

@Controller
public class CandidateRegistrationController {

	@Autowired
	NaukriExcelRepository naukriExcelRepository;

	@Autowired
	private CandidateBOPrepareUtil prepareUtil;

	@Autowired
	private CandidateService registrationService;

	@Autowired
	EmailService emailService;

	@Autowired
	UserDetailServiceImpl userDetailsService;

	@Autowired
	CandidatePrefRepository candPrefRepo;

	@Autowired
	protected AuthenticationManager authenticationManager;

	@Autowired
	OTPgenerateUtil otpGenerateUtil;

	@Autowired
	CandidateService candidateService;

	public static final String REGISTRATION_MODEL = "request";

	@GetMapping(URLMapper.CANDIDATE_REGISTRATION)
	public String loadRegistrationPage(Model model, @ModelAttribute UserRegistrationRequest registrationRequest) {

		System.out.println("hii");

		// List<String> states = cityService.getAllState();

		// Map<String, List<City>> allCities = new HashMap<String, List<City>>();

		// for(String s : states) {

		// allCities.put(s, cityService.getCitiesByState(s));

		// }

		model.addAttribute(REGISTRATION_MODEL, new UserRegistrationRequest());
		// model.addAttribute("states", states);
		// model.addAttribute("cities", allCities);
		// model.addAttribute("registration_url", URLMapper.CANDIDATE_REGISTRATION);
		return ViewMapper.CANDIDATE_REGISTRATION;
	}

	@CrossOrigin
	@RequestMapping(value = "/candidateRegistration", method = RequestMethod.POST, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public boolean jUserRegistration(
			@RequestBody @ModelAttribute(REGISTRATION_MODEL) @Valid UserRegistrationRequest userRegistrationRequest,
			BindingResult result, HttpServletRequest request, HttpServletResponse response) throws IOException {

		boolean flag = true;
		System.out.println("json_reg_cad");
		System.out.println(userRegistrationRequest);

		flag = regHelper(userRegistrationRequest, request, response, true);

		return flag;
	}

	@CrossOrigin
	@RequestMapping(value = "/crosCandidateRegistration", method = RequestMethod.POST, produces = {
			"application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public boolean crosUserRegistration(
			@RequestBody @ModelAttribute(REGISTRATION_MODEL) @Valid UserRegistrationRequest userRegistrationRequest,
			BindingResult result, HttpServletRequest request, HttpServletResponse response) throws IOException {
		boolean flag = true;
		System.out.println("json_reg_cad");
		System.out.println(userRegistrationRequest);

		flag = regHelper(userRegistrationRequest, request, response, false);

		return flag;
	}

	@PostMapping(URLMapper.CANDIDATE_REGISTRATION)
	public String userRegistration(
			@Valid @ModelAttribute(REGISTRATION_MODEL) UserRegistrationRequest userRegistrationRequest,
			BindingResult result, HttpServletRequest request, HttpServletResponse response, Model model)
			throws IOException, MessagingException {

		System.out.println("jsp_reg_cad");
		String msg;
		if (result.hasErrors()) {
			return "candidate_reg";
		}

		boolean flag = false;
		boolean reg = false;
		try {     

			userRegistrationRequest.setNotificationStatus(false);
			reg = regHelper(userRegistrationRequest, request, response, true);

			try {
				if (reg)
					authenticateUserAndSetSession(userRegistrationRequest.getUsername(),
							userRegistrationRequest.getPassword(), request);
			} catch (Exception e) {
				System.out.println("error in authentication after registeration");
				e.printStackTrace();
			}
		} catch (Throwable t) {
			t.printStackTrace();
			msg = "301";
			model.addAttribute("error", msg);
			flag = true;
		}

		if (flag) {

			return "error";
		}

		/*
		 * InternetAddress ia= new InternetAddress();
		 * ia.setAddress(URLMapper.EMAIL_FROM);
		 * 
		 * String to = userRegistrationRequest.getEmail(); String subject =
		 * "Registeration with NaukriJob";
		 * 
		 * EmailTemplate template = new EmailTemplate("mailer.txt");
		 * template.setTemplate(EmailMessage.MSG);
		 * 
		 * Map<String, String> replacements = new HashMap<String, String>();
		 * replacements.put("username", userRegistrationRequest.getUsername());
		 * replacements.put("password", userRegistrationRequest.getPassword());
		 * replacements.put("name", userRegistrationRequest.getName());
		 * 
		 * String message = template.getTemplate(replacements);
		 * 
		 * Email email = new Email(ia, to, subject, message); email.setHtml(true);
		 * emailService.send(email);
		 */

		model.addAttribute("message", "success");
		return "redirect:" + URLMapper.CANDIDATE_VIEW_JOBS;
	}

	@RequestMapping(value = URLMapper.UPLOAD_RESUME, method = RequestMethod.POST, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jupdateResume(@RequestParam("resume") MultipartFile resume, HttpServletRequest request,
			ModelMap modelMap) throws Exception {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		boolean flag = true;
		String ResumePath = "";
		if (auth == null) {
			flag = false;
			return flag;
		}

		UserRegistrationRequest userRegistrationRequest = registrationService.getUserData(auth.getName());

		// Long cadId = candidateService.getCandidateId(auth.getName());

		String FName = (candPrefRepo.findOne(userRegistrationRequest.getId())).getResume();

		boolean avail = checkFile(FName);

		try {

			ResumePath = saveFile(resume, userRegistrationRequest.getName(), request);
		} catch (Exception e) {
			flag = false;
			throw new Exception("Unable to save file");
		}

		if (!(ResumePath.equals("") || ResumePath == null)) {

			if (avail) {
				deleteFile(FName);
			}
			flag = false;
			throw new Exception("Unable to save file");

		}

		return flag;
	}

	private void authenticateUserAndSetSession(String username, String passwordFromForm, HttpServletRequest request) {

		System.out.println("username:  " + username + " password: " + passwordFromForm);

		UserDetails userDetails = userDetailsService.loadUserByUsername(username);

		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
				username, passwordFromForm, userDetails.getAuthorities());
		HttpSession session = request.getSession();

		System.out.println("Line Authentication 1");

		usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetails(request));

		System.out.println("Line Authentication 2");

		Authentication authenticatedUser = authenticationManager.authenticate(usernamePasswordAuthenticationToken);

		System.out.println("Line Authentication 3");

		if (usernamePasswordAuthenticationToken.isAuthenticated()) {
			SecurityContextHolder.getContext().setAuthentication(authenticatedUser);
			System.out.println("Line Authentication 4");

		}

		request.getSession().setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY,
				SecurityContextHolder.getContext());// creates context for that session.

		System.out.println("Line Authentication 5");

		session.setAttribute("username", username);

		System.out.println("Line Authentication 6");

		session.setAttribute("authorities", usernamePasswordAuthenticationToken.getAuthorities());

		System.out.println("username:  " + username + "password: " + passwordFromForm + "authorities: "
				+ usernamePasswordAuthenticationToken.getAuthorities());

		// user = userDAO.validate(user.getUsername(), user.getPassword());
		// log.debug("You are successfully register");

	}

	public String saveFile(MultipartFile resume, String name, HttpServletRequest request) throws IOException {

		ServletContext cntxt = request.getServletContext();

		String rootPath = cntxt.getContextPath();
		System.out.println(rootPath);

		System.out.println(resume);
		String FileName = resume.getOriginalFilename();
		String FullPath = rootPath + File.separator + "Resume";

		System.out.println(FullPath);

		File dir = new File(FullPath);

		if (!dir.exists()) {
			dir.mkdirs();
		}

		String extn = FilenameUtils.getExtension(FileName);

		String token = otpGenerateUtil.generateOTP();

		File serveFile = new File(FullPath + File.separator + name + token + "." + extn);

		String ResumePath = "Resume" + File.separator + name + token + "." + extn;

		try (BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serveFile))) {

			InputStream is = resume.getInputStream();
			byte[] bytes = new byte[1024];
			int sizeRead;
			while ((sizeRead = is.read(bytes, 0, 1024)) > 0) {
				stream.write(bytes, 0, sizeRead);
			}


			stream.flush();
			stream.close();

			is.close();

		} catch (Exception e) {
			System.out.println("You failed to upload " + FileName + " => " + e.getMessage());

		}
		return ResumePath;
	}

	public boolean deleteFile(String fname) throws Exception {

		boolean flag = true;

		String FilePath = fname;

		File file = new File(FilePath);
		if (file.exists()) {
			if (file.delete()) {
				System.out.println("File deleted successfully");
			} else {
				flag = false;
				System.out.println("Fail to delete file");
			}
		} else {
			throw new Exception("Resume not exist");
		}

		return flag;

	}

	public boolean checkFile(String fName) {

		boolean flag = true;

		String FilePath = "C:" + File.separator + fName;

		File file = new File(FilePath);
		if (file.exists()) {
			return flag;
		}
		flag = false;

		return flag;

	}

	public boolean regHelper(UserRegistrationRequest userRegistrationRequest, HttpServletRequest request,
			HttpServletResponse response, boolean methodCall) throws IOException {

		boolean flag = true;

		CandidateBO candidateBO = null;
		try {

			candidateBO = prepareUtil.prepareCandidateBO(userRegistrationRequest);
			candidateBO.setCandidatePreference(prepareUtil.prepareCanPrefBO(userRegistrationRequest));
			candidateBO.setQualification(prepareUtil.prepareCandidateQualBO(userRegistrationRequest));

			String ResumePath = saveFile(userRegistrationRequest.getResume(), userRegistrationRequest.getName(),
					request);

			candidateBO.getCandidatePreference().setResume(ResumePath);

		} catch (Throwable noeE) {

			response.setHeader("status", "301");
			flag = false;

		}
		try {

			boolean abc = (flag
					? methodCall ? registrationService.candidateReg(candidateBO)
							: registrationService.crosCandidateReg(candidateBO)
					: false);

		} catch (Throwable noeE) {

			response.setHeader("status", "301");
			flag = false;

		}
		System.out.println(flag);

		if (flag) {
			response.setHeader("status", "200");

		}
		return flag;
	}

	public CandidateBOPrepareUtil getPrepareUtil() {
		return prepareUtil;
	}

	public void setPrepareUtil(CandidateBOPrepareUtil prepareUtil) {
		this.prepareUtil = prepareUtil;
	}

	public CandidateService getRegistrationService() {
		return registrationService;
	}

	public void setRegistrationService(CandidateService registrationService) {
		this.registrationService = registrationService;
	}
}