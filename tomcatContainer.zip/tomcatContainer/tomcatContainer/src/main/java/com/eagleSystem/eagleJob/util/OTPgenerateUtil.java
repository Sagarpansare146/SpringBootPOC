package com.eagleSystem.eagleJob.util;

import java.util.Random;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.entity.JPUser;

@Component 
public class OTPgenerateUtil {

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	JPUserRepository jpUserRepository;

	
	String from = "support@naukriJob.co.in";
	String subject = "NaukriJob Password Reset Link";
	public static ThreadLocal<String> threadLocal = new ThreadLocal<>();
	
	public String generateOTP() {
		return String.valueOf(new Random().nextInt(95509));
	}
	
	public boolean getOTP(String email) throws Exception {
		
		boolean flag = true;
		JPUser jpUser = jpUserRepository.findByUsernameIgnoreCase(email);
		if(jpUser == null) {
			flag = false;
			throw new Exception("Invalid User");
		}
		
		
		InternetAddress ia= new InternetAddress();
		ia.setAddress(email);
		
		
		String otp = threadLocal.get();
		
		if(otp == null || otp.equalsIgnoreCase("")) {
			otp = generateOTP();
			threadLocal.set(otp);
		}

		String msg = "Your OTP to reset password is "+otp+"\n"+ "download our app for latest job notications : https://play.google.com/store/apps/details?id=naukrijobs.eaglesystem.naukrijobs";
		
		try {
			flag = sendOtpEmail(otp, ia, msg);
	
		}catch (Exception e) {
			flag = false;
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean verifyOTP(String OTP) throws Exception {
		
		String oldOTP = threadLocal.get();
		boolean flag = true;
		if(oldOTP == null || oldOTP.equalsIgnoreCase("")) {
			throw new Exception("Invalid OTP");
		}
		
		if(oldOTP.equalsIgnoreCase(OTP)) {
			flag = true;
		}else {
			throw new Exception("OTP Not Match");
		}
		return flag;
	}
	
	public void cleadThreadLocal() {
		threadLocal.set("");
	}
	
	public boolean sendOtpEmail( String otp, InternetAddress ia, String text) {
		boolean flag = true;
		
		try {
			
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper mailMessage = new MimeMessageHelper(message);
		
		mailMessage.setTo(ia);
	//	mailMessage.setReplyTo(String.valueOf(eParams.getFrom()));
	//	helper.setFrom("Career@naukrijob.co.in", "NaukriJob");
		
		mailMessage.setFrom(from, "NaukriJob");
		mailMessage.setSubject(subject);
		mailMessage.setText(text);

		
		mailSender.send(message);

		}catch (Exception e) {
			flag = false;
			e.printStackTrace();
		}
		
		return flag;

	}
	
}
