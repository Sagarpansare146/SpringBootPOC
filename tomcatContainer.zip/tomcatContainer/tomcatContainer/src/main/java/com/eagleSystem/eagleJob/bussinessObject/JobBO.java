package com.eagleSystem.eagleJob.bussinessObject;

import java.util.Date;

public class JobBO {

	private Long postId;
	private String companyName;
	private String companyEmail;
	private Long contactNumber;
	private String companyAddress;
	private String state;
	private String city;
	private String companyWebsite;
	private String jobType;
	private String jobCategory;
	private String functionalArea;
	private String keySkill;
	private int experienceFrom;
	private int experienceTo;
	private String jobProfile;
	private String jobDetail;
	private String location;
	private Date walkinStartDate;
	private Date walkinEndDate;
	private Long salary;
	private String contactPerson;
	private String status;
	private boolean isDeleted;
	private Date postedOn;
	private Date updatedOn;
	private Long applicationCount;

	public JobBO() {
		super();
	}

	public Long getPostId() {
		return postId;
	}

	public void setPostId(Long postId) {
		this.postId = postId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getJobCategory() {
		return jobCategory;
	}

	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}

	public String getFunctionalArea() {
		return functionalArea;
	}

	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}

	public String getKeySkill() {
		return keySkill;
	}

	public void setKeySkill(String keySkill) {
		this.keySkill = keySkill;
	}

	public int getExperienceFrom() {
		return experienceFrom;
	}

	public void setExperienceFrom(int experienceFrom) {
		this.experienceFrom = experienceFrom;
	}

	public int getExperienceTo() {
		return experienceTo;
	}

	public void setExperienceTo(int experienceTo) {
		this.experienceTo = experienceTo;
	}

	public String getJobProfile() {
		return jobProfile;
	}

	public void setJobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}

	public String getJobDetail() {
		return jobDetail;
	}

	public void setJobDetail(String jobDetail) {
		this.jobDetail = jobDetail;
	}

	public Date getWalkinStartDate() {
		return walkinStartDate;
	}

	public void setWalkinStartDate(Date walkinStartDate) {
		this.walkinStartDate = walkinStartDate;
	}

	public Date getWalkinEndDate() {
		return walkinEndDate;
	}

	public void setWalkinEndDate(Date walkinEndDate) {
		this.walkinEndDate = walkinEndDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Date getPostedOn() {
		return postedOn;
	}

	public void setPostedOn(Date postedOn) {
		this.postedOn = postedOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Long getApplicationCount() {
		return applicationCount;
	}

	public void setApplicationCount(Long applicationCount) {
		this.applicationCount = applicationCount;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "JobBO [postId=" + postId + ", companyName=" + companyName + ", companyEmail=" + companyEmail
				+ ", contactNumber=" + contactNumber + ", companyAddress=" + companyAddress + ", state=" + state
				+ ", city=" + city + ", companyWebsite=" + companyWebsite + ", jobType=" + jobType + ", jobCategory="
				+ jobCategory + ", functionalArea=" + functionalArea + ", keySkill=" + keySkill + ", experienceFrom="
				+ experienceFrom + ", experienceTo=" + experienceTo + ", jobProfile=" + jobProfile + ", jobDetail="
				+ jobDetail + ", location=" + location + ", walkinStartDate=" + walkinStartDate + ", walkinEndDate="
				+ walkinEndDate + ", salary=" + salary + ", contactPerson=" + contactPerson + ", status=" + status
				+ ", isDeleted=" + isDeleted + ", postedOn=" + postedOn + ", updatedOn=" + updatedOn
				+ ", applicationCount=" + applicationCount + "]";
	}

}
