package com.eagleSystem.eagleJob.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BDM_Recuiter")
public class BDMRecuiterEntity implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long recuiterId;
	private String bdmName;
	private String status;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getRecuiterId() {
		return recuiterId;
	}
	public void setRecuiterId(Long recuiterId) {
		this.recuiterId = recuiterId;
	}
	public String getBdmName() {
		return bdmName;
	}
	public void setBdmName(String bdmName) {
		this.bdmName = bdmName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "BDMRecuiterEntity [id=" + id + ", recuiterId=" + recuiterId + ", bdmName=" + bdmName + ", status="
				+ status + "]";
	}
	public BDMRecuiterEntity(Long recuiterId, String bdmName, String status) {
		super();
		this.recuiterId = recuiterId;
		this.bdmName = bdmName;
		this.status = status;
	}
	public BDMRecuiterEntity() {
		super();
	}
	
	

	
}
