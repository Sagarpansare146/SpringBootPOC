package com.eagleSystem.eagleJob.service;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.eagleSystem.eagleJob.dao.AccountRepository;
import com.eagleSystem.eagleJob.dao.CandidateApplicationRepository;
import com.eagleSystem.eagleJob.dao.CandidatePrefRepository;
import com.eagleSystem.eagleJob.dao.DBCustomerRepository;
import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;
import com.eagleSystem.eagleJob.dao.QualificationRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.CandidatePreference;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import com.eagleSystem.eagleJob.entity.JPUser;
import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;
import com.eagleSystem.eagleJob.entity.Qualification;
import com.eagleSystem.eagleJob.service.CandidateService;
import com.eagleSystem.eagleJob.util.Role;
import com.eagleSystem.eagleJob.valueObject.CandidateRecords;
import com.eagleSystem.eagleJob.valueObject.NaukriExcelDisplay;

@Component
public class UserServiceImpl {

	@Autowired
	CandidateApplicationRepository candidateApplicationRepository;

	@Autowired
	CandidatePrefRepository candidatePrefRepository;

	@Autowired
	QualificationRepository qualifactionRepository;
	
	@Autowired
	NaukriExcelRepository naukriExcelRepository;
	
	@Autowired
	CandidateService candidateService;
	
	@Autowired
	DBCustomerRepository dBCustomerRepository;
	
	@Autowired
	JPUserRepository jpUserRepository;

	@Autowired
	AccountRepository accountRepository;


	public static Specification<NaukriExcelRecord> filterNaukriSpecification(String location, int exp, String jobCategory, String gender) {
	    return new Specification<NaukriExcelRecord>() {
			
			@Override
			public javax.persistence.criteria.Predicate toPredicate(Root<NaukriExcelRecord> root,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				// TODO Auto-generated method stub
				
				List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();
				
				if(!location.equals("")) {
					predicates.add(cb.like(root.get("preferredLocations"), "%" +location+ "%" ));
				}
				
				if(!jobCategory.equals("")) {
					predicates.add(cb.like(root.get("jobCategory"), "%" +jobCategory+ "%" ));
				}
				
				if(exp != -1 && exp != 99) {
					predicates.add(cb.like(root.get("totalExperience"), "%" +exp+" Year"+ "%" ));
				}
				if(exp == 99) {
					System.out.println("fresher");
					predicates.add(cb.equal(root.get("totalExperience"), "Fresher"));
				}
				
				if(! gender.equals("")) {
					predicates.add(cb.equal(root.get("gender"), gender ));
				}
				
				return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[0]));
			}
			
		};
	}
	
	public static Specification<CandidatePreference> filterNaukriJobSpecification( String jobCategory) {
	    return new Specification<CandidatePreference>() {
			
			@Override
			public javax.persistence.criteria.Predicate toPredicate(Root<CandidatePreference> root,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				// TODO Auto-generated method stub
				
				List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();
				
				
				if(!jobCategory.equals("")) {
					predicates.add(cb.like(root.get("jobCategory"), "%" +jobCategory+ "%" ));
				}
				
				
				
				return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[0]));
			}
			
		};
	}
	
	public static Specification<Qualification> filterNaukriJobSpecification1( String passout) {
	    return new Specification<Qualification>() {
			
			@Override
			public javax.persistence.criteria.Predicate toPredicate(Root<Qualification> root,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				// TODO Auto-generated method stub
				
				List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();
				
				
				
				return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[0]));
			}
			
		};
	}
	
	public Map<String, Object> filterNaukriJobRecords(int page, int pageSize,
			String jobCategory, String passout) {

		Pageable request =
	            new PageRequest(page - 1, pageSize,Sort.Direction.DESC,"cid");
		
		Pageable request1 =
	            new PageRequest(page - 1, pageSize,Sort.Direction.DESC,"qid");
		
		Page<CandidatePreference> pCad = null;
		Page<Qualification> pQaul = null;
		
		List<CandidatePreference> lCad = new ArrayList<>();
		List<Qualification> lQaul = new ArrayList<>();


		if((!jobCategory.equals(""))) {
		pCad = candidatePrefRepository.findAll(filterNaukriJobSpecification( jobCategory), request);
		
			
		}
		if( (!passout.equals(""))) {
		pQaul = qualifactionRepository.findAll(filterNaukriJobSpecification1(passout), request1);
		}
		
		lCad = (pCad == null ? new ArrayList<>() : pCad.getContent());
		lQaul = (pQaul == null ? new ArrayList<>() : pQaul.getContent());
		
		Map<String, Object> map = new HashMap<>();
		
		Set<Long> jobIds = new HashSet<>();
		List<Long> finalIds = new ArrayList<>();

		if (pCad == null && pQaul == null) {
			System.out.println("a");
			finalIds = new ArrayList<>();
			map.put("totalCount" , 0);
			map.put("totalPages" , 0);
			
		} else if (pQaul == null) {
			System.out.println("b");
			jobIds = lCad.stream().map(cad -> cad.getCid()).collect(Collectors.toSet());
			finalIds.addAll(jobIds);
			map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
			map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
			

		} else if (pCad == null && pQaul != null) {
			System.out.println("c");
			finalIds = lQaul.stream().map(qual -> qual.getQid()).collect(Collectors.toList());
			map.put("totalCount" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalElements()));
			map.put("totalPages" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalPages()));
			
		} else {
			System.out.println("else");
			
			jobIds = lCad.stream().map(cad -> cad.getCid()).collect(Collectors.toSet());
			Set<Long> l = jobIds;
			Set<Long> jobIds1 = lQaul.stream().map(qual -> qual.getQid()).collect(Collectors.toSet());
			if(jobIds1.size() != 0) {
				System.out.println("jobId :"+jobIds);
				System.out.println("jobId :"+jobIds1);
			finalIds = jobIds1.stream().filter(li -> (l.contains(li))).collect(Collectors.toList());
			} else {
			finalIds.addAll(jobIds);
			}
			if(pCad == null) {
				map.put("totalCount" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalElements()));
				map.put("totalPages" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalPages()));
				
			} else if(pQaul == null) {
				map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
				map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
			}
			else {
			map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
			map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
			}
		}
		
		System.out.println(finalIds);
		
		List<CandidateRecords> cadRec = candidateService.prepareRecordsObj(finalIds);
		
//		map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
//		map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
		Collections.reverse(cadRec);
		map.put("records" , cadRec);
		System.out.println(cadRec);
		return map;

	}
	
	
	public Map<String, Object> filternaukriRecords(int page, int pageSize, String location, int exp, String jobCategory,
			String degree, String gender) {

		Pageable request =
	            new PageRequest(page - 1, pageSize,Sort.Direction.DESC,"id");
		
		Set<NaukriExcelRecord> finalrec = new HashSet<>();
		
		Map<String, Object> map = new HashMap<>();
		
		Page<NaukriExcelRecord> pNauk = naukriExcelRepository.findAll(filterNaukriSpecification(location, exp, jobCategory, gender), request);
		
		if(pNauk != null)
		finalrec.addAll(pNauk.getContent());
		
		List<NaukriExcelDisplay> lNauk = ( finalrec != null ? finalrec.stream().map(e -> makeObject(e)).collect(Collectors.toList()) : new ArrayList<>());
		Collections.reverse(lNauk);
		map.put("request", lNauk);
		map.put("totalCount", (pNauk != null ? pNauk.getTotalElements() : 0));
		map.put("totalPages", (pNauk != null ? pNauk.getTotalPages() : 0));
		
		return map;

	}
	
	public NaukriExcelDisplay makeObject(NaukriExcelRecord record) {
		
		NaukriExcelDisplay canRec = new NaukriExcelDisplay();

		canRec.setId(record.getId());
		canRec.setName(record.getName());
		canRec.setLocation(record.getCurrentLocation());
		canRec.setQualification(record.getUgCourse());
		canRec.setTotalExpInYear(record.getTotalExperience());
		canRec.setJobCategory(record.getJobCategory());
		canRec.setKeySkill(record.getKeySkills());
		canRec.setPreferredLocations(record.getPreferredLocations());
		canRec.setGender(record.getGender());
		return canRec;
	}
	
	@Transactional
	public boolean dbCustomerReg(DbCustomerEntity customerEntity) throws Exception {

		boolean flag = true;

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		JPUser jpUser = new JPUser();

		if (jpUserRepository.findByUsernameIgnoreCase(customerEntity.getUsername()) != null) {
			throw new Exception("Aleardy Exist User");
		}
		
		if( authentication == null ) {
			throw new Exception("Invalid BDM");
		}
		
		try {
			jpUser.setUsername(customerEntity.getUsername());
			jpUser.setPassword(customerEntity.getPassword());
			jpUser.setEnabled(true);
			jpUser.setRole(Role.database.name());
		
			Account account = accountRepository.findByUsername(authentication.getName());
			
			customerEntity.setAccount(account);
			DbCustomerEntity dbCust = dBCustomerRepository.save(customerEntity);
			
			List<DbCustomerEntity> custList = account.getDbCustomer();
			custList.add(dbCust);
			account.setDbCustomer(custList);
			accountRepository.save(account);
	//		customerBDMRepository.save(new CustomerSubAdmin(dbCust.getId(), authentication.getName()));
			
			jpUserRepository.save(jpUser);

		} catch (Exception e) {
			e.printStackTrace();

			flag = false;
		}

		return flag;

	}
	
	
	public List<NaukriExcelRecord> commonDownloadBdmNaukriExcelRecord(Long cadId[]) {
		
		List<Long> cIds = Arrays.asList(cadId);
	
		List<NaukriExcelRecord> records = new ArrayList<>();

		
		records = cIds.stream().map(id -> naukriExcelRepository.findOne(id)).collect(Collectors.toList());
		
	//	System.out.println(records);
		
		return (records == null ? new ArrayList<>() : records);
		
	}
	
	


	public List<NaukriExcelRecord> commonDownloadBdmNaukriJobExcelRecord(Long cadId[]) {
		
		List<Long> cIds = Arrays.asList(cadId);
	
		List<NaukriExcelRecord> records = new ArrayList<>();

		
		records = cIds.stream().map(id -> naukriExcelRepository.findOne(id)).collect(Collectors.toList());
		
	//	System.out.println(records);
		
		return (records == null ? new ArrayList<>() : records);
		
	}
	
	public List<NaukriExcelRecord> downloadBdmNaukriExcelRecord(Long cadId[]) {
		return commonDownloadBdmNaukriExcelRecord(cadId);
	}
	
	public List<NaukriExcelRecord> downloadBdmNaukriJobExcelRecord(Long cadId[]) {
		return commonDownloadBdmNaukriJobExcelRecord(cadId);
		
	}
	
	public List<String> resumeNaukriPath(Long ids[]) {
		
		return commonResumeNaukriPath(ids);
		
	}

	public List<String> resumeNaukriJobPath(Long ids[]) {
		
		
		return commonResumeNaukriJobPath(ids);
		
	}
	
	public List<String> commonResumeNaukriPath(Long ids[]) {
		
		return naukriExcelRepository.getResumePath(ids).stream().filter(s -> s != null).filter(s -> !s.equals("")).collect(Collectors.toList());
		
	}

	public List<String> commonResumeNaukriJobPath(Long ids[]) {
		
		return candidatePrefRepository.getResumePath(ids);
		
	}

	
	public List<NaukriExcelRecord> recDownloadBdmNaukriExcelRecord(Long cadId[]) {
		
		return commonDownloadBdmNaukriExcelRecord(cadId);
	}
	
	public List<NaukriExcelRecord> recDownloadBdmNaukriJobExcelRecord(Long cadId[]) {
		
		return commonDownloadBdmNaukriJobExcelRecord(cadId);
	}
	
	public List<String> recResumeNaukriPath(Long ids[]) {
		
		return commonResumeNaukriPath(ids);
	}
	
	public List<String> recResumeNaukriJobPath(Long ids[]) {
		
		return commonResumeNaukriJobPath(ids);
		
	}
	
	public List<NaukriExcelRecord> bdmDownloadBdmNaukriExcelRecord(Long cadId[]) {
		
		return commonDownloadBdmNaukriExcelRecord(cadId);
	}
	
	public List<NaukriExcelRecord> bdmDownloadBdmNaukriJobExcelRecord(Long cadId[]) {
		
		return commonDownloadBdmNaukriJobExcelRecord(cadId);
	}
	
	public List<String> bdmResumeNaukriPath(Long ids[]) {
		
		return commonResumeNaukriPath(ids);
	}
	
	public List<String> bdmResumeNaukriJobPath(Long ids[]) {
		
		return commonResumeNaukriJobPath(ids);
		
	}
	
}
