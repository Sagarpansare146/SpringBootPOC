package com.eagleSystem.eagleJob.valueObject;

import java.util.Date;

import org.hibernate.validator.constraints.Email;
import org.springframework.format.annotation.DateTimeFormat;

public class JobPostRequest {

	private Long postId;
	
	private String companyName = "";
	
	@Email
	private String companyEmail = "";
	
	private Long contactNumber;
	
	private String companyAddress = "";
	
	private String state = "";
	
	private String city = "";
	
	private String companyWebsite = "";
	
	private String jobType = "";
	
	private String jobCategory = "";
	
	private String functionalArea = "";
	
	private String keySkill = "";
	
	
	private Integer experienceFrom ;
	private Integer experienceTo;
	
	private String jobProfile = "";
	private String jobDetail = "";
	
	private String contactPerson = "";
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date walkinStartDate;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date walkinEndDate;
	
	private Long salary;
	
	private String Location;
	
	public JobPostRequest() {
		super();
	}


	public Long getPostId() {
		return postId;
	}


	public void setPostId(Long postId) {
		this.postId = postId;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public String getCompanyEmail() {
		return companyEmail;
	}


	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}


	public Long getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}


	public String getCompanyAddress() {
		return companyAddress;
	}


	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getCompanyWebsite() {
		return companyWebsite;
	}


	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}


	public String getJobType() {
		return jobType;
	}


	public void setJobType(String jobType) {
		this.jobType = jobType;
	}


	public String getJobCategory() {
		return jobCategory;
	}


	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}


	public String getFunctionalArea() {
		return functionalArea;
	}


	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}


	public String getKeySkill() {
		return keySkill;
	}


	public void setKeySkill(String keySkill) {
		this.keySkill = keySkill;
	}


	public Integer getExperienceFrom() {
		return experienceFrom;
	}


	public void setExperienceFrom(Integer experienceFrom) {
		this.experienceFrom = experienceFrom;
	}


	public Integer getExperienceTo() {
		return experienceTo;
	}


	public void setExperienceTo(Integer experienceTo) {
		this.experienceTo = experienceTo;
	}


	public String getJobProfile() {
		return jobProfile;
	}


	public void setJobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}


	public String getJobDetail() {
		return jobDetail;
	}


	public void setJobDetail(String jobDetail) {
		this.jobDetail = jobDetail;
	}


	public String getContactPerson() {
		return contactPerson;
	}


	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}


	public Date getWalkinStartDate() {
		return walkinStartDate;
	}


	public void setWalkinStartDate(Date walkinStartDate) {
		this.walkinStartDate = walkinStartDate;
	}


	public Date getWalkinEndDate() {
		return walkinEndDate;
	}


	public void setWalkinEndDate(Date walkinEndDate) {
		this.walkinEndDate = walkinEndDate;
	}


	public Long getSalary() {
		return salary;
	}


	public void setSalary(Long salary) {
		this.salary = salary;
	}


	public String getLocation() {
		return Location;
	}


	public void setLocation(String location) {
		Location = location;
	}


	@Override
	public String toString() {
		return "JobPostRequest [postId=" + postId + ", companyName=" + companyName + ", companyEmail=" + companyEmail
				+ ", contactNumber=" + contactNumber + ", companyAddress=" + companyAddress + ", state=" + state
				+ ", city=" + city + ", companyWebsite=" + companyWebsite + ", jobType=" + jobType + ", jobCategory="
				+ jobCategory + ", functionalArea=" + functionalArea + ", keySkill=" + keySkill + ", experienceFrom="
				+ experienceFrom + ", experienceTo=" + experienceTo + ", jobProfile=" + jobProfile + ", jobDetail="
				+ jobDetail + ", contactPerson=" + contactPerson + ", walkinStartDate=" + walkinStartDate
				+ ", walkinEndDate=" + walkinEndDate + ", salary=" + salary + ", Location=" + Location + "]";
	}


	
	
	
}
