package com.eagleSystem.eagleJob.businessExcel;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eagleSystem.eagleJob.dao.MonsterExcelRepository;;

@RestController
@CrossOrigin

public class MonstarDownloadRecord {

	
	
	
	@Autowired
	MonsterExcelRepository monsterExcelRepository;

	
	
	@Cacheable("MonstercurrentLocation")
	@RequestMapping(value = "/getMonsterPrefLocation")
	public Set<String> getLocations() {
		
		List<String> currentLocation = monsterExcelRepository.findDistinctcurrentLocation();
		Set<String> location = new HashSet<>();
		currentLocation.parallelStream().forEach(loc -> location.addAll(Arrays.asList(loc.split(","))));
		location.forEach(e -> e.trim());
		return location;
		

	}
	
	@Cacheable("MonsterjobCategory")
		@RequestMapping(value = "/getMonsterJobCategory")
	public Set<String> getJobCategory() {
		
		List<String> jobC = monsterExcelRepository.findDistinctjobCategory();
		Set<String> jobCategory= new HashSet<>();
		jobC.parallelStream().forEach(jc -> jobCategory.addAll(Arrays.asList(jc.split(","))));
		jobCategory.forEach(e -> e.trim());
		return jobCategory;

	}
}
