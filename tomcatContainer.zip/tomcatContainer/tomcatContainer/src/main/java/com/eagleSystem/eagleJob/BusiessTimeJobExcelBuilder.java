package com.eagleSystem.eagleJob;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;


import com.eagleSystem.eagleJob.entity.TimesExcelRecord;

public class BusiessTimeJobExcelBuilder  extends AbstractXlsView  {

	@Override
	protected void buildExcelDocument(Map model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String name = (String) model.get("industry");

		// change the file name
		response.setHeader("Content-Disposition", "attachment; filename=\""+ "TimesJobExcel"+ "_"+ name + ".xls\"");

		@SuppressWarnings("unchecked")
		List<TimesExcelRecord> records = (List<TimesExcelRecord>) model.get("records");

		// create excel xls sheet
		Sheet sheet = workbook.createSheet("Job Post Response");

		// create header row
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("Sr. no.");
		header.createCell(1).setCellValue("CandidateName");
		header.createCell(2).setCellValue("EmailID");
		header.createCell(3).setCellValue("ContactNumber");
		header.createCell(4).setCellValue("ResumeTitle");
		header.createCell(5).setCellValue("TotalWorkExperience");
		header.createCell(6).setCellValue("HighestEducationLevel");
		header.createCell(7).setCellValue("JobCategory");
		
		int rowCount = 0;                             
		for (TimesExcelRecord course : records) {               
			Row courseRow = sheet.createRow(++rowCount);
			System.out.println(rowCount);
			courseRow.createCell(0).setCellValue(rowCount);
			courseRow.createCell(1).setCellValue(course.getName());
			courseRow.createCell(2).setCellValue(course.getEmailId());
			courseRow.createCell(3).setCellValue(course.getMobileNo());
			courseRow.createCell(4).setCellValue(course.getResumeTitle());
			courseRow.createCell(5).setCellValue(course.getWorkExperience());
			courseRow.createCell(6).setCellValue(course.getCourseHighestEducation());
			courseRow.createCell(7).setCellValue(course.getJobCategory());
			
		}

	}
	
}
