package com.eagleSystem.eagleJob.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.springframework.beans.factory.annotation.Autowired;

import com.eagleSystem.eagleJob.bussinessObject.JobBO;
import com.eagleSystem.eagleJob.dao.JobRepository;
import com.eagleSystem.eagleJob.entity.JobPost;

public class CandidateUpdateAspect {

	@Autowired
	JobRepository JobRepo;

	@Around(value = "execution(* com.eagleSystem.eagleJob.service.JobServiceImpl.updateJob(..))")
	public Object cadUpdateCheck(ProceedingJoinPoint pjp) throws Throwable {
		JobPost job = JobRepo.findOne(((JobBO) (pjp.getArgs())[0]).getPostId());

		if ((job == null)) {
			throw new Exception("Invalid job");
		}
		System.out.println(job.getJobProfile());
		return pjp.proceed();

	}

}
