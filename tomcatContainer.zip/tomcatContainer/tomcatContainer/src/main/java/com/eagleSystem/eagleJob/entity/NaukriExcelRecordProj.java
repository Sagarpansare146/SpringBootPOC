package com.eagleSystem.eagleJob.entity;

public interface NaukriExcelRecordProj {

	public long getId();

	public String getName();

	public String getGender();

	public String getTotalExperience();

	public String getKeySkills();

	public String getFunctionalArea();

	public String getPreferredLocations();

	public String getUgCourse();

	public String getJobCategory();

}
