package com.eagleSystem.eagleJob.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "JOB_POST")
public class JobPost implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "COMPANY_NAME")
	private String companyName;
	
	@Column(name = "COMPANY_EMAIL")
	private String companyEmail;
	
	@Column(name = "MOBNO")
	private Long contactNumber;
	
	@Column(name = "COMPANY_WEBSITE")
	private String companyWebsite;
		
	@Column(name = "COMPANY_ADDRESS")
	private String companyAddress;
	
	@Column(name = "STATE")
	private String state;
	
	@Column(name = "CITY")
	private String city;
	
	@Column(name = "CATEGORY")
	private String jobCategory;
	
	@Column(name = "FUNCTIONAL_AREA")
	private String functionalArea;
	
	@Column(name = "KEYSKILL")
	private String keySkill;
	
	@Column(name = "JOBTYPE")
	private String jobType;
	
	@Column(name = "EXPERIENCE_FROM")
	private int experienceFrom;
	
	@Column(name = "EXPERIENCE_TO")
	private int experienceTo;
	
	@Column(name = "JOB_PROFILE")
	private String jobProfile;
	
	@Column(name = "JOB_DETAIL")
	private String jobDetail;
	
	@Column(name = "WALKIN_START_DATE")
	@Temporal(TemporalType.DATE)
	private Date walkinStartDate;
	
	@Column(name = "WALKIN_END_DATE")
	@Temporal(TemporalType.DATE)
	private Date walkinEndDate;
	
	@Column(name = "CONTACT_PERSON")
	private String contactPerson;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "AVAIL")
	private boolean isDeleted;
	
	@Column(name = "POSTED_ON")
	@Temporal(TemporalType.TIMESTAMP)
	private Date postedOn;
	
	@Column(name = "UPDATED_ON")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedOn;
	
	@Column(name = "RESPONSE_COUNT")
	private Long applicationCount;
	
	@Column(name = "RECORDS_DOWNLOAD_COUNT")
	private Integer excelRecordsDownloadCount;
	
	@Column(name = "RESUME_DOWNLOAD_COUNT")
	private Integer resumeDownloadCount;
	
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "recruiter_id")
	private Recruiter recruiter;

	@Column(name= "SALARY")
	private Long salary;
	
	@Column(name = "LOCATION")
	private String location;
	
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	public String getJobCategory() {
		return jobCategory;
	}

	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}

	public String getFunctionalArea() {
		return functionalArea;
	}

	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}

	public String getKeySkill() {
		return keySkill;
	}

	public void setKeySkill(String keySkill) {
		this.keySkill = keySkill;
	}

	public int getExperienceFrom() {
		return experienceFrom;
	}

	public void setExperienceFrom(int experienceFrom) {
		this.experienceFrom = experienceFrom;
	}

	public int getExperienceTo() {
		return experienceTo;
	}

	public void setExperienceTo(int experienceTo) {
		this.experienceTo = experienceTo;
	}

	public String getJobProfile() {
		return jobProfile;
	}

	public void setJobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}

	public String getJobDetail() {
		return jobDetail;
	}

	public void setJobDetail(String jobDetail) {
		this.jobDetail = jobDetail;
	}

	public Date getWalkinStartDate() {
		return walkinStartDate;
	}

	public void setWalkinStartDate(Date walkinStartDate) {
		this.walkinStartDate = walkinStartDate;
	}

	public Date getWalkinEndDate() {
		return walkinEndDate;
	}

	public void setWalkinEndDate(Date walkinEndDate) {
		this.walkinEndDate = walkinEndDate;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Date getPostedOn() {
		return postedOn;
	}

	public void setPostedOn(Date postedOn) {
		this.postedOn = postedOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Long getApplicationCount() {
		return applicationCount;
	}

	public void setApplicationCount(Long applicationCount) {
		this.applicationCount = applicationCount;
	}

	public JobPost() {
		super();
	}

	public Recruiter getRecruiter() {
		return recruiter;
	}

	public void setRecruiter(Recruiter recruiter) {
		this.recruiter = recruiter;
	}

	
	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	

	public Integer getExcelRecordsDownloadCount() {
		return excelRecordsDownloadCount;
	}

	public void setExcelRecordsDownloadCount(Integer excelRecordsDownloadCount) {
		this.excelRecordsDownloadCount = excelRecordsDownloadCount;
	}

	public Integer getResumeDownloadCount() {
		return resumeDownloadCount;
	}

	public void setResumeDownloadCount(Integer resumeDownloadCount) {
		this.resumeDownloadCount = resumeDownloadCount;
	}

	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "JobPost [id=" + id + ", companyName=" + companyName + ", companyEmail=" + companyEmail
				+ ", contactNumber=" + contactNumber + ", companyWebsite=" + companyWebsite + ", companyAddress="
				+ companyAddress + ", state=" + state + ", city=" + city + ", jobCategory=" + jobCategory
				+ ", functionalArea=" + functionalArea + ", keySkill=" + keySkill + ", jobType=" + jobType
				+ ", experienceFrom=" + experienceFrom + ", experienceTo=" + experienceTo + ", jobProfile=" + jobProfile
				+ ", jobDetail=" + jobDetail + ", walkinStartDate=" + walkinStartDate + ", walkinEndDate="
				+ walkinEndDate + ", contactPerson=" + contactPerson + ", status=" + status + ", isDeleted=" + isDeleted
				+ ", postedOn=" + postedOn + ", updatedOn=" + updatedOn + ", applicationCount=" + applicationCount
				+ ", excelRecordsDownloadCount=" + excelRecordsDownloadCount + ", resumeDownloadCount="
				+ resumeDownloadCount + ", recruiter=" + recruiter + ", salary=" + salary + ", location=" + location
				+ "]";
	}

		
}
