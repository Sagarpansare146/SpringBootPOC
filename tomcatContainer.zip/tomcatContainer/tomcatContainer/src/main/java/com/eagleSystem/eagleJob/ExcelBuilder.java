package com.eagleSystem.eagleJob;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.document.AbstractXlsView;
import com.eagleSystem.eagleJob.valueObject.CandidateExcelRecords;

@Component
public class ExcelBuilder extends AbstractXlsView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
	
		String name = (String) model.get("name");

		// change the file name
		response.setHeader("Content-Disposition", "attachment; filename=\"" + name + ".xls\"");

		@SuppressWarnings("unchecked")
		List<CandidateExcelRecords> records = (List<CandidateExcelRecords>) model.get("request");


		// create excel xls sheet
		Sheet sheet = workbook.createSheet("Job Post Response");

		// create header row
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("Sr. no.");
		header.createCell(1).setCellValue("Name");
		header.createCell(2).setCellValue("Email Id");
		header.createCell(3).setCellValue("Contact Number");
		header.createCell(4).setCellValue("Gender");
		header.createCell(5).setCellValue("Current Location");
		header.createCell(6).setCellValue("Keyskill");
		header.createCell(7).setCellValue("Experience");
		header.createCell(8).setCellValue("Job Location");
		header.createCell(9).setCellValue("Qualification");
		header.createCell(10).setCellValue("Specilization");
		header.createCell(11).setCellValue("University");
		header.createCell(12).setCellValue("Year of Passout");
		header.createCell(13).setCellValue("Percentage");

		// Create data cells
		int rowCount = 0;
		for (CandidateExcelRecords course : records) {
			Row courseRow = sheet.createRow(++rowCount);
			courseRow.createCell(0).setCellValue(rowCount);
			courseRow.createCell(1).setCellValue((course.getName() == null) ? "Not Mentioned" : course.getName());
			courseRow.createCell(2).setCellValue((course.getEmail() == null) ? "Not Mentioned" : course.getEmail());
			courseRow.createCell(3).setCellValue((course.getContactNumber() == null) ? "Not Mentioned" : String.valueOf(course.getContactNumber()));
			courseRow.createCell(4).setCellValue((course.getGender() == null) ? "Not Mentioned" : course.getGender());
			courseRow.createCell(5).setCellValue((course.getCandidateCity() == null) ? "Not Mentioned" : course.getCandidateCity());
			courseRow.createCell(6).setCellValue((course.getKeySkill() == null) ? "Not Mentioned" : course.getKeySkill());
			courseRow.createCell(7). setCellValue((course.getExperience() == null) ? "Not Mentioned" : String.valueOf(course.getExperience())+" Years" + "-" + String.valueOf(course.getMonth()+" months"));
			courseRow.createCell(8).setCellValue((course.getLocation() == null) ? "Not Mentioned" : course.getLocation());
			courseRow.createCell(9).setCellValue((course.getDegree() == null) ? "Not Mentioned" : course.getDegree());
			courseRow.createCell(10).setCellValue((course.getSpecilization() == null) ? "Not Mentioned" : course.getSpecilization());
			courseRow.createCell(11).setCellValue((course.getUniversity() == null) ? "Not Mentioned" : course.getUniversity());
			courseRow.createCell(12).setCellValue((course.getPassout() == null) ? "Not Mentioned" : String.valueOf(course.getPassout()));
			courseRow.createCell(13).setCellValue((course.getPercentage() == null) ? "Not Mentioned" : String.valueOf(course.getPercentage()));
		}
	}

}
