package com.eagleSystem.eagleJob.aspect;

import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.InternetAddress;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.bussinessObject.CandidateBO;
import com.eagleSystem.eagleJob.bussinessObject.Email;
import com.eagleSystem.eagleJob.dao.CandidateRepository;
import com.eagleSystem.eagleJob.entity.Candidate;
import com.eagleSystem.eagleJob.service.EmailService;
import com.eagleSystem.eagleJob.util.EmailTemplate;

@Aspect
@Component
public class CandidateRegAspect extends AbstractAppPointcut {

	@Autowired
	EmailService emailService;

	@Autowired
	CandidateRepository candidateRepo;

	@Around("cadRegpointcut()")
	public Object cadRegCheck(ProceedingJoinPoint pjp) throws Throwable {

		Object obj[] = pjp.getArgs();
		String email = ((CandidateBO) obj[0]).getEmail();
		String username = ((CandidateBO) obj[0]).getUsername();

		Candidate candidate = candidateRepo.findByEmail(email);

		if (!(candidate == null)) {
			System.out.println(candidate.getName());
			throw new NumberFormatException("Mobile Number or Email id already registered");
		}

		boolean flag = (boolean) pjp.proceed();

		try {
			InternetAddress ia = new InternetAddress();
			ia.setAddress("registration@naukriJob.co.in");

			String to = email;
			String subject = "Welcome to NaukriJob";

			EmailTemplate template = new EmailTemplate("email-templates/candidateLogin.txt");
			// template.setTemplate(CustomerEmailMessage.MSG);

			Map<String, String> replacements = new HashMap<String, String>();
			replacements.put("${username}", username);
			replacements.put("${password}", ((CandidateBO) obj[0]).getPassword());
			replacements.put("${name}", ((CandidateBO) obj[0]).getName());
			replacements.put("apkLink",
					"https://play.google.com/store/apps/details?id=naukrijobs.eaglesystem.naukrijobs");

			String message = template.getHtmlTemplate(replacements);

			Email email1 = new Email(ia, to, subject, message);
			email1.setHtml(true);
			emailService.send(email1);
		} catch (Throwable th) {
			System.out.println("sorry email cant be sent");
		}
		return flag;
	}
}
