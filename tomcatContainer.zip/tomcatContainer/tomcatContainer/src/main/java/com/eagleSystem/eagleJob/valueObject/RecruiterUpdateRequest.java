package com.eagleSystem.eagleJob.valueObject;

public class RecruiterUpdateRequest {

}
