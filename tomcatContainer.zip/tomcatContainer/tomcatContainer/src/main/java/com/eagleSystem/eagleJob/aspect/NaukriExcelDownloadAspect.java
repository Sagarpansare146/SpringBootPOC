package com.eagleSystem.eagleJob.aspect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.dao.CustomerDownloadRecordsRepository;
import com.eagleSystem.eagleJob.dao.DBCustomerRepository;
import com.eagleSystem.eagleJob.entity.CustomerDownloadRecords;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;

@Aspect
@Component
public class NaukriExcelDownloadAspect extends AbstractAppPointcut{
	
	@Autowired
	DBCustomerRepository dbCustomerRepository;
	
	@Autowired
	CustomerDownloadRecordsRepository customerDownloadRecordsRepository;
	
	@Around("databaseExcelNaukriPointCut()")
	public Object checkBeforeDownload(ProceedingJoinPoint pjp) throws Throwable {

		System.out.println("excel aspect");

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

	//	Recruiter rec = recruiterRepository.findByUsername(auth.getName());

		
		DbCustomerEntity dbCustomerEntity = dbCustomerRepository.findByUsername(auth.getName());
		
		Object obj[] = pjp.getArgs();
		Long[] cadId = (Long[]) obj[0];
	
		Long limit = dbCustomerEntity.getExcelLimit();
		Long oldDownloadedCount = dbCustomerEntity.getExcelDataUsed();
		Long canDownloadCount = limit - oldDownloadedCount;
		Long count = (long) cadId.length;
		List<Long> lcadId = new ArrayList<>();
		Long downloadedCount = 0l;
		
		if(canDownloadCount == 0 && oldDownloadedCount == limit) {
			throw new Exception("You reached your download Limit");
		} else if (canDownloadCount <= count) {
			
			lcadId = Arrays.stream(cadId).limit(canDownloadCount).collect(Collectors.toList());
			downloadedCount = (long) lcadId.size();
			
		}else {
			downloadedCount = count;
		}
		
		
		Object ret = pjp.proceed();
		
		dbCustomerEntity.setExcelDataUsed(oldDownloadedCount + downloadedCount);
		
		dbCustomerEntity = dbCustomerRepository.save(dbCustomerEntity);
		
		CustomerDownloadRecords custRecord = new CustomerDownloadRecords();
		
		custRecord.setCustomer(auth.getName());
		custRecord.setCurrentExcelCount(dbCustomerEntity.getExcelDataUsed());
		custRecord.setDownloadExcelCount(downloadedCount);
		custRecord.setDownloadDate(new Date());
		
		customerDownloadRecordsRepository.save(custRecord);
		
		return ret;

	}

}
