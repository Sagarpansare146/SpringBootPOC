package com.eagleSystem.eagleJob.valueObject;

import java.util.Date;

public class ListJobForCandidate {


		private Long postId;
		private String companyName = "";
		private String location = "";
		private String keySkill = "";
		private Integer experienceFrom = 0;
		private Integer experienceTo = 0;
		private String jobProfile = "";
		private Date postedOn;
		private boolean isApplied;
		
		
		public ListJobForCandidate() {
			super();
		}


		public Long getPostId() {
			return postId;
		}


		public void setPostId(Long postId) {
			this.postId = postId;
		}


		public String getCompanyName() {
			return companyName;
		}


		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}


		public String getLocation() {
			return location;
		}


		public void setLocation(String location) {
			this.location = location;
		}


		public String getKeySkill() {
			return keySkill;
		}


		public void setKeySkill(String keySkill) {
			this.keySkill = keySkill;
		}


		public Integer getExperienceFrom() {
			return experienceFrom;
		}


		public void setExperienceFrom(Integer experienceFrom) {
			this.experienceFrom = experienceFrom;
		}


		public Integer getExperienceTo() {
			return experienceTo;
		}


		public void setExperienceTo(Integer experienceTo) {
			this.experienceTo = experienceTo;
		}


		public String getJobProfile() {
			return jobProfile;
		}


		public void setJobProfile(String jobProfile) {
			this.jobProfile = jobProfile;
		}


		public Date getPostedOn() {
			return postedOn;
		}


		public void setPostedOn(Date postedOn) {
			this.postedOn = postedOn;
		}


		public boolean isApplied() {
			return isApplied;
		}

		public boolean getIsApplied() {
			return isApplied;
		}



		public void setApplied(boolean isApplied) {
			this.isApplied = isApplied;
		}


		@Override
		public String toString() {
			return "ListJobForCandidate [postId=" + postId + ", companyName=" + companyName + ", location=" + location
					+ ", keySkill=" + keySkill + ", experienceFrom=" + experienceFrom + ", experienceTo=" + experienceTo
					+ ", jobProfile=" + jobProfile + ", postedOn=" + postedOn + ", isApplied=" + isApplied + "]";
		}

		
		
}
