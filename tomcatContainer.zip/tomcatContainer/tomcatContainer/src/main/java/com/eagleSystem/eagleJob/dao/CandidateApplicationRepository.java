package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eagleSystem.eagleJob.entity.CandidateApplication;

@Repository
public interface CandidateApplicationRepository extends JpaRepository<CandidateApplication, Long> {

	List<CandidateApplication> findByJobPostId(Long jobId);

	@Query("select ca.candidate.id from CandidateApplication ca where ca.jobPost.id = :jobId")
	List<Long> findCandidateIdsByJobPost(@Param("jobId") Long jobId);

	CandidateApplication findByJobPostIdAndCandidateId(Long jobId, Long candidateId);
	
	List<CandidateApplication> findByCandidateIdOrderByAppliedOnDesc(Long candidateId);
	
	@Query("SELECT ca.jobPost.id FROM CandidateApplication ca WHERE ca.candidate.id = :candidateId")
	Page<Long> getAppliedJobIds(@Param("candidateId") Long CandidateId, Pageable pageable);
	
	@Query("SELECT ca.jobPost.id FROM CandidateApplication ca WHERE ca.candidate.id = :candidateId")
	List<Long> getAllAppliedJobIds(@Param("candidateId") Long CandidateId);
}