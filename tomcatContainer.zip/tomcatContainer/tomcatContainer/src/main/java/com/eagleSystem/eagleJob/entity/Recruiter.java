package com.eagleSystem.eagleJob.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


@Entity
@Table(name="RECRUITER", uniqueConstraints = {@UniqueConstraint(columnNames = {"email"})})
public class Recruiter implements Serializable {

	@Id
	@Column(name = "RECRUITER_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "NAME")
	private String name;
	
	@Column(name = "DESIGNATION")
	private String Designation;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "MobNo")
	private Long mobNo ;

	@Column(name = "USERNAME")
	private String username;
	
	@OneToMany(mappedBy = "recruiter", fetch = FetchType.LAZY)
	private List<JobPost> postedJobs;

	
	@OneToOne
	private MasterPlan masterPlan;
	
	@OneToOne
	private BoosterPlan boosterPlan;

	
	private Date joinDate = new Date();

	
	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public Recruiter() {

	}	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	public Long getMobNo() {
		return mobNo;
	}


	public void setMobNo(Long mobNo) {
		this.mobNo = mobNo;
	}


	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	
	public List<JobPost> getPostedJobs() {
		return postedJobs;
	}

	public void setPostedJobs(List<JobPost> postedJobs) {
		this.postedJobs = postedJobs;
	}


	public MasterPlan getMasterPlan() {
		return masterPlan;
	}


	public void setMasterPlan(MasterPlan masterPlan) {
		this.masterPlan = masterPlan;
	}


	public BoosterPlan getBoosterPlan() {
		return boosterPlan;
	}


	public void setBoosterPlan(BoosterPlan boosterPlan) {
		this.boosterPlan = boosterPlan;
	}

	@Override
	public String toString() {
		return "Recruiter [id=" + id + ", name=" + name + ", Designation=" + Designation + ", email=" + email
				+ ", mobNo=" + mobNo + ", username=" + username + "]";
	}

	

}