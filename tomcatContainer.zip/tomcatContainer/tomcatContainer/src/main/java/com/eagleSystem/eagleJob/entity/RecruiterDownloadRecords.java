package com.eagleSystem.eagleJob.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RecruiterDownloadRecords {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String recruiter;
	
	private int downloadExcelCount;
	private int currentExcelCount;
	private int downloadResumeCount;
	private int currentResumeCount;
	private Date downloadDate;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getRecruiter() {
		return recruiter;
	}
	public void setRecruiter(String recruiter) {
		this.recruiter = recruiter;
	}
	public int getDownloadExcelCount() {
		return downloadExcelCount;
	}
	public void setDownloadExcelCount(int downloadExcelCount) {
		this.downloadExcelCount = downloadExcelCount;
	}
	public int getCurrentExcelCount() {
		return currentExcelCount;
	}
	public void setCurrentExcelCount(int currentExcelCount) {
		this.currentExcelCount = currentExcelCount;
	}
	public int getDownloadResumeCount() {
		return downloadResumeCount;
	}
	public void setDownloadResumeCount(int downloadResumeCount) {
		this.downloadResumeCount = downloadResumeCount;
	}
	public int getCurrentResumeCount() {
		return currentResumeCount;
	}
	public void setCurrentResumeCount(int currentResumeCount) {
		this.currentResumeCount = currentResumeCount;
	}
	public Date getDownloadDate() {
		return downloadDate;
	}
	public void setDownloadDate(Date downloadDate) {
		this.downloadDate = downloadDate;
	}


	
}
