package com.eagleSystem.eagleJob.customException;

public class NumberOrEmailExistException extends Exception{

	public NumberOrEmailExistException() {
		super();
	}

	public NumberOrEmailExistException(String message, Throwable cause) {
		super(message, cause);
	}

	public NumberOrEmailExistException(String message) {
		super(message);
	}

	public NumberOrEmailExistException(Throwable cause) {
		super(cause);
	}

	
}
