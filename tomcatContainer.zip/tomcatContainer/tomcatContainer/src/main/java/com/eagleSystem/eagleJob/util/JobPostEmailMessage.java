package com.eagleSystem.eagleJob.util;

public interface JobPostEmailMessage {

	String MSG = "{{job Title}}- {{Keyskills}}\r\n" + 
			"\r\n" + 
			"Dear Candidate \r\n" + 
			"\r\n" + 
			"Here are new jobs matching your profile\r\n" + 
			"\r\n" + 
			"Jobs in your preferred location and keyskill\r\n" + 
			"\r\n" + 
			"{{job Title}}\r\n" + 
			"\r\n" + 
			"Location : {{Location}}\r\n" + 
			"\r\n" + 
			"Keyskills: {{Keyskills}}\r\n" + 
			"\r\n" + 
			"Urgent Openings {{job Title}} - ({{Experience}}-{{month}}) years\r\n" + 
			"\r\n" + 
			"Out Sourcing Company\r\n" + 
			"\r\n" + 
			"{{company Locaton}}\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"Apply Here : {{jobLink}}" +
			"\r\n" + 
			"Looking for a different kind of job? Tell us, and get relevant jobs in your inbox.\r\n" + 
			"\r\n" + 
			"Set your job alert\r\n" + 
			"\r\n" + 
			"Wish you good luck in your job search.\r\n" + 
			"\r\n" + 
			"Regards,\r\n" + 
			"\r\n" + 
			"'NaukriJob.co.in team'\r\n" + 
			"\r\n" + 
			"Join us on\r\n" + 
			"NaukriJob Mobile App {{apkLink}} \r\n"+
			
			"Unsubscribe Report a problem.hr@naukrijob.co.in\r\n" + 
			"\r\n" + 
			"You have received this mail because your e-mail ID is registered with NaukriJob.co.in.com. This is a system-generated e-mail regarding your NaukriJob.co.in account preferences, please don't reply to this message. The jobs sent in this mail have been posted by the clients of NaukriJob.co.in.com. And we have enabled auto-login for your convenience, you are strongly advised not to forward this email to protect your account from unauthorized access. IEIL has taken all reasonable steps to ensure that the information in this mailer is authentic. Users are advised to research bonafides of advertisers independently. Please do not pay any money to anyone who promises to find you a job. IEIL shall not have any responsibility in this regard. We recommend that you visit our Terms & Conditions and the Security Advice for more comprehensive information.";
	
}
