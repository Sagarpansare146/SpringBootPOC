package com.eagleSystem.eagleJob.valueObject;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class RecruiterRegistrationRequest {

// Recruiter related input data
	
	private Long recruiterId;
	
	@NotEmpty(message = "Recruiter Name cannot be blank")
	private String recruiterName = "";
	
	@NotEmpty(message = "Designation cannot be blank")
	private String Designation = "";
	
	@Email
	@NotEmpty(message = "email cannot be blank")
	private String email = "";
	
	@NotNull(message="Mobile number cannot be empty")
	private Long MobNo ;
	
	@NotEmpty(message = "username cannot be blank")
	private String username;
	
	@NotEmpty(message = "password cannot be blank")
	private String password;
		
// Company related input data
	
	@NotEmpty(message = "Company Type cannot be blank")
	private String companyType = "";
	
	@NotEmpty(message = "Company Name cannot be blank")
	private String companyName = "";
	
	@NotEmpty(message = "Company Address cannot be blank")
	private String companyAddress = "";
	
	@NotEmpty(message = "city cannot be blank")
	private String city = "";
	
	@NotNull
	private String detail = "";
	
	@NotNull
	private String state = "";
	
	
	private String GSTNO = "";
	
	
	public RecruiterRegistrationRequest() {
		super();
	}


	public Long getRecruiterId() {
		return recruiterId;
	}


	public void setRecruiterId(Long recruiterId) {
		this.recruiterId = recruiterId;
	}


	public String getRecruiterName() {
		return recruiterName;
	}


	public void setRecruiterName(String recruiterName) {
		this.recruiterName = recruiterName;
	}


	public String getDesignation() {
		return Designation;
	}


	public void setDesignation(String designation) {
		Designation = designation;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Long getMobNo() {
		return MobNo;
	}


	public void setMobNo(Long mobNo) {
		MobNo = mobNo;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getCompanyType() {
		return companyType;
	}


	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public String getCompanyAddress() {
		return companyAddress;
	}


	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getDetail() {
		return detail;
	}


	public void setDetail(String detail) {
		this.detail = detail;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getGSTNO() {
		return GSTNO;
	}


	public void setGSTNO(String gSTNO) {
		GSTNO = gSTNO;
	}


	@Override
	public String toString() {
		return "RecruiterRegistrationRequest [recruiterId=" + recruiterId + ", recruiterName=" + recruiterName
				+ ", Designation=" + Designation + ", email=" + email + ", MobNo=" + MobNo + ", username=" + username
				+ ", password=" + password + ", companyType=" + companyType + ", companyName=" + companyName
				+ ", companyAddress=" + companyAddress + ", city=" + city + ", detail=" + detail + ", state=" + state
				+ ", GSTNO=" + GSTNO + "]";
	}



}
