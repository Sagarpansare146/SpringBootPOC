package com.eagleSystem.eagleJob.businessExcel;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;

@CrossOrigin
@RestController
public class NaukriDownloadRecord {

	@Autowired
	NaukriExcelRepository naukriExcelRepository;

	@Cacheable("prefLocation")
	@RequestMapping(value = "/getPrefLocation")
	public Set<String> getLocations() {
		
		List<String> PrefLocations = naukriExcelRepository.findDistinctCity();
		Set<String> locations = new HashSet<>();
		PrefLocations.parallelStream().forEach(loc -> locations.addAll(Arrays.asList(loc.split(","))));
		locations.forEach(e -> e.trim());
		return locations;
		

	}
	
	@Cacheable("currentLocationNukari")
	@RequestMapping(value = "/getcurrentLocation")
	public Set<String> getcurrentLocations() {
		
		List<String> CurrentLocation = naukriExcelRepository.findDistinctCurrentLocation();
		Set<String> currentLocation = new HashSet<>();
		CurrentLocation.parallelStream().forEach(loc -> currentLocation.addAll(Arrays.asList(loc.split(","))));
		currentLocation.forEach(e -> e.trim());
		return currentLocation;
		
	}
	
	@Cacheable("jobCategory")
	@RequestMapping(value = "/getJobCategory")
	public Set<String> getJobCategory() {
		
		List<String> jobC = naukriExcelRepository.findDistinctJobCategory();
		Set<String> jobCategory = new HashSet<>();
		jobC.parallelStream().forEach(jc -> jobCategory.addAll(Arrays.asList(jc.split(","))));
		jobCategory.forEach(e -> e.trim());
		return jobCategory;

	}
	
	@Cacheable("jobKeySkill")
	@RequestMapping(value = "/getKeySkill")
	public Set<String> getKeySkill() {
		
		List<String> keySkill = naukriExcelRepository.findDistinctKeySkills();
		Set<String> skills = new HashSet<>();
		keySkill.parallelStream().forEach(ks -> skills.addAll(Arrays.asList(ks.split(","))));
		skills.forEach(e -> e.trim());
		return skills;

	}
	
	@Cacheable("jobUgCourse")
	@RequestMapping(value = "/getJobUgCourse")
	public Set<String> getQualification() {
		
		List<String> ugCourse = naukriExcelRepository.findDistinctUgCourse();
		Set<String> ugC = new HashSet<>();
		ugCourse.parallelStream().forEach(uc -> ugC.addAll(Arrays.asList(uc.split(","))));
		ugC.forEach(e -> e.trim());
		return ugC;

	}
	
	@Cacheable("annualSalaryNaukri")
	@RequestMapping(value = "/getannualSalary")
	public Set<String> getannualSalary() {
		
		List<String> annualSalary = naukriExcelRepository.findDistinctannualSalary();
		Set<String> annualsalary = new HashSet<>();
		annualSalary.parallelStream().forEach(uc -> annualsalary.addAll(Arrays.asList(uc.split(","))));
		annualsalary.forEach(e -> e.trim());
		return annualsalary;

	}
	
}
