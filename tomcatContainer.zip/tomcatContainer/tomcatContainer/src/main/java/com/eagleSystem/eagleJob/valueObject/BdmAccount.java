package com.eagleSystem.eagleJob.valueObject;

public class BdmAccount {

	private String name;
	private String email;
	private String role;
	private Long excelLimit;
	private Long resumeLimit;
	private Long target;
	private Long loaction;
	
	private Long excelDownloadedCount;
	private Long resumeDownloadedCount;
	private Long recruiterLimitPerDay;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Long getExcelLimit() {
		return excelLimit;
	}

	public void setExcelLimit(Long excelLimit) {
		this.excelLimit = excelLimit;
	}

	public Long getResumeLimit() {
		return resumeLimit;
	}

	public void setResumeLimit(Long resumeLimit) {
		this.resumeLimit = resumeLimit;
	}

	public Long getTarget() {
		return target;
	}

	public void setTarget(Long target) {
		this.target = target;
	}

	public Long getLoaction() {
		return loaction;
	}

	public void setLoaction(Long loaction) {
		this.loaction = loaction;
	}

	public Long getRecruiterLimitPerDay() {
		return recruiterLimitPerDay;
	}

	public void setRecruiterLimitPerDay(Long recruiterLimitPerDay) {
		this.recruiterLimitPerDay = recruiterLimitPerDay;
	}

	public Long getExcelDownloadedCount() {
		return excelDownloadedCount;
	}

	public void setExcelDownloadedCount(Long excelDownloadedCount) {
		this.excelDownloadedCount = excelDownloadedCount;
	}

	public Long getResumeDownloadedCount() {
		return resumeDownloadedCount;
	}

	public void setResumeDownloadedCount(Long resumeDownloadedCount) {
		this.resumeDownloadedCount = resumeDownloadedCount;
	}

		
	
}
