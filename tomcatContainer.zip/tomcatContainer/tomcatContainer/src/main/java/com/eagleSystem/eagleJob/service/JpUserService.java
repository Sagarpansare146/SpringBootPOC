package com.eagleSystem.eagleJob.service;

import com.eagleSystem.eagleJob.entity.JPUser;

public interface JpUserService {

	public JPUser getUserByUsername(String username);
}
