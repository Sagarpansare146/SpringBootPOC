package com.eagleSystem.eagleJob;

import java.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.eagleSystem.eagleJob.entity.JPUser;
import com.eagleSystem.eagleJob.service.JpUserService;
import com.eagleSystem.eagleJob.service.JpUserServiceImpl;

@Service
public class UserDetailServiceImpl implements UserDetailsService {

	@Autowired
	JpUserService jpUser = new JpUserServiceImpl();

	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		JPUser user;
		try {
			System.out.println("UserDetails");
			System.out.println(jpUser);
			System.out.println(userId);
			user = jpUser.getUserByUsername(userId);
			System.out.println(user);
			if (user == null)
				throw new UsernameNotFoundException("user name not found");

		} catch (Exception e) {
			throw new UsernameNotFoundException("database error ");
		}
		return buildUserFromUserEntity(user);
	}

	private UserDetails buildUserFromUserEntity(JPUser userEntity) {
		// convert model user to spring security user
		String username = userEntity.getUsername();
		String password = userEntity.getPassword();
		boolean enabled = userEntity.isEnabled();
		boolean accountNonExpired = true;
		boolean credentialsNonExpired = true;
		boolean accountNonLocked = true;
		SimpleGrantedAuthority[] authorities = new SimpleGrantedAuthority[1];
		authorities[0] = new SimpleGrantedAuthority(userEntity.getRole());

		UserDetails springUser = new User(username, password, enabled, accountNonExpired, credentialsNonExpired,
				accountNonLocked, Arrays.asList(authorities));
		System.out.println(springUser);
		return springUser;
	}

	public JpUserService getJpUser() 
	{
		return jpUser;
	}

	public void setJpUser(JpUserService jpUser) {
		this.jpUser = jpUser;
	}

}