package com.eagleSystem.eagleJob.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.eagleSystem.eagleJob.entity.BDMRecuiterEntity;
import java.lang.String;
import java.util.List;

public interface BDMRecruiterRepository extends JpaRepository<BDMRecuiterEntity, Long> {

	@Query("select cp from BDMRecuiterEntity cp where cp.bdmName = bdmName")
	List<BDMRecuiterEntity> getIdByBdmName(@Param("bdmName") String bdmname);

	List<BDMRecuiterEntity> findByBdmName(String name);
	Page<BDMRecuiterEntity> findByBdmName(String name, Pageable pageable);
}
