package com.eagleSystem.eagleJob.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="SUB_ADMIN", uniqueConstraints = {@UniqueConstraint(columnNames = {"email", "MOBNO"})})
public class SubAdmin {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "MOBNO")
	private Long contactNumber;
	
	@Column(name = "LOCATION")
	private String location;
	
	@Column(name = "USERNAME")
	private String username;
	
	@Column(name = "PASSWORD")
	@Transient
	private String password;
	
	private Date joinDate = new Date();
	
	@JsonIgnore
	@OneToMany(mappedBy = "subAdmin", fetch = FetchType.LAZY)
	private List<PlanUpdateRecord> planUpdateRecord;
	
	@JsonIgnore
	@OneToMany(mappedBy = "subAdmin", fetch = FetchType.LAZY)
	private List<Account> account;
	
	
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "admin_id")
	private Admin admin;
	
	
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	public List<PlanUpdateRecord> getPlanUpdateRecord() {
		return planUpdateRecord;
	}
	public void setPlanUpdateRecord(List<PlanUpdateRecord> planUpdateRecord) {
		this.planUpdateRecord = planUpdateRecord;
	}
	public List<Account> getAccount() {
		return account;
	}
	public void setAccount(List<Account> account) {
		this.account = account;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "SubAdmin [id=" + id + ", name=" + name + ", email=" + email + ", contactNumber=" + contactNumber
				+ ", location=" + location + ", username=" + username + ", password=" + password + ", joinDate="
				+ joinDate + "]";
	}
	
	
	
}
