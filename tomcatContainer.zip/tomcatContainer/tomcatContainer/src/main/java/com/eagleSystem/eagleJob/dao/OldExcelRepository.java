package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagleSystem.eagleJob.entity.OldExcel;

public interface OldExcelRepository extends JpaRepository<OldExcel, Long> {

	List<OldExcel> findByJobCatagoryAndLocation(String jobCategory, String location);
	
}
