package com.eagleSystem.eagleJob.service;

import java.util.List;

import com.eagleSystem.eagleJob.bussinessObject.CandidateBO;
import com.eagleSystem.eagleJob.valueObject.CandidateRecords;
import com.eagleSystem.eagleJob.valueObject.UserRegistrationRequest;

public interface CandidateService {
	
	public boolean candidateReg(CandidateBO candidateBO);
	public boolean crosCandidateReg(CandidateBO candidateBO);
	public UserRegistrationRequest getUserData(String username);
	public UserRegistrationRequest getCandidate(String username);
	public Long getCandidateId(String username);
	public List<CandidateRecords> prepareRecordsObj(List<Long> ids);
	public boolean candidateUpdate(UserRegistrationRequest registrationRequest, Long id);
	public long getCandidateCount();
}
