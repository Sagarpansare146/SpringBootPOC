package com.eagleSystem.eagleJob.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.stereotype.Component;
import org.springframework.beans.BeanUtils;

@Component
public class AppBeanUtils {
	
	private static final Logger logger = LoggerFactory.getLogger(AppBeanUtils.class);
	
	public static Set<String> getNullPropertyNames (Object source,String... extra) {
	    final BeanWrapper src = new BeanWrapperImpl(source);
	    java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();
	    Set<String> emptyNames = new HashSet<String>();
	    for(java.beans.PropertyDescriptor pd : pds) {
	        Object srcValue = src.getPropertyValue(pd.getName());
	        if (srcValue == null) {
	        logger.info("attribute {}",pd.getName());
	        emptyNames.add(pd.getName());
	        }
	    }
	    for(String args : extra) {
	    emptyNames.add(args);
	    }
	    return emptyNames;
	}
	
	public static Object maker (Object source,Object target) {
	/*    final BeanWrapper src = new BeanWrapperImpl(source);
	    final BeanWrapper tar = new BeanWrapperImpl(target);
	    java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();
	    java.beans.PropertyDescriptor[] pds1 = tar.getPropertyDescriptors();
	 */
		
	    Method mSrc[] = source.getClass().getDeclaredMethods();
	    Method mTar[] = target.getClass().getDeclaredMethods();
	    Field fSrc[] = source.getClass().getDeclaredFields();
	    Field fTar[] = target.getClass().getDeclaredFields();
	    
	    Set<String> emptyProp = AppBeanUtils.getNullPropertyNames(source, "");
	    
//	    Set<String> emptyNames = new HashSet<String>();
	    for(Field pd : fSrc) {
	    	
	    	 for(Field pd1 : fTar) {
	    		 
	    		 if(pd.getName().equals(pd1.getName()) && !(emptyProp.contains(pd1))) {
	    			 
	    			 Optional<Method> meth = Arrays.stream(mTar).filter(m -> m.getName().equals( "set"+ pd1.getName().substring(0, 1).toUpperCase() + pd1.getName().substring(1))).findFirst();
	    			 Optional<Method> meth1 = Arrays.stream(mSrc).filter(m -> m.getName().equals( "get"+ pd1.getName().substring(0, 1).toUpperCase() + pd1.getName().substring(1))).findFirst();
	    			 
	    			 try {
//						pd1.getWriteMethod().invoke(target, srcValue);
	    				 meth.get().invoke(target, (Object)meth1.get().invoke(source));
	    		    		
					} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
						e.printStackTrace();
						
					}
	    		 }
	    	 }
	    }
	    	/*Object srcValue = src.getPropertyValue(pd.getName());
	        
	    	if (srcValue == null) {
	        logger.info("attribute {}",pd.getName());
	        emptyNames.add(pd.getName());
	        }
	    }
	    for(String args : extra) {
	    emptyNames.add(args);
	    }
	    return emptyNames;
	*/
	    	 
	    return target;
	    }
	
	
	public static Object buildEntity(Object source, Object target, String... extra) {
		
		Set<String> ignoreFields = getNullPropertyNames(target, extra);
		BeanUtils.copyProperties(source, target, ignoreFields.toArray(new String[ignoreFields.size()]));
	    
		return target;	
	}
	
	/*  public Vehicle editVehicleDetails(long vehicleId , Vehicle vehicle) {
	    Vehicle original = vehicleRepository.findById(vehicleId).orElse(null);
	    Set<String> ignoreFields = com.amoebiq.product.vehiman.controller.utils.BeanUtils.getNullPropertyNames(vehicle,"id","owner");
	    BeanUtils.copyProperties(original, vehicle,ignoreFields.toArray(new String[ignoreFields.size()]));
	    serviceDetailsRepository.save(service);
	}*/

}
