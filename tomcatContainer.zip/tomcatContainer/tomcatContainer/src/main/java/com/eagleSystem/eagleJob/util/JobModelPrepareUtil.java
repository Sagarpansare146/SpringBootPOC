package com.eagleSystem.eagleJob.util;

import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.bussinessObject.JobBO;
import com.eagleSystem.eagleJob.entity.JobPost;

@Component
public class JobModelPrepareUtil {

	public JobPost prepareJobPost(JobBO jobBO) {
		
		JobPost jobPost = new JobPost();
//		String keySkill = "";
		
		if(!(jobBO.getPostId() == null)) 
		jobBO.setPostId(jobBO.getPostId());
		jobPost.setCompanyName(jobBO.getCompanyName());
		jobPost.setCompanyEmail(jobBO.getCompanyEmail());
//		jobPost.setCompanyType(jobBO.getCompanyType());
		jobPost.setCompanyWebsite(jobBO.getCompanyWebsite());
		jobPost.setContactNumber(jobBO.getContactNumber());
		jobPost.setContactPerson(jobBO.getContactPerson());
		jobPost.setExperienceFrom(jobBO.getExperienceFrom());
		jobPost.setExperienceTo(jobBO.getExperienceTo());
		jobPost.setFunctionalArea(jobBO.getFunctionalArea());
		jobPost.setJobCategory(jobBO.getJobCategory());
		jobPost.setJobDetail(jobBO.getJobDetail());
		jobPost.setJobProfile(jobBO.getJobProfile());
		jobPost.setJobType(jobBO.getJobType());		
		jobPost.setLocation(jobBO.getLocation());
/*		for (String ks : jobBO.getKeySkill()) {
			keySkill = keySkill + ks;
		}
*/		
		jobPost.setKeySkill(jobBO.getKeySkill());
		jobPost.setState(jobBO.getState());
		jobPost.setCity(jobBO.getCity());
		jobPost.setCompanyAddress(jobBO.getCompanyAddress());
		jobPost.setWalkinStartDate(jobBO.getWalkinStartDate());
		jobPost.setWalkinEndDate(jobBO.getWalkinEndDate());
		
		jobPost.setDeleted(jobBO.isDeleted());
		jobPost.setPostedOn(jobBO.getPostedOn());
		jobPost.setStatus(jobBO.getStatus());
		jobPost.setUpdatedOn(jobBO.getUpdatedOn());
		
		return jobPost;
	}
	
}
