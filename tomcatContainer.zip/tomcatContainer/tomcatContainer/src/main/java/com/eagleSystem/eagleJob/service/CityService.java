package com.eagleSystem.eagleJob.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.eagleSystem.eagleJob.dao.CityRepository;
import com.eagleSystem.eagleJob.entity.City;

@Service
public class CityService {

	@Autowired
	CityRepository cityRepository;
	
	@Cacheable
	public List<City> getAllState() {
		
		return cityRepository.getAllState();
	}
	
	@Cacheable
	public List<City> getCitiesByState(String state) {
		
		return cityRepository.getCitiesByState(state);
	}
	
	
}
