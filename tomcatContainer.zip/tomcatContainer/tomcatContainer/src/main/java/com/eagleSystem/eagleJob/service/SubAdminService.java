package com.eagleSystem.eagleJob.service;

import com.eagleSystem.eagleJob.valueObject.CreateSubadmin;

public interface SubAdminService {
	public boolean addSubAdmin(CreateSubadmin subadmin);

}
