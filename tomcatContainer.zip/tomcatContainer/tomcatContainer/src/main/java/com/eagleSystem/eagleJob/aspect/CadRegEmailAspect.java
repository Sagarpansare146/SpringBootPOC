package com.eagleSystem.eagleJob.aspect;

public class CadRegEmailAspect {

}
