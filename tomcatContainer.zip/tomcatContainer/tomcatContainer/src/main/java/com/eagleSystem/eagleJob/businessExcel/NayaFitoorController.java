package com.eagleSystem.eagleJob.businessExcel;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.eagleSystem.eagleJob.controller.CandidateRegistrationController;
import com.eagleSystem.eagleJob.dao.CandidatePrefRepository;
import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;
import com.eagleSystem.eagleJob.dao.OtherRecords;
import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;
import com.eagleSystem.eagleJob.entity.OtherRecordsEntity;
import com.eagleSystem.eagleJob.util.ResumeUtil;
import com.eagleSystem.eagleJob.util.URLMapper;

@CrossOrigin
@RestController
public class NayaFitoorController {
	
	@Autowired
	CandidatePrefRepository candPrefRepo;
	
	CandidateRegistrationController canRegCon = new CandidateRegistrationController();
	
	@Autowired
	NaukriExcelRepository naukriExcelRepository;
	
	@Autowired
	OtherRecords otherRecords;
	
	@Autowired
	ResumeUtil resumeUtil;
	
	@RequestMapping("/corsResumeUpdate")
	@ResponseBody
	public boolean jupdateResume(@RequestParam("email") String email, @RequestParam("experience") String experience, @RequestParam("resume") MultipartFile resume) throws Exception {

		boolean flag = true;
		String ResumePath = "";
		boolean avail = false;
		
		if(resume.isEmpty()) {
			
			return false;
		}
		
		
		NaukriExcelRecord excelRecord = naukriExcelRepository.findByEmailIDContaining(email);
	System.out.println(excelRecord);
		if(excelRecord != null)
			avail = (excelRecord.getResumePath() == null || excelRecord.getResumePath().equalsIgnoreCase("") ? false : true);

	
		String directory = "c:" + File.separator + "BDM_Resume" + File.separator + "zip";
		
		if(excelRecord == null) {
			flag = save(email, experience, resume);			
			
			return flag;
		}
		
		
		
		System.out.println("hii");
		try {

			ResumePath = resumeUtil.fileReader(resume, directory);
		} catch (Exception e) {
			flag = false;
			
		}

		if (flag && (ResumePath != null || !(ResumePath.equals("")))) {

			if(excelRecord.getResumePath() != null )
				
				canRegCon.deleteFile(excelRecord.getResumePath());
			
				excelRecord.setTotalExperience(experience);
				excelRecord.setResumePath(ResumePath);
				naukriExcelRepository.save(excelRecord);
				return flag;
		
		}

		System.out.println(flag);
		return flag;
	}

	
	private boolean save(String email, String experience, MultipartFile resume) throws Exception {

		boolean flag = true;
		String ResumePath = "";
		String directory = "c:" + File.separator + "OtherResume";
		try {
			ResumePath = resumeUtil.fileReader(resume, directory);
		} catch (Exception e) {
			flag = false;
		}

		if (flag && !(ResumePath.equals(""))) {

			otherRecords.save(new OtherRecordsEntity(email, experience , ResumePath));
			return flag;
		}
		return flag;		
	}
	
}
