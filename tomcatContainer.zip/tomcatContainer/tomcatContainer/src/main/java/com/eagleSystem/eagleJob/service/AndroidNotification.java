/*package com.eagleSystem.eagleJob.service;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

public class AndroidNotification {

	
	public void setNotification() {
		
		try {
			String deviceToken = "";
			String androidFcmKey = "XXXXXXXXXXXX";
			String androidFcmUrl = "https://fcm.googleapis.com/fcm/send";

			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.set("Authorization", "key=" + androidFcmKey);
			httpHeaders.set("Content-Type", "application/json");
			JSONObject msg = new JSONObject();
			JSONObject json = new JSONObject();

			msg.put("title", "Title");
			msg.put("body", "Message");
			msg.put("notificationType", "Test");

			json.put("data", msg);
			json.put("to", deviceToken);

			HttpEntity<String> httpEntity = new HttpEntity<String>(json.toString(), httpHeaders);
			String response = restTemplate.postForObject(androidFcmUrl, httpEntity, String.class);
			System.out.println(response);
		} catch (JSONException e) {
			e.printStackTrace();
		}

	}
}
*/