package com.eagleSystem.eagleJob.service.Admin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eagleSystem.eagleJob.dao.AccountRepository;
import com.eagleSystem.eagleJob.dao.BDMRecruiterRepository;
import com.eagleSystem.eagleJob.dao.CandidateRepository;
import com.eagleSystem.eagleJob.dao.ClientNaukriRepository;
import com.eagleSystem.eagleJob.dao.DBCustomerRepository;
import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.dao.SubAdminRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.BDMRecuiterEntity;
import com.eagleSystem.eagleJob.entity.Candidate;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import com.eagleSystem.eagleJob.entity.JPUser;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.entity.SubAdmin;
import com.eagleSystem.eagleJob.util.Coverter;
import com.eagleSystem.eagleJob.valueObject.CreateSubadmin;

@Service
public class AdminServiceImpl  {
	
	
	
	@Autowired
	JPUserRepository jpUserRepository;
	@Autowired
	SubAdminRepository subAdminRepository;
	
	@Autowired
	CandidateRepository candidateRepository;

	@Autowired
	NaukriExcelRepository naukriExcelRepository;
	
	@Autowired
	RecruiterRepository recruiterRepository;
	
	@Autowired
	AccountRepository account;
	
	
	@Autowired
	DBCustomerRepository dbCustomerRepository ;
	
	
	@Autowired 
	BDMRecruiterRepository bdmRecruiterRepository ;
	
	@Autowired
	SubAdminRepository subadminRepository;
	
	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired 
	ClientNaukriRepository clientNaukriRepository;
	
	//for server 2 database count ......Note**........getCount method using Naukrijob database count aslo candidate  record count 
	
	public long getCount()
	{
		
		return candidateRepository.count();

	}
	
	//for server 1 database count
	public long getNaukriCount()
	{
		return naukriExcelRepository.count();
	}
	
	public long getClientNaukriCount()
	{
		return clientNaukriRepository.count();
	}
	
	//for All Module Account count
	
	public long getRecruiters()
	{
		return recruiterRepository.count();
	}
	
	
	public long dbCustomer()
	{
		return dbCustomerRepository.count();
		
	}
	
	public long bdmAccount()
	{
		List<Account> listOfBdm;
		listOfBdm = account.findByRole("bdm"); 
		
		if(listOfBdm==null) {
			
			return 0;
			
		}
		else {
			
			return listOfBdm.size();
			
		}
		
	}
	
	public long getsubadmin()
	{
		return subadminRepository.count();
		
	}
	
	public long getUser()
	{
		
		List<Account> listOfBdm;
		listOfBdm = account.findByRole("user"); 
		
		if(listOfBdm==null) {
			
			return 0;
			
		}
		else {
			
			return listOfBdm.size();
			
		}
	
		
	}
	
	
	

	
	
	@Transactional
	public boolean addSubAdmin(CreateSubadmin subadmin) throws Exception {
		boolean flag = true;

		SubAdmin subAdmin = (new Coverter()).converSubAdmin(subadmin);

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}

		JPUser jpUser = jpUserRepository.findByUsernameIgnoreCase(subAdmin.getUsername());

		if (jpUser != null) {
			throw new Exception("Already Register with username : " + subAdmin.getUsername());
		}

		jpUser = new JPUser();

		jpUser.setUsername(subAdmin.getUsername());
		jpUser.setPassword(subAdmin.getPassword());
		jpUser.setEnabled(true);
		jpUser.setRole("subadmin");
		try {
			subAdminRepository.save(subAdmin);
			jpUserRepository.save(jpUser);
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}

		return flag;
}
	
	
	
	//GET SUBADMIN 
	
	public List<SubAdmin> getSubadminReport() throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}

		
		return subAdminRepository.findAll();

	}
	
	//get Emp by role 
	
	public Map<String, Object> getAllEmpByRole(String role, int page, int pageSize) {

		
		Map<String, Object> map = new HashMap<>();

		Pageable pageRequest;

		switch (role) {

		case "candidate":

			pageRequest = new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "id");

			Page<Candidate> dataPage = candidateRepository.findAll(pageRequest);

			map.put("data", dataPage.getContent());
			map.put("totalCount", (dataPage != null ? 0 : dataPage.getTotalElements()));
			map.put("totalPages", (dataPage != null ? 0 : dataPage.getTotalPages()));
			break;

		case "recruiter":

			pageRequest = new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "id");

			Page<BDMRecuiterEntity> dataPage1 = bdmRecruiterRepository.findAll(
					pageRequest);
						map.put("data", dataPage1.getContent());
			map.put("totalCount", (dataPage1 != null ? 0 : dataPage1.getTotalElements()));
			map.put("totalPages", (dataPage1 != null ? 0 : dataPage1.getTotalPages()));
		
			break;

		/*
		 * case Role.user.name() :
		 * 
		 * break;
		 * 
		 */
		default:

			pageRequest = new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "id");

			Page<Account> dataPage2 = accountRepository.findAll(pageRequest);
			map.put("data", dataPage2.getContent().stream().filter(e -> e.getRole().equals(role)).collect(Collectors.toList()));
			map.put("totalCount", (dataPage2 != null ? 0 : dataPage2.getTotalElements()));
			map.put("totalPages", (dataPage2 != null ? 0 : dataPage2.getTotalPages()));
			break;
		}

		return map;
	}
	
	public List<DbCustomerEntity> getCustomerReport() throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}

		
		return dbCustomerRepository.findAll();
				
	}
	
	public List<Recruiter> getPostingReport() throws Exception {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null) {
			throw new Exception("Invalid User");
		}

		
		return recruiterRepository.findAll();
				
	}
	

	
	@Cacheable(cacheNames = "subAdmin", key = "#username")
	private SubAdmin getSubAdmin(String username) {

		return subAdminRepository.findByUsername(username);

	}

	@CacheEvict(cacheNames = "subAdmin", key = "#username")
	public SubAdmin updateSubAdmin(String username) {
		return subAdminRepository.findByUsername(username);
	}

	
}
