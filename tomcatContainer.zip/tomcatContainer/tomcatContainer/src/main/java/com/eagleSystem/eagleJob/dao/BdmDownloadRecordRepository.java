package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagleSystem.eagleJob.entity.BdmDownloadRecord;

public interface BdmDownloadRecordRepository extends JpaRepository<BdmDownloadRecord, Long> {

	List<BdmDownloadRecord> findByBdm(String bdm);
}
