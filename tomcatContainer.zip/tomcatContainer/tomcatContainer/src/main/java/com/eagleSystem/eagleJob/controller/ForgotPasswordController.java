package com.eagleSystem.eagleJob.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.entity.JPUser;
import com.eagleSystem.eagleJob.service.EmailService;
import com.eagleSystem.eagleJob.util.OTPgenerateUtil;
import com.eagleSystem.eagleJob.util.URLMapper;

public class ForgotPasswordController {

	@Autowired
	EmailService emailService;

	@Autowired
	JPUserRepository jpUserRepository;

	@Autowired
	OTPgenerateUtil otpGenerateUtil;

	@PostMapping(value = URLMapper.FORGOT_PASSWORD, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jForgetPassword(@RequestParam("email") String email, @RequestParam("otp") String otp,
			@RequestParam("password") String password, Model model) {

		JPUser jpUser = jpUserRepository.findByUsernameIgnoreCase(email);
		boolean flag = true;

		try {

			if (jpUser == null) {
				flag = false;
				model.addAttribute("error", "Invalid Email Address");
				return flag;
			}

			flag = otpGenerateUtil.verifyOTP(otp);

			if (flag) {
				jpUser.setPassword(password);
				jpUserRepository.save(jpUser);
				otpGenerateUtil.cleadThreadLocal();
			}

		} catch (Throwable th) {
			flag = false;
			System.out.println("sorry email cant be sent");
		}

		return flag;
	}

	@PostMapping(value = URLMapper.FORGOT_PASSWORD)
	public String forgetPassword(@RequestParam("email") String email, @RequestParam("otp") String otp,
			@RequestParam("password") String password, Model model) {

		boolean flag = true;

		try {
			flag = jForgetPassword(email, otp, password, model);
		} catch (Throwable th) {
			flag = false;
			th.printStackTrace();
		}

		if (!flag)
			return "error";

		model.addAttribute("error", "error");

		return "redirect:" + URLMapper.CANDIDATE_LOGIN;
	}
}
