package com.eagleSystem.eagleJob.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CustomerDownloadRecords {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String customer;
	
	private Long downloadExcelCount;
	private Long currentExcelCount;
	private Long downloadResumeCount;
	private Long currentResumeCount;
	private Date downloadDate;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public Long getDownloadExcelCount() {
		return downloadExcelCount;
	}
	public void setDownloadExcelCount(Long downloadExcelCount) {
		this.downloadExcelCount = downloadExcelCount;
	}
	public Long getCurrentExcelCount() {
		return currentExcelCount;
	}
	public void setCurrentExcelCount(Long currentExcelCount) {
		this.currentExcelCount = currentExcelCount;
	}
	public Long getDownloadResumeCount() {
		return downloadResumeCount;
	}
	public void setDownloadResumeCount(Long downloadResumeCount) {
		this.downloadResumeCount = downloadResumeCount;
	}
	public Long getCurrentResumeCount() {
		return currentResumeCount;
	}
	public void setCurrentResumeCount(Long currentResumeCount) {
		this.currentResumeCount = currentResumeCount;
	}
	public Date getDownloadDate() {
		return downloadDate;
	}
	public void setDownloadDate(Date downloadDate) {
		this.downloadDate = downloadDate;
	}

	
}
