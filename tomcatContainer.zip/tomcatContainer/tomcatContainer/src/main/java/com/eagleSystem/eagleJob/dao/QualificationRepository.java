package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.query.Param;

import com.eagleSystem.eagleJob.entity.Qualification;
import com.querydsl.core.types.Predicate;

public interface QualificationRepository extends JpaRepository<Qualification, Long>, JpaSpecificationExecutor<Qualification>{

	@Query("SELECT q.qid, q.experience, q.month FROM Qualification q WHERE q.qid = :candidateId")
	Object getCandidateQualRecord(@Param("candidateId") Long candidateId);

	@Query("select q.qid from Qualification q where q.experience = :experience")
	List<Long> findIdByExp(@Param("experience") Integer experience);
	@Query("select q.qid from Qualification q where q.experience = :experience")
	List<Long> findIdByDegree(@Param("experience") String experience);

	@Query("select q from Qualification q where q.passout = :passout")
	List<Qualification> findIdByPassout(@Param("passout") Integer passout);

	
//	Iterable<Qualification> findAll(Predicate predicate);
	@Query("SELECT DISTINCT p.passout FROM Qualification p")
	List<Integer> findDistinctpassout();
}
