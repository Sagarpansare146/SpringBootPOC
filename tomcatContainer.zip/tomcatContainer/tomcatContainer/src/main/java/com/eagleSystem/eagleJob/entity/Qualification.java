package com.eagleSystem.eagleJob.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="QUALIFICATION")
public class Qualification implements Serializable {
	
	@Id
	@Column(name = "CANDIDATE_ID")
	@GeneratedValue(generator = "foreign_gen")
	@GenericGenerator(name="foreign_gen", strategy = "foreign", parameters=
	@Parameter(name="property", value="candidate"))
	private Long qid;

	@Column(name="DEGREE")
	private String degree;
	
	@Column(name="SPECILIZATION")
	private String specilization;
	
	@Column(name="UNIVERSITY")
	private String university;
	
	@Column(name="PERCENTAGE")
	private Float percentage;
	
	@Column(name="PASSOUT")
	private Integer passout;
	
	@Column(name="EXPERIENCE")
	private int experience;
	
	@Column(name = "EXP_MONTH")
	private int month;
		
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Candidate candidate;
	
	public Qualification() {
	}

	public Long getQid() {
		return qid;
	}

	public void setQid(Long qid) {
		this.qid = qid;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getSpecilization() {
		return specilization;
	}

	public void setSpecilization(String specilization) {
		this.specilization = specilization;
	}

	
	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}
	
	public Float getPercentage() {
		return percentage;
	}

	public void setPercentage(Float percentage) {
		this.percentage = percentage;
	}

	
	public Integer getPassout() {
		return passout;
	}

	public void setPassout(Integer passout) {
		this.passout = passout;
	}

	
	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	
	public Candidate getCandidate() {
		return candidate;
	}

	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}
	
	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	@Override
	public String toString() {
		return "Qualification [qid=" + qid + ", degree=" + degree + ", specilization=" + specilization + ", university="
				+ university + ", percentage=" + percentage + ", passout=" + passout + ", experience=" + experience
				+ ", month=" + month + ", candidate=" + candidate + "]";
	}

	

}
