package com.eagleSystem.eagleJob.businessExcel;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eagleSystem.eagleJob.dao.ClientNaukriRepository;;
@CrossOrigin
@RestController
public class ClientNaukriExcelDownload {

	@Autowired
	ClientNaukriRepository clientNaukriRepository;

	@Cacheable("clientNaukriprefLocation")
	@RequestMapping(value = "/getclientNaukriPrefLocation")
	public Set<String> getLocations() {
		
		List<String> PrefLocations = clientNaukriRepository.findDistinctCity();
		Set<String> locations = new HashSet<>();
		PrefLocations.parallelStream().forEach(loc -> locations.addAll(Arrays.asList(loc.split(","))));
		locations.forEach(e -> e.trim());
		return locations;
		

	}
	
	@Cacheable("clientNaukricurrentLocation")
	@RequestMapping(value = "/getclientNaukricurrentLocation")
	public Set<String> getcurrentLocations() {
		
		List<String> CurrentLocation = clientNaukriRepository.findDistinctCurrentLocation();
		Set<String> currentLocation = new HashSet<>();
		CurrentLocation.parallelStream().forEach(loc -> currentLocation.addAll(Arrays.asList(loc.split(","))));
		currentLocation.forEach(e -> e.trim());
		return currentLocation;
		
	}
	
	@Cacheable("clientNaukrijobCategory")
	@RequestMapping(value = "/getclientNaukriJobCategory")
	public Set<String> getJobCategory() {
		
		List<String> jobC = clientNaukriRepository.findDistinctJobCategory();
		Set<String> jobCategory = new HashSet<>();
		jobC.parallelStream().forEach(jc -> jobCategory.addAll(Arrays.asList(jc.split(","))));
		jobCategory.forEach(e -> e.trim());
		return jobCategory;

	}
	
	@Cacheable("clientNaukrijobKeySkill")
	@RequestMapping(value = "/getclientNaukriKeySkill")
	public Set<String> getKeySkill() {
		
		List<String> keySkill = clientNaukriRepository.findDistinctKeySkills();
		Set<String> skills = new HashSet<>();
		keySkill.parallelStream().forEach(ks -> skills.addAll(Arrays.asList(ks.split(","))));
		skills.forEach(e -> e.trim());
		return skills;

	}
	
	@Cacheable("clientNaukrijobUgCourse")
	@RequestMapping(value = "/getclientNaukriJobUgCourse")
	public Set<String> getQualification() {
		
		List<String> ugCourse = clientNaukriRepository.findDistinctUgCourse();
		Set<String> ugC = new HashSet<>();
		ugCourse.parallelStream().forEach(uc -> ugC.addAll(Arrays.asList(uc.split(","))));
		ugC.forEach(e -> e.trim());
		return ugC;

	}
	
	@Cacheable("clientNaukriannualSalary")
	@RequestMapping(value = "/getclientNaukriannualSalary")
	public Set<String> getannualSalary() {
		
		List<String> annualSalary = clientNaukriRepository.findDistinctannualSalary();
		Set<String> annualsalary = new HashSet<>();
		annualSalary.parallelStream().forEach(uc -> annualsalary.addAll(Arrays.asList(uc.split(","))));
		annualsalary.forEach(e -> e.trim());
		return annualsalary;

	}

}
