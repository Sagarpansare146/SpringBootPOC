package com.eagleSystem.eagleJob.service;

public interface EmailNotify {

}
