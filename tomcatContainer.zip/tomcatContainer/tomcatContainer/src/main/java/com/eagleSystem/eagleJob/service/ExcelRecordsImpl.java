package com.eagleSystem.eagleJob.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.eagleSystem.eagleJob.valueObject.EmailNotifyInputs;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

@Service
public class ExcelRecordsImpl {

	public List<String> excel(HttpServletRequest request, HttpServletResponse response, EmailNotifyInputs inputs)
			throws Exception {

		String filePath = "";
		List<String> ids = null;

		filePath = fileReader(request, response, inputs);

		File file = new File(filePath);

		String inputFilename = file.getName();

		switch (inputFilename.substring(inputFilename.lastIndexOf(".") + 1, inputFilename.length())) {
		case "xls":
			ids = abc(file);
			break;
		case "xlsx":
			ids = xlsxReader(file);
			break;
		default:
			System.out.println("Please select valid \"Excel\" File\"");
		}

		return ids;
	}

	public String fileReader(HttpServletRequest request, HttpServletResponse response, EmailNotifyInputs inputs) {

		String fName = "";
		String FileName = inputs.getFile().getOriginalFilename();
		String FullPath = "c:/test" + File.separator + "file";

		System.out.println(FileName);

		try {
			File dir = new File(FullPath);

			if (!dir.exists()) {
				dir.mkdirs();
			}

			String extn = FilenameUtils.getExtension(FileName);

			File serveFile = new File(FullPath + File.separator + FileName);
			fName = serveFile.getAbsolutePath();
			BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serveFile));
			// String ResumePath = "Resume" + File.separator +
			// userRegistrationRequest.getContactNumber();
			stream.write(inputs.getFile().getBytes());
			stream.flush();
			stream.close();
		} catch (IOException io) {
			io.printStackTrace();
		}

		return fName;
	}

	/*
	 * public void getHeadingFromXlsFile(Sheet sheet) {
	 * 
	 * int columnCount = sheet.getColumns();
	 * 
	 * for (int i = 0; i < columnCount; i++) { System.out.println(sheet.getCell(i,
	 * 0).getContents()); } }
	 */

	public List<String> xlsReader(File fileInput) throws Exception {
		// File inputWorkbook = new File(inputFile);
		List<String> ids = new ArrayList<String>();
		try {
			FileInputStream file = new FileInputStream(fileInput);

			// HSSFWorkbook workbook = new HSSFWorkbook(file);

			HSSFWorkbook workbook = new HSSFWorkbook(file);

			// Get first sheet from the workbook
			HSSFSheet sheet = workbook.getSheetAt(0);

			// Get iterator to all the rows in current sheet
			Iterator<Row> rowIterator = sheet.iterator();

			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();

				// For each row, iterate through each columns
				Iterator<Cell> cellIterator = row.cellIterator();

				for (int i = 0; i <= 5; i++) {
					cellIterator.hasNext();
				}

				while (cellIterator.hasNext()) {

					Cell cell = cellIterator.next();

					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_BOOLEAN:
						break;
					case Cell.CELL_TYPE_NUMERIC:
						break;
					case Cell.CELL_TYPE_STRING:
						if (cell.getStringCellValue().contains("@") && cell.getStringCellValue().contains(".com"))
							ids.add(cell.getStringCellValue());

						break;
					}
				}
			}
			file.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return ids;

	}

	public List<String> xlsxReader(File fileInput) throws Exception {
		// File inputWorkbook = new File(inputFile);
		List<String> ids = new ArrayList<String>();
		try {
			FileInputStream file = new FileInputStream(fileInput);

			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// Get iterator to all the rows in current sheet
			Iterator<Row> rowIterator = sheet.iterator();

			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();

				// For each row, iterate through each columns
				Iterator<Cell> cellIterator = row.cellIterator();

				for (int i = 0; i <= 5; i++) {
					cellIterator.hasNext();
				}

				while (cellIterator.hasNext()) {

					Cell cell = cellIterator.next();

					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_BOOLEAN:
						break;
					case Cell.CELL_TYPE_NUMERIC:
						break;
					case Cell.CELL_TYPE_STRING:
						if (cell.getStringCellValue().contains("@"))
							ids.add(cell.getStringCellValue());

						break;
					}
				}
			}
			file.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return ids;
	}

	public List<String> abc(File fileInput) {

		List<String> ids = new ArrayList<>();

		// 1. Create an Excel file

		Workbook workbook = null;
		try {

			workbook = Workbook.getWorkbook(fileInput);

			Sheet sheet = workbook.getSheet(0);

			for (int i = 5; i < sheet.getRows(); i++) {

				jxl.Cell[] c = sheet.getRow(i);

				for (int j = 0; j < c.length; j++) {

					if (c[j].getContents().contains("@")) {
						ids.add(c[j].getContents());
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		} finally {

			if (workbook != null) {
				workbook.close();
			}

		}
		return ids;

	}

}
