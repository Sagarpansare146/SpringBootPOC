package com.eagleSystem.eagleJob.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.LoginSuccessHandler;
import com.eagleSystem.eagleJob.service.JobService;
import com.eagleSystem.eagleJob.util.OTPgenerateUtil;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;

@Controller
public class WelcomeController {

	@Autowired
	LoginSuccessHandler sucessHandler;

	@Autowired
	OTPgenerateUtil otpGenenrateUtil;

	@Value("${application.message:Hello World}")
	private String message = "Hello World";
	private JobService jobService;

	@RequestMapping(URLMapper.LOGIN)
	public String login(Authentication authentication) {

		System.out.println("login");

		return "other/login";
	}

	public String loadadmin(Authentication authentication) {
		return ViewMapper.ADMIN_LOGIN;
	}
	
	
	@RequestMapping("/AdminLogin")
	public String AdminLogin() {
		return ViewMapper.ADMIN_LOGIN;
	}

	/*@GetMapping(URLMapper.CONTACT_US)
	public String loadContactUs(Authentication authentication) {
		return ViewMapper.CONTACT_US;
	}*/

	@GetMapping(URLMapper.CANDIDATE_LOGIN)
	public String candidatelogin(Authentication authentication) {

		if (authentication != null) {
			String url = sucessHandler.determineTargetUrl(authentication);
			System.out.println(authentication.getAuthorities());
			return "redirect:" + url;
		} else {
			return ViewMapper.CANDIDATE_LOGIN;
		}

	}

	@GetMapping(URLMapper.RECRUITER_LOGIN)
	public String recruiterlogin(Authentication authentication) {

		if (authentication != null) {
			String url = sucessHandler.determineTargetUrl(authentication);
			return "redirect:" + url;
		} else {
			return ViewMapper.RECRUITER_LOGIN;
		}
	}

	@GetMapping(URLMapper.HOME)
	public String loadHome() {
		return ViewMapper.HOME;
	}

	@PostMapping(value = URLMapper.HOME, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody Map<String, Object> jhome(@RequestParam(required = false, defaultValue = "") String input,
			@RequestParam(required = false, defaultValue = "1") String page,
			@RequestParam(required = false, defaultValue = "10") String pageSize,
			@RequestParam(required = false, defaultValue = "") String location) {

		Map<String, Object> map = new HashMap<>();

		map = search(input, location, page, pageSize);

		System.out.println(map.get("jobs"));

		return map;
	}

	@GetMapping(value = "/search")
	public String Home(@RequestParam(required = false, defaultValue = "") String input,
			@RequestParam(required = false, defaultValue = "1") String page,
			@RequestParam(required = false, defaultValue = "10") String pageSize,
			@RequestParam(required = false, defaultValue = "") String location, Model model) {

		Map<String, Object> map = new HashMap<>();

		boolean flag = false;
		try {
			map = search(input, location, page, pageSize);
		} catch (Throwable t) {
			t.printStackTrace();
			flag = true;
		}

		if (flag) {

			return "other/error";

		}

		model.addAttribute("beginIndex", map.get("begin"));
		model.addAttribute("endIndex", map.get("end"));
		model.addAttribute("currentIndex", map.get("current"));
		model.addAttribute("totalPages", map.get("totalPages"));
		model.addAttribute("request", map.get("jobs"));
		model.addAttribute("input", input);
		model.addAttribute("location", location);

		return "other/find_job";
	}

	@GetMapping(URLMapper.TERMS_AND_CONDITION)
	public String tnc() {
		return ViewMapper.TERMS_AND_CONDITION;
	}

	@GetMapping(value = URLMapper.VERIFT_EMAIL, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jVerifyEmail(@RequestParam("otp") String otp) throws Exception {
		return otpGenenrateUtil.verifyOTP(otp);
	}

	@GetMapping(value = URLMapper.VERIFT_EMAIL)
	public @ResponseBody boolean verifyEmail(@RequestParam("otp") String otp, Model model) {
		boolean flag = true;
		try {
			flag = otpGenenrateUtil.verifyOTP(otp);
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			e.printStackTrace();
			flag = false;
		}

		return flag;
	}

	@GetMapping(value = URLMapper.SEND_OTP, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jSendOTP(@RequestParam("email") String email) throws Exception {

		return otpGenenrateUtil.getOTP(email);
	}

	@GetMapping(value = URLMapper.SEND_OTP)
	public @ResponseBody boolean sendOTP(@RequestParam("email") String email, Model model) {

		boolean flag = true;
		try {
			flag = otpGenenrateUtil.getOTP(email);
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			e.printStackTrace();
			flag = false;
		}

		return flag;
	}

	public Map<String, Object> search(String input, String location, String page, String pageSize) {

		Map<String, Object> map = new HashMap<>();

		if ((input.equalsIgnoreCase("") && location.equalsIgnoreCase("Select City"))) {
			map = jobService.allJobs(Integer.parseInt(page), Integer.parseInt(pageSize));
		} else if (((input.equalsIgnoreCase("")) && (!(location.equalsIgnoreCase(""))))) {
			map = jobService.getJobByCity(location, Integer.parseInt(page), Integer.parseInt(pageSize));
		} else {
			map = jobService.searchedJob(input, location, input, input, Integer.parseInt(page),
					Integer.parseInt(pageSize));
		}

		return map;

	}

	public String getUrl() {

		String url = "";

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		if (auth == null) {
			return "login";
		}

		switch (auth.getAuthorities().toString()) {
		case "admin":
			url = "";
			break;

		case "candidate":
			url = "";
			break;
		case "recruiter":
			url = "";
			break;
		case "bdm":
			url = "";
			break;

		case "subAdmin":
			url = "";
			break;
		default:
			break;
		}

		return url;
	}

	@GetMapping(URLMapper.FORGOT_PAGE)
	public String forgotPage() {
		return ViewMapper.FORGOT_PAGE;
	}

	/*
	 * @RequestMapping(value = "/view_jobs.htm") public String
	 * viewJobs(@ModelAttribute List<ListJobRequest> jobs,Map<String, Object> model,
	 * Authentication auth) {
	 * 
	 * jobs = jobService.allJobs(); System.out.println(jobs.toString());
	 * for(ListJobRequest j : jobs) { System.out.println(j.toString()); }
	 * 
	 * model.put("jobs", jobs); System.out.println(model.toString());
	 * 
	 * return "find_job"; }
	 * 
	 */

	public JobService getJobService() {
		return jobService;
	}

	@Autowired
	public void setJobService(JobService jobService) {
		this.jobService = jobService;
	}

}
