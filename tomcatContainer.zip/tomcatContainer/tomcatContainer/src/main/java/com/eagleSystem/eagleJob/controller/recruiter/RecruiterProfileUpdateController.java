package com.eagleSystem.eagleJob.controller.recruiter;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;

@Controller
public class RecruiterProfileUpdateController {

	@Autowired
	RecruiterService recruiterService;
	
	@GetMapping(value = "/companyProfile", produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody RecruiterRegistrationRequest jUpdateProfilePage(Model model, @ModelAttribute RecruiterRegistrationRequest registrationRequest, Authentication auth) {
		
	//	String username = "pravin@gmail.com";
		
		RecruiterRegistrationRequest request = recruiterService.getRecruiterData(auth.getName());
		
		return request;
		
	}
	
	@GetMapping(value = "/companyProfile")
	public String updateProfilePage(Model model, @ModelAttribute RecruiterRegistrationRequest registrationRequest, Authentication auth) {
		
		RecruiterRegistrationRequest request = null;
				
		try {
			request = jUpdateProfilePage(model, registrationRequest, auth);
		
		}catch(Throwable th) {
			th.printStackTrace();
			model.addAttribute("error", "Unable to get Profile");
		}
		
		model.addAttribute("request", request);
		return ViewMapper.RECRUITER_COMPANY_PROFILE;
		
	}
	
	@PostMapping(value = "/recruiterProfile", produces = { "application/json"} )
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jUpdateProfile(Model model, @RequestBody @ModelAttribute("request") @Valid RecruiterRegistrationRequest registrationRequest, Authentication auth) {

		boolean flag = false;
		
		flag = recruiterService.updateRecruiterProfile(registrationRequest);
		
		return flag;
		
	}
	
	@PostMapping(value = "/companyProfile")
	public String updateProfile(Model model, @ModelAttribute("request") @Valid RecruiterRegistrationRequest registrationRequest, Authentication auth) {

		boolean flag = false;
		
		try {
			flag = jUpdateProfile(model, registrationRequest, auth);
		
		}catch(Throwable th) {
			th.printStackTrace();
			model.addAttribute("error", "Unable to get Profile");
		}
		
		
		if (flag) 
		return ViewMapper.RECRUITER_POSTED_JOBS;

		model.addAttribute("message", "success");
		
		return "error";
		
	}
	
	
}
