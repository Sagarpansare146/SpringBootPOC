package com.eagleSystem.eagleJob.aspect;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.mail.internet.InternetAddress;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.bussinessObject.Email;
import com.eagleSystem.eagleJob.dao.CandidatePrefRepository;
import com.eagleSystem.eagleJob.dao.CandidateRepository;
import com.eagleSystem.eagleJob.dao.JobRepository;
import com.eagleSystem.eagleJob.dao.OldExcelRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.BoosterPlan;
import com.eagleSystem.eagleJob.entity.JobPost;
import com.eagleSystem.eagleJob.entity.MasterPlan;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.service.EmailService;
import com.eagleSystem.eagleJob.util.EmailTemplate;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.valueObject.JobPostRequest;

@Aspect
@Component
public class JobPostAspect extends AbstractAppPointcut {

	@Autowired
	RecruiterRepository recruiterRepository;

	@Autowired
	JobRepository jobRepository;

	@Autowired
	EmailService emailService;

	@Autowired
	CandidateRepository candidateRepository;

	@Autowired
	CandidatePrefRepository candidatePrefRepository;

	@Autowired
	OldExcelRepository oldExcelRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(JobPostAspect.class);

	
	@Around(value = "JobPostPointcut()")
	public Object jobPostAspect(ProceedingJoinPoint pjp) throws Throwable {

		Set<String> emailIds = new HashSet<>();
	//	Set<String> emailIds1 = new HashSet<>();

		System.out.println("hiiii");

		Object args[] = pjp.getArgs();

		JobPostRequest request = (JobPostRequest) args[1];

		String username = (String) args[0];

		Recruiter recruiter = recruiterRepository.findByUsername(username);
		Long count = (long) recruiter.getPostedJobs().size();

		boolean check = limitCheck(recruiter, count);

		if (!check) {
			return check;
		}

		boolean flag = (boolean) pjp.proceed();

		List<JobPost> jp = jobRepository.findByRecruiterIdOrderByPostedOnDesc(recruiter.getId());

		
		
		//		emailIds1 = getIdsFromExcel(request.getJobCategory(), request.getCity());

	/*	if (emailIds1 != null && !(emailIds1.isEmpty()))
			emailIds.addAll(emailIds1);
*/
		try {
			emailIds = getIdsFromDb(request.getJobCategory(), request.getCity());
			emailSender(request, emailIds, jp.get(0).getId());
		} catch (Exception e) {
			LOGGER.error("error while job post", e);
			e.printStackTrace();
			flag = false;
		}

		return flag;
	}

	public Set<String> getIdsFromDb(String jCategory, String jLocation) {

		Set<String> emailIds = new HashSet<>();

		String[] jobCategory = (jCategory).split(",");
		String location = jLocation;
		List<Long> cp = null;

		if (jobCategory.length <= 1) {
			cp = candidatePrefRepository.findIdByJobCategory(jobCategory[0], location);
		} else {
			cp = candidatePrefRepository.findIdByJobCategory(jobCategory[0], location);
		}
		
		for (Long bi : cp) {

			emailIds.add((candidateRepository.findOne(bi)).getEmail());
		}

		return emailIds;
	}

/*	public Set<String> getIdsFromExcel(String jobCategory, String location) {

		Set<String> emailIds = new HashSet<>();

		List<OldExcel> records = oldExcelRepository.findByJobCatagoryAndLocation(jobCategory, location);

		if(!records.isEmpty()) {
		for (OldExcel obj : records) {
			emailIds.add(obj.getEmailId());
		}
		}
		return emailIds;
	}*/

	@Async
	public void emailSender(JobPostRequest request, Set<String> emailIds, Long jobId) {

		int count = 0;
		int error = 0;
		InternetAddress ia = new InternetAddress();
		ia.setAddress(URLMapper.EMAIL_FROM);

		// String to = request.getCompanyEmail();
		String subject = request.getJobProfile();

		EmailTemplate template = new EmailTemplate("email-templates/JobPost.txt");
		// template.setTemplate(JobPostEmailMessage.MSG);

		String walkinStartDate = "Not Mentioned";
		String walkinEndDate = "Not Mentioned";
		try {
		if (request != null) {
			walkinStartDate = new SimpleDateFormat("dd/MM/yyyy").format(request.getWalkinStartDate());
			walkinEndDate = new SimpleDateFormat("dd/MM/yyyy").format(request.getWalkinEndDate());
		}
		
		}catch (Exception e) {
			System.out.println("walkin date prob");
		}
		Map<String, String> replacements = new HashMap<String, String>();
		replacements.put("${request.keySkill}", request.getKeySkill());
		replacements.put("${request.jobProfile}", request.getJobProfile());
		replacements.put("${request.jobCategory}", request.getJobCategory());
		replacements.put("${request.companyAddress}", request.getCompanyAddress());
		replacements.put("${request.experienceFrom}", String.valueOf(request.getExperienceFrom()));
		replacements.put("${request.experienceTo}", String.valueOf(request.getExperienceTo()));
		replacements.put("apkLink", "https://play.google.com/store/apps/details?id=naukrijobs.eaglesystem.naukrijobs");
		replacements.put("${request.jobType}", request.getJobType());
		replacements.put("${request.companyName}", request.getCompanyName());
		replacements.put("${request.companyWebsite}", request.getCompanyWebsite());
		replacements.put("${request.contactPerson}", request.getContactPerson());
		replacements.put("${request.contactNumber}", String.valueOf(request.getContactNumber()));
		replacements.put("${request.jobDetail}", request.getJobDetail());
		replacements.put("${request.walkinStartDate}", walkinStartDate);
		replacements.put("${request.walkinEndDate}", walkinEndDate);
		replacements.put("${request.postedOn}", new SimpleDateFormat("dd/MM/yyyy").format(new Date()));

		replacements.put("${pageContext.request.contextPath}/candidateApplyJobs?jobId=${request.postId}",
				"http://naukrijob.co.in/jobDetail?jobId=" + jobId);

		String message = template.getHtmlTemplate(replacements);

		Email email1 = new Email();
		email1.setHtml(true);

		int i = 0;

		for (String emailId : emailIds) {
			List<String> toList = new ArrayList<>();
			toList.add(emailId);
			try {
				email1.setTo(toList);
				email1.setSubject(subject);
				email1.setMessage(message);
				email1.setSenderName(request.getCompanyName());

				switch (i) {
				case 0:
					email1.setFrom(ia);

					i = i + 1;
					break;
				case 1:
					ia.setAddress("naukrijob.alert@naukrijob.co.in");
					email1.setFrom(ia);
					i = i + 1;
					break;
				case 2:

					ia.setAddress("naukrijob.updates@naukrijob.co.in");
					email1.setFrom(ia);
					i = i + 1;
					break;
				case 3:

					ia.setAddress("walkin.alert@naukrijob.co.in");
					email1.setFrom(ia);
					i = i + 1;
					break;
				case 4:

					ia.setAddress("job.alert@naukrijob.co.in");
					email1.setFrom(ia);
					i = 0;
					break;

				default:
					break;
				}
				count = count +1;
				emailService.send(email1);
				
				
			} catch (Exception e) {
				error = error+1;
				e.printStackTrace();
			}
			
			
		}
		
		if(emailIds != null)
		LOGGER.info("Total email Ids :"+emailIds.size());
		
		LOGGER.info("Total email sent :"+ count);
		LOGGER.error("Error while email sent :"+ error);

		System.out.println("Total email sent :"+count);
		System.out.println("Error while email sent :"+error);
	}

	public boolean limitCheck(Recruiter rec, long count) throws Exception {

		boolean flag = true;

		BoosterPlan bp = rec.getBoosterPlan();
		MasterPlan mp = rec.getMasterPlan();

		int fixedLimit = 0;

		if (bp != null)
			fixedLimit = mp.getJobPostLimit() + bp.getJobPostLimit();

		fixedLimit = mp.getJobPostLimit();

		if (count >= fixedLimit) {
			flag = false;
			throw new Exception("Aleady passed limit of posting job");
		}

		return flag;
	}

}
