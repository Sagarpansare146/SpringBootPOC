package com.eagleSystem.eagleJob.service;

public interface UpdateResumeService {

	public boolean updateResume(String ResumePath);
}
