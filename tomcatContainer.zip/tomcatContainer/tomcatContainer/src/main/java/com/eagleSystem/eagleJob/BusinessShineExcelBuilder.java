package com.eagleSystem.eagleJob;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import com.eagleSystem.eagleJob.entity.ShineExcelRecord;
@Component
public class BusinessShineExcelBuilder extends AbstractXlsView  {

	@Override
	protected void buildExcelDocument(Map model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String name = (String) model.get("industry");

		// change the file name
		response.setHeader("Content-Disposition", "attachment; filename=\""+ "ShineExcel"+ "_"+ name + ".xls\"");

		@SuppressWarnings("unchecked")
		List<ShineExcelRecord> records = (List<ShineExcelRecord>) model.get("records");

		// create excel xls sheet
		Sheet sheet = workbook.createSheet("Job Post Response");

		// create header row
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("Sr. no.");
		header.createCell(1).setCellValue("CandidateName");
		header.createCell(2).setCellValue("CandidateDob");
		header.createCell(3).setCellValue("EmailID");
		header.createCell(4).setCellValue("ContactNumber");
		header.createCell(5).setCellValue("CurrentLocation");
		header.createCell(6).setCellValue("Gender");
		header.createCell(7).setCellValue("TotalWorkExperience");
		header.createCell(8).setCellValue("CurrentAnnualSalary");
		header.createCell(9).setCellValue("CurrentJobTitle");
		header.createCell(10).setCellValue("CurrentFunctionalArea");
		header.createCell(11).setCellValue("CurentIndustry");
		header.createCell(12).setCellValue("CurrentCompany");	
		header.createCell(13).setCellValue("YearsinCurrentJob");
		header.createCell(14).setCellValue("NoticePeriod");
		header.createCell(15).setCellValue("HighestEducationLevel");
		header.createCell(16).setCellValue("HighestEducationStream");
		header.createCell(17).setCellValue("HighestEducationInstitute");
			header.createCell(18).setCellValue("YearOfPassing");
		header.createCell(19).setCellValue("JobCategory");
		
		int rowCount = 0;                             
		for (ShineExcelRecord course : records) {               
			Row courseRow = sheet.createRow(++rowCount);
			System.out.println(rowCount);
			courseRow.createCell(0).setCellValue(rowCount);
			courseRow.createCell(1).setCellValue(course.getCandidateName());
			courseRow.createCell(2).setCellValue(course.getDob());
			courseRow.createCell(3).setCellValue(course.getEmailID());
			courseRow.createCell(4).setCellValue(course.getContactNumber());
			courseRow.createCell(5).setCellValue(course.getCurrentLocation());
			courseRow.createCell(6).setCellValue(course.getGender());
			courseRow.createCell(7).setCellValue(course.getTotalWorkExperience());
			courseRow.createCell(8).setCellValue(course.getCurrentAnnualSalary());
			courseRow.createCell(9).setCellValue(course.getCurrentJobTitle());
			courseRow.createCell(10).setCellValue(course.getCurrentFunctionalArea());
			courseRow.createCell(11).setCellValue(course.getCurrentIndustry());
			courseRow.createCell(12).setCellValue(course.getCurrentCompany());
			courseRow.createCell(13).setCellValue(course.getYearsinCurrentJob());
			courseRow.createCell(14).setCellValue(course.getNoticePeriod());
			courseRow.createCell(15).setCellValue(course.getHighestEducationLevel());
			courseRow.createCell(16).setCellValue(course.getHighestEducationStream());
			courseRow.createCell(17).setCellValue(course.getHighestEducationInstitute());
			courseRow.createCell(18).setCellValue(course.getYearOfPassing());
			courseRow.createCell(19).setCellValue(course.getJobCategory());
			
		}

	}
	
}
