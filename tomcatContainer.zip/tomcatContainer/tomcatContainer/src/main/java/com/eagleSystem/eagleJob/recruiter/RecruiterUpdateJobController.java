package com.eagleSystem.eagleJob.recruiter;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.bussinessObject.JobBO;
import com.eagleSystem.eagleJob.bussinessObject.RecruiterBO;
import com.eagleSystem.eagleJob.service.JobService;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.util.JobBOPrepareUtil;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.JobPostRequest;

@Controller
public class RecruiterUpdateJobController {

	static final String UPDATE_JOB_MODEL = "request";

	@Autowired
	JobService jobService;

	@Autowired
	RecruiterService recruiterService;

	@Autowired
	JobBOPrepareUtil jobBOPrepareUtil;
	
	
	@GetMapping(URLMapper.RECRUITER_JOB_UPDATE)
	public String loadUpdateJobPage(Model model, @RequestParam(value = "postId") String jobId, Authentication auth) {
		
		
		JobBO job = null;
		
		try {
			job = jobService.getJobBOById(Long.parseLong(jobId));
		}catch(Throwable th) {
			th.printStackTrace();
			model.addAttribute("error", "Unable to get Job Profile");
		}

		JobPostRequest request = prepareJobRequest(job);
		model.addAttribute(UPDATE_JOB_MODEL, request);
		
		return ViewMapper.RECRUITER_JOB_UPDATE;
	}

	@PostMapping(URLMapper.RECRUITER_JOB_UPDATE)
	public String postJob(@Valid @ModelAttribute(UPDATE_JOB_MODEL) JobPostRequest jobRequest, BindingResult result, Model model,HttpServletRequest request) {

		// validate the job entry
		if (result.hasErrors()) {
			// the errors will automatically get mapped to form:errors path = ""
			return ViewMapper.RECRUITER_JOB_UPDATE;
		}
		// Hardcoded right now. Change Later. based on login

		try {
			JobBO job = jobService.getJobBOById(jobRequest.getPostId());
			if (null == job) {
				return ViewMapper.RECRUITER_JOB_UPDATE;
			}
	//		String title =  ValidateScripting.validate(jobRequest.getTitle());
	//		String description = ValidateScripting.validate(job.getDescription());
	//		String location = ValidateScripting.validate(job.getLocation());
			
/*
			newJob.setTitle(title);
			newJob.setDescription(description);
			newJob.setExperience(job.getExperience());
			newJob.setLocation(location);
			String type = request.getParameter("jobType");
			// System.out.println(type);
			newJob.setType(type);
*/
			job.setUpdatedOn(new Date());

			// updating job
			jobService.updateJob(job);
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("error", "Unable to Update Job Profile");
			return "error";
		}

		model.addAttribute("message", "Success");
		return "redirect:" + URLMapper.RECRUITER_POSTED_JOBS;
	}

	@GetMapping(value = URLMapper.RECRUITER_DELETE_JOB_URL, produces = {"application/json"})
	@ResponseStatus(value = HttpStatus.OK)
	public boolean jDeleteJobPage(Model model, @RequestParam(value = "jobId") Long jobId, Authentication auth) {
		
		boolean flag = false;
		/*	JobBO job = jobService.getJobBOById(Long.parseLong(jobId));
		System.out.println(job.getStatus());
		job.setUpdatedOn(new Date());
		job.setStatus("Deactive");
		job.setDeleted(true);
		flag = jobService.updateJob(job);
		return flag;*/
		
		RecruiterBO recruiterBO = recruiterService.getRecruiterByUsername(auth.getName());
		
		flag = jobService.deletePostedJob(jobId, recruiterBO.getId());
		
		return flag;
		
	}
	
	@GetMapping(URLMapper.RECRUITER_DELETE_JOB_URL)
	public String deleteJobPage(Model model, @RequestParam(value = "jobId") Long jobId, Authentication auth) {
		
		boolean flag = false;
		boolean error = false;
		
		try {
			flag = jDeleteJobPage(model, jobId, auth);
		}catch(Throwable th) {
			th.printStackTrace();
			model.addAttribute("error", "error");
			error = true;
		}
		
		if(!flag)
			return "error";
		if(error)
			return "error";
		
		model.addAttribute("message", "success");
		
		return "redirect:" + URLMapper.RECRUITER_POSTED_JOBS;
	}

	public JobPostRequest prepareJobRequest(JobBO jobBO) {
		
	//	String keySkill = "";
		JobPostRequest request = new JobPostRequest();
		
		if(!(jobBO.getPostId() == null)) 
			request.setPostId(jobBO.getPostId());
			request.setCompanyName(jobBO.getCompanyName());
			request.setCompanyEmail(jobBO.getCompanyEmail());
//			request.setCompanyType(jobBO.getCompanyType());
			request.setCity(jobBO.getCity());
			request.setState(jobBO.getState());
			request.setCompanyWebsite(jobBO.getCompanyWebsite());
			request.setContactNumber(jobBO.getContactNumber());
			request.setCompanyAddress(jobBO.getCompanyAddress());
			request.setContactPerson(jobBO.getContactPerson());
			request.setJobCategory(jobBO.getJobCategory());
			request.setExperienceFrom(jobBO.getExperienceFrom());
			request.setExperienceTo(jobBO.getExperienceTo());
			request.setFunctionalArea(jobBO.getFunctionalArea());
			request.setJobDetail(jobBO.getJobDetail());
			request.setJobProfile(jobBO.getJobProfile());
			request.setJobType(jobBO.getJobType());		
			
		/*	for (String ks : jobBO.getKeySkill()) {
				keySkill = keySkill + ks;
			}*/
		
			request.setWalkinStartDate(jobBO.getWalkinStartDate());
			request.setWalkinEndDate(jobBO.getWalkinEndDate());
			request.setKeySkill(jobBO.getKeySkill());
			request.setSalary(jobBO.getSalary());
			
			return request;
	}
	
}
