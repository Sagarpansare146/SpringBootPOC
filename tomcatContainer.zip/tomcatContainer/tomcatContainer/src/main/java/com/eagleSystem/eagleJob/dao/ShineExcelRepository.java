package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.lang.String;

import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;
import com.eagleSystem.eagleJob.entity.ShineExcelRecord;

public interface ShineExcelRepository extends JpaRepository<ShineExcelRecord, Long> ,JpaSpecificationExecutor<ShineExcelRecord>{

	List<ShineExcelRecord> findByjobCategory(String jobCategory);
	List<ShineExcelRecord>findBycurrentLocation(String location);
	
	

	List<ShineExcelRecord> findByJobCategoryAndCurrentLocation(String JobCategory,String CurrentLocation);
	
	@Query("SELECT DISTINCT p.jobCategory FROM ShineExcelRecord p")
	List<String> findDistinctjobCategory();
	
	
	@Query("SELECT DISTINCT p.currentLocation FROM ShineExcelRecord p")
	List<String> findDistinctcurrentLocation();
	

}
