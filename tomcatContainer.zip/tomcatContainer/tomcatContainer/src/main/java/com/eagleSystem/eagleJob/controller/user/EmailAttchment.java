package com.eagleSystem.eagleJob.controller.user;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.eagleSystem.eagleJob.bussinessObject.EmailAttch;
import com.eagleSystem.eagleJob.service.ExcelRecordsImpl;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.EmailNotifyInputs;


@Controller
public class EmailAttchment {

	@Autowired
	ExcelRecordsImpl excelRecord;

	@Autowired
	private JavaMailSender mailSender;
	
	@RequestMapping("/userSendAttchEmail")
	public String emailNotify(HttpServletRequest request, HttpServletResponse response, EmailNotifyInputs inputs,
			Model model) throws IllegalStateException, IOException {

		System.out.println(inputs);
		List<String> ids = null;
		int count = 0;
		try {
			ids = excelRecord.excel(request, response, inputs);
		} catch (Exception e) {

			ids = new ArrayList<>();
			e.printStackTrace();
		}

		if (!(ids == null)) {
			count = ids.size();
			System.out.println("Total no of records : " + ids.size());
	//		inputs.getFile().transferTo(new File("C:/test/abc.jpg"));
			emailSender(ids, inputs.getSubject(), inputs.getSenderName(), inputs.getMessage(), inputs.getFrom(), inputs.getAttchFile());

		} else {
			System.out.println("Total no of records : " + count);

		}

		model.addAttribute("request", ids);
		model.addAttribute("count", count);
		return ViewMapper.USER_USER_SENDMAILATTCH;
	}

	@Async
	public void emailSender(List<String> emailIds, String subject, String senderName, String message, String from, MultipartFile file) {

		System.out.println(emailIds);
		InternetAddress ia = new InternetAddress();
		ia.setAddress(from);

		EmailAttch email1 = new EmailAttch();

		int success = 0;
		int failed = 0;

		for (String emailId : emailIds) {
			List<String> toList = new ArrayList<>();
			toList.add(emailId);
			try {
				email1.setTo(toList);
				email1.setSubject(subject);
				email1.setMessage(message);
				email1.setFrom(ia);

				sendPlainTextMail(email1, senderName, from, file);
				success = success + 1;

			} catch (Exception e) {
				e.printStackTrace();
				failed = failed + 1;
			}
		}

		System.out.println("Total Email successfully send : " + success);
		System.out.println("Total Email failed : " + failed);

	}
	
	public void sendPlainTextMail(EmailAttch eParams, String senderName, String from, MultipartFile attachFile)
			throws MessagingException, UnsupportedEncodingException {

		// SimpleMailMessage mailMessage = new SimpleMailMessage();

		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper mailMessage = new MimeMessageHelper(message, true);

		eParams.getTo().toArray(new String[eParams.getTo().size()]);
		mailMessage.setTo(eParams.getTo().toArray(new String[eParams.getTo().size()]));
		// mailMessage.setReplyTo(String.valueOf(eParams.getFrom()));
		// helper.setFrom("Career@naukrijob.co.in", "NaukriJob");

		mailMessage.setFrom(from, senderName);
		mailMessage.setSubject(eParams.getSubject());
		mailMessage.setText(eParams.getMessage());

		if (eParams.getCc().size() > 0) {
			mailMessage.setCc(eParams.getCc().toArray(new String[eParams.getCc().size()]));
		}
		
		String attachName = attachFile.getOriginalFilename();
        if (!attachFile.equals("")) {

        	mailMessage.addAttachment(attachName, new InputStreamSource() {
                 
                @Override
                public InputStream getInputStream() throws IOException {
                    return attachFile.getInputStream();
                }
            });
        }
		
	//	FileSystemResource file = new FileSystemResource(new File(path));
	//	mailMessage.addAttachment(path, file);

	/*	Multipart multipart = new MimeMultipart();
		MimeBodyPart attachementPart = new MimeBodyPart();
		attachementPart.attachFile(new File("D:/cp/pic.jpg"));
		multipart.addBodyPart(attachementPart); */
		
		/*FileSystemResource file 
	      = new FileSystemResource(new File(path));
		mailMessage.addAttachment("NaukriJob", file);
	 */

		mailSender.send(message);

	}
	

}
