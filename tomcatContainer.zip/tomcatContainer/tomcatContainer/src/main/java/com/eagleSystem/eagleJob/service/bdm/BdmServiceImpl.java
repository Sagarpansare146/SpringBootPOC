package com.eagleSystem.eagleJob.service.bdm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.eagleSystem.eagleJob.dao.AccountRepository;
import com.eagleSystem.eagleJob.dao.CandidateApplicationRepository;
import com.eagleSystem.eagleJob.dao.CandidatePrefRepository;
import com.eagleSystem.eagleJob.dao.DBCustomerRepository;
import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;
import com.eagleSystem.eagleJob.dao.QualificationRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.CandidatePreference;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import com.eagleSystem.eagleJob.entity.JPUser;
import com.eagleSystem.eagleJob.entity.NaukriExcelRecord;
import com.eagleSystem.eagleJob.entity.Qualification;
import com.eagleSystem.eagleJob.service.CandidateService;
import com.eagleSystem.eagleJob.util.Role;
import com.eagleSystem.eagleJob.valueObject.CandidateRecords;
import com.eagleSystem.eagleJob.valueObject.NaukriExcelDisplay;

@Component
public class BdmServiceImpl {

	@Autowired
	CandidateApplicationRepository candidateApplicationRepository;

	@Autowired
	CandidatePrefRepository candidatePrefRepository;

	@Autowired
	QualificationRepository qualifactionRepository;
	
	@Autowired
	NaukriExcelRepository naukriExcelRepository;
	
	@Autowired
	CandidateService candidateService;
	
	@Autowired
	DBCustomerRepository dBCustomerRepository;
	
	@Autowired
	JPUserRepository jpUserRepository;

	@Autowired
	AccountRepository accountRepository;


	public static Specification<NaukriExcelRecord> filterNaukriSpecification(String location, int exp, String jobCategory, String gender,String currentlocation,String annualSalary) {
	    return new Specification<NaukriExcelRecord>() {
			
			@Override
			public javax.persistence.criteria.Predicate toPredicate(Root<NaukriExcelRecord> root,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				// TODO Auto-generated method stub
				
				List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();
				
				if(!location.equals("")) {
					predicates.add(cb.like(root.get("preferredLocations"), "%" +location+ "%" ));
				}
				
				if(!jobCategory.equals("")) {
					predicates.add(cb.like(root.get("jobCategory"), "%" +jobCategory+ "%" ));
				}
				
				if(exp != -1 && exp != 99) {
					predicates.add(cb.like(root.get("totalExperience"), "%" +exp+" Year"+ "%" ));
				}
				if(exp == 99) {
					System.out.println("fresher");
					predicates.add(cb.equal(root.get("totalExperience"), "Fresher"));
				}
				
				if(! gender.equals("")) {
					predicates.add(cb.equal(root.get("gender"), gender ));
				}
				if(!currentlocation.equals("")) {
					predicates.add(cb.equal(root.get("currentLocation"), currentlocation ));
				}
				if(!annualSalary.equals("")) {
					predicates.add(cb.like(root.get("annualSalary"), "%" +annualSalary+ "%" ));
				}
				System.out.println(predicates.toString());
				return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[0]));
			}
			
		};
	}
	
	public static Specification<CandidatePreference> filterNaukriJobSpecification(String location, String jobCategory, String gender) {
	    return new Specification<CandidatePreference>() {
			
			@Override
			public javax.persistence.criteria.Predicate toPredicate(Root<CandidatePreference> root,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				// TODO Auto-generated method stub
				
				List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();
				
				if(!location.equals("")) {
					predicates.add(cb.like(root.get("location"), "%" +location+ "%" ));
				}
				
				if(!jobCategory.equals("")) {
					predicates.add(cb.like(root.get("jobCategory"), "%" +jobCategory+ "%" ));
				}
				
				if(! gender.equals("")) {
					predicates.add(cb.equal(root.get("gender"), gender ));
				}
				
				return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[0]));
			}
			
		};
	}
	
	public static Specification<Qualification> filterNaukriJobSpecification1(int from, int to, String degree) {
	    return new Specification<Qualification>() {
			
			@Override
			public javax.persistence.criteria.Predicate toPredicate(Root<Qualification> root,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				// TODO Auto-generated method stub
				
				List<javax.persistence.criteria.Predicate> predicates = new ArrayList<>();
				
				if(from != -1 && to != -1) {
					predicates.add(cb.between(root.get("experience"), from, to));
				}
				
				if(!degree.equals("")) {
					predicates.add(cb.equal(root.get("degree"), degree));
				}
				
				return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[0]));
			}
			
		};
	}
	
	public Map<String, Object> filterNaukriJobRecords(int page, int pageSize, String location, int from, int to, String jobCategory,
			String degree, String gender) {

		Pageable request =
	            new PageRequest(page - 1, pageSize,Sort.Direction.DESC,"cid");
		
		Pageable request1 =
	            new PageRequest(page - 1, pageSize,Sort.Direction.DESC,"qid");
		
		Page<CandidatePreference> pCad = null;
		Page<Qualification> pQaul = null;
		
		List<CandidatePreference> lCad = new ArrayList<>();
		List<Qualification> lQaul = new ArrayList<>();

		/*Predicate pJobC = QCandidatePreference.candidatePreference.jobCategory.contains(jobCategory);
		Predicate pJcNLoc = QCandidatePreference.candidatePreference.jobCategory.contains(jobCategory)
				.and(QCandidatePreference.candidatePreference.location.contains(location));
		Predicate pLoc = (QCandidatePreference.candidatePreference.location.contains(location));

		Predicate pDeg = QQualification.qualification.degree.eq(degree);
		Predicate pDegNExp = QQualification.qualification.degree.eq(degree).and(
				QQualification.qualification.experience.goe(from).and(QQualification.qualification.experience.loe(to)));
		Predicate pExp = (QQualification.qualification.experience.goe(from)
				.and(QQualification.qualification.experience.loe(to)));

		int i = (!((location.equalsIgnoreCase("") || location == null)
				&& (jobCategory.equalsIgnoreCase("") || jobCategory == null))
						? jobCategory.equalsIgnoreCase("") || jobCategory == null ? 2 : 1
						: 0);
		int j = (!((degree.equalsIgnoreCase("") || degree == null) && (from == -1 || to == -1))
				? (from == -1 || to == -1) ? 2 : 1
				: 0);

		switch (i) {
		case 0:
			pCad = null;
			break;
		case 1:
			if(location.equals("")) {
				System.out.println("1");
			pCad =  candidatePrefRepository.findAll(pJobC, request);
			} else {
				System.out.println("2");
				pCad = candidatePrefRepository.findAll(pJcNLoc, request);
			}
			
			break;
		case 2:
			pCad = candidatePrefRepository.findAll(pLoc, request);
			break;

		default:
			pCad =  candidatePrefRepository.findAll(pJcNLoc, request);
			break;
		}

		switch (j) {
		case 0:
			pQaul = null;
			break;
		case 1:
			pQaul =  qualifactionRepository.findAll(pExp, request);
			break;
		case 2:
			pQaul =  qualifactionRepository.findAll(pDeg, request);
			break;

		default:
			pQaul =  qualifactionRepository.findAll(pDegNExp, request);
			break;
		}*/

		if((!location.equals("")) || (!jobCategory.equals(""))) {
		pCad = candidatePrefRepository.findAll(filterNaukriJobSpecification(location, jobCategory, gender), request);
		}
		if((from != -1 && to != -1 ) || (!degree.equals(""))) {
		pQaul = qualifactionRepository.findAll(filterNaukriJobSpecification1(from, to, degree), request1);
		}
		
		lCad = (pCad == null ? new ArrayList<>() : pCad.getContent());
		lQaul = (pQaul == null ? new ArrayList<>() : pQaul.getContent());
		
		Map<String, Object> map = new HashMap<>();
		
		Set<Long> jobIds = new HashSet<>();
		List<Long> finalIds = new ArrayList<>();

		if (pCad == null && pQaul == null) {
			System.out.println("a");
			finalIds = new ArrayList<>();
			map.put("totalCount" , 0);
			map.put("totalPages" , 0);
			
		} else if (pQaul == null) {
			System.out.println("b");
			jobIds = lCad.stream().map(cad -> cad.getCid()).collect(Collectors.toSet());
			finalIds.addAll(jobIds);
			map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
			map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
			

		} else if (pCad == null && pQaul != null) {
			System.out.println("c");
			finalIds = lQaul.stream().map(qual -> qual.getQid()).collect(Collectors.toList());
			map.put("totalCount" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalElements()));
			map.put("totalPages" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalPages()));
			
		} else {
			System.out.println("else");
			
			jobIds = lCad.stream().map(cad -> cad.getCid()).collect(Collectors.toSet());
			Set<Long> l = jobIds;
			Set<Long> jobIds1 = lQaul.stream().peek(e -> System.out.println(e)).map(qual -> qual.getQid()).collect(Collectors.toSet());
			if(jobIds1.size() != 0) {
			finalIds = jobIds1.stream().filter(li -> (l.contains(li))).collect(Collectors.toList());
			} else {
			finalIds.addAll(jobIds);
			}
			if(pCad == null) {
				map.put("totalCount" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalElements()));
				map.put("totalPages" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalPages()));
				
			} else if(pQaul == null) {
				map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
				map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
			}
			else {
			map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
			map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
			}
		}
		
		
	/*	System.out.println(pCad.hasContent());
		System.out.println(pCad);
		System.out.println(pQaul.hasContent());
		System.out.println(pQaul);
		*/
		
		/*
		if (pCad.hasContent() && pQaul.hasContent()) {
					System.out.println("else");
			
			jobIds = lCad.stream().map(cad -> cad.getCid()).collect(Collectors.toSet());
			Set<Long> l = jobIds;
			Set<Long> jobIds1 = lQaul.stream().peek(e -> System.out.println(e)).map(qual -> qual.getQid()).collect(Collectors.toSet());
			if(jobIds1.size() != 0) {
			finalIds = jobIds1.stream().filter(li -> (l.contains(li))).collect(Collectors.toList());
			} else {
			finalIds.addAll(jobIds);
			}
			if(pQaul.hasContent()) {
				map.put("totalCount" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalElements()));
				map.put("totalPages" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalPages()));
				
			} else if(pCad.hasContent()) {
				map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
				map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
			}
			else {
			map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
			map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
			}
			
		} else if (pCad.hasContent()) {
			System.out.println("b");
			jobIds = lCad.stream().map(cad -> cad.getCid()).collect(Collectors.toSet());
			finalIds.addAll(jobIds);
			map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
			map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
			

		} else if (!pCad.hasContent() && pQaul.hasContent()) {
			System.out.println("c");
			finalIds = lQaul.stream().map(qual -> qual.getQid()).collect(Collectors.toList());
			map.put("totalCount" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalElements()));
			map.put("totalPages" , (pQaul == null ? new ArrayList<>() : pQaul.getTotalPages()));
			
		} else {
			
			System.out.println("a");
			finalIds = new ArrayList<>();
			map.put("totalCount" , 0);
			map.put("totalPages" , 0);
			
		
		}*/
		
	//	finalIds = finalIds.stream().filter(li -> (appliedIds.contains(li))).collect(Collectors.toList());
		List<CandidateRecords> cadRec = candidateService.prepareRecordsObj(finalIds);
		
//		map.put("totalCount" , (pCad == null ? new ArrayList<>() : pCad.getTotalElements()));
//		map.put("totalPages" , (pCad == null ? new ArrayList<>() : pCad.getTotalPages()));
		Collections.reverse(cadRec);
		map.put("request" , cadRec);
		
		return map;

	}
	
	
	public Map<String, Object> filternaukriRecords(int page, int pageSize, String location, int exp, String jobCategory,
			String degree, String gender, String currentlocation, String annualSalary ) {

		Pageable request =
	            new PageRequest(page - 1, pageSize,Sort.Direction.DESC,"id");
		
		Set<NaukriExcelRecord> finalrec = new HashSet<>();
		
		Map<String, Object> map = new HashMap<>();
		
		Page<NaukriExcelRecord> pNauk = naukriExcelRepository.findAll(filterNaukriSpecification(location, exp, jobCategory, gender,currentlocation,annualSalary), request);
		
		if(pNauk != null)
		finalrec.addAll(pNauk.getContent());
		
		List<NaukriExcelDisplay> lNauk = ( finalrec != null ? finalrec.stream().map(e -> makeObject(e)).collect(Collectors.toList()) : new ArrayList<>());
		Collections.reverse(lNauk);
		map.put("request", lNauk);
		map.put("totalCount", (pNauk != null ? pNauk.getTotalElements() : 0));
		map.put("totalPages", (pNauk != null ? pNauk.getTotalPages() : 0));
		
		return map;

	}
	
	public NaukriExcelDisplay makeObject(NaukriExcelRecord record) {
		
		NaukriExcelDisplay canRec = new NaukriExcelDisplay();

		canRec.setId(record.getId());
		canRec.setName(record.getName());
		canRec.setLocation(record.getCurrentLocation());
		canRec.setQualification(record.getUgCourse());
		canRec.setTotalExpInYear(record.getTotalExperience());
		canRec.setJobCategory(record.getJobCategory());
		canRec.setKeySkill(record.getKeySkills());
		canRec.setAnnualSalary(record.getAnnualSalary());
		
		canRec.setPreferredLocations(record.getPreferredLocations());
		canRec.setGender(record.getGender());
		return canRec;
	}
	
	@Transactional
	public boolean dbCustomerReg(DbCustomerEntity customerEntity) throws Exception {

		boolean flag = true;

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		JPUser jpUser = new JPUser();

		if (jpUserRepository.findByUsernameIgnoreCase(customerEntity.getUsername()) != null) {
			throw new Exception("Aleardy Exist User");
		}
		
		if( authentication == null ) {
			throw new Exception("Invalid BDM");
		}
		
		try {
			jpUser.setUsername(customerEntity.getUsername());
			jpUser.setPassword(customerEntity.getPassword());
			jpUser.setEnabled(true);
			jpUser.setRole(Role.database.name());
		
			Account account = accountRepository.findByUsername(authentication.getName());
			
			customerEntity.setAccount(account);
			DbCustomerEntity dbCust = dBCustomerRepository.save(customerEntity);
			
			List<DbCustomerEntity> custList = account.getDbCustomer();
			custList.add(dbCust);
			account.setDbCustomer(custList);
			accountRepository.save(account);
	//		customerBDMRepository.save(new CustomerSubAdmin(dbCust.getId(), authentication.getName()));
			
			jpUserRepository.save(jpUser);

		} catch (Exception e) {
			e.printStackTrace();

			flag = false;
		}

		return flag;

	}
	
	
	public List<NaukriExcelRecord> commonDownloadBdmNaukriExcelRecord(Long cadId[]) {
		
		List<Long> cIds = Arrays.asList(cadId);
	
		List<NaukriExcelRecord> records = new ArrayList<>();

		
		records = cIds.stream().map(id -> naukriExcelRepository.findOne(id)).collect(Collectors.toList());
		
	//	System.out.println(records);
		
		return (records == null ? new ArrayList<>() : records);
		
	}
	
	


	public List<NaukriExcelRecord> commonDownloadBdmNaukriJobExcelRecord(Long cadId[]) {
		
		List<Long> cIds = Arrays.asList(cadId);
	
		List<NaukriExcelRecord> records = new ArrayList<>();

		
		records = cIds.stream().map(id -> naukriExcelRepository.findOne(id)).collect(Collectors.toList());
		
	//	System.out.println(records);
		
		return (records == null ? new ArrayList<>() : records);
		
	}
	
	public List<NaukriExcelRecord> downloadBdmNaukriExcelRecord(Long cadId[]) {
		return commonDownloadBdmNaukriExcelRecord(cadId);
	}
	
	public List<NaukriExcelRecord> downloadBdmNaukriJobExcelRecord(Long cadId[]) {
		return commonDownloadBdmNaukriJobExcelRecord(cadId);
		
	}
	
	public List<String> resumeNaukriPath(Long ids[]) {
		
		return commonResumeNaukriPath(ids);
		
	}

	public List<String> resumeNaukriJobPath(Long ids[]) {
		
		
		return commonResumeNaukriJobPath(ids);
		
	}
	
	public List<String> commonResumeNaukriPath(Long ids[]) {
		
		return naukriExcelRepository.getResumePath(ids).stream().filter(s -> s != null).filter(s -> !s.equals("")).collect(Collectors.toList());
		
	}

	public List<String> commonResumeNaukriJobPath(Long ids[]) {
		
		return candidatePrefRepository.getResumePath(ids);
		
	}

	
	public List<NaukriExcelRecord> recDownloadBdmNaukriExcelRecord(Long cadId[]) {
		
		return commonDownloadBdmNaukriExcelRecord(cadId);
	}
	
	public List<NaukriExcelRecord> recDownloadBdmNaukriJobExcelRecord(Long cadId[]) {
		
		return commonDownloadBdmNaukriJobExcelRecord(cadId);
	}
	
	public List<String> recResumeNaukriPath(Long ids[]) {
		
		return commonResumeNaukriPath(ids);
	}
	
	public List<String> recResumeNaukriJobPath(Long ids[]) {
		
		return commonResumeNaukriJobPath(ids);
		
	}
	
	public List<NaukriExcelRecord> bdmDownloadBdmNaukriExcelRecord(Long cadId[]) {
		
		return commonDownloadBdmNaukriExcelRecord(cadId);
	}
	
	public List<NaukriExcelRecord> bdmDownloadBdmNaukriJobExcelRecord(Long cadId[]) {
		
		return commonDownloadBdmNaukriJobExcelRecord(cadId);
	}
	
	public List<String> bdmResumeNaukriPath(Long ids[]) {
		
		return commonResumeNaukriPath(ids);
	}
	
	public List<String> bdmResumeNaukriJobPath(Long ids[]) {
		
		return commonResumeNaukriJobPath(ids);
		
	}
	
}
