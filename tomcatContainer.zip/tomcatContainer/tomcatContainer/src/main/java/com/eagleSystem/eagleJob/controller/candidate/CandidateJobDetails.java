package com.eagleSystem.eagleJob.controller.candidate;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.eagleSystem.eagleJob.bussinessObject.JobBO;
import com.eagleSystem.eagleJob.service.JobService;
import com.eagleSystem.eagleJob.util.JobBOPrepareUtil;
import com.eagleSystem.eagleJob.util.Role;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.SingleJobRequest;

@Controller
public class CandidateJobDetails {

	@Autowired
	JobService jobService;
	
	@Autowired
	JobBOPrepareUtil jobBOPrepareUtil;
	
	@CrossOrigin
	@GetMapping(value = URLMapper.JOB_DETAIL, produces = {"application/json"})
	public @ResponseBody SingleJobRequest jDisplayJobDetail(Authentication auth, @RequestParam("jobId") Long jobId) {
		
		JobBO jobBO = jobService.getJobBOById(jobId);
		
		SingleJobRequest jobDetail = jobBOPrepareUtil.PrepareJobRequest(jobBO);
		System.out.println(jobDetail);
		
		return jobDetail;
		
	}
	
	@GetMapping(URLMapper.JOB_DETAIL)
	public String displayJobDetail(Model model, Authentication auth, @RequestParam("jobId") Long jobId) {
		
		SingleJobRequest jobDetail = jDisplayJobDetail(auth, jobId);
		model.addAttribute("request", jobDetail);
		System.out.println(jobDetail);
		
		if(auth == null) {
			System.out.println("common");
			return ViewMapper.COMMON_JOB_DETAILS;
		}
		boolean isCandidate = false;
		boolean	isEmployer = false;
		Collection<? extends GrantedAuthority> authorities = auth.getAuthorities();
		for (GrantedAuthority grantedAuthority : authorities) {
			if (Role.candidate.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
				System.out.println("candidate");
				isCandidate = true;
				break;
			} else if (Role.recruiter.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
				System.out.println("recruiter");
				isEmployer = true;
				break;
			}
		}
		if (isCandidate) {
			return ViewMapper.CANDIDATE_JOB_DETAILS;
		} else if (isEmployer) {
			return ViewMapper.RECRUITER_JOB_DETAILS;
		} else {
			throw new IllegalStateException();
		}
		
		//return ViewMapper.CANDIDATE_JOB_DETAILS;
		
	}
	
}
