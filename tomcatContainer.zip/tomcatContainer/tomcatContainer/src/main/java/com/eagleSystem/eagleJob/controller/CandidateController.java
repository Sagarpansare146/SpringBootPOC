package com.eagleSystem.eagleJob.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.service.CandidateService;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.util.CandidateBOPrepareUtil;
import com.eagleSystem.eagleJob.util.CandidateModelPrepareUtil;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.UserRegistrationRequest;

@Controller
public class CandidateController {

	@Autowired
	CandidateModelPrepareUtil util;

	@Autowired
	CandidateService candidateService;

	@Autowired
	RecruiterService recruiterService;

	@Autowired
	CandidateBOPrepareUtil prepareUtil;

	public static final String UPDATE_CANDIDATE_MODEl = "request";

	@GetMapping(value = URLMapper.CANDIDATE_PROFILE_UPDATE, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody UserRegistrationRequest jcandidateUpdateForm(
			@ModelAttribute(UPDATE_CANDIDATE_MODEl) UserRegistrationRequest registrationRequest, Model model,
			Authentication auth) {

		System.out.println("update form");

		// String username = "wasimsayyad";
		// UserRegistrationRequest userRegistrationRequest =
		// candidateService.getUserData(username);
		UserRegistrationRequest userRegistrationRequest = candidateService.getUserData(auth.getName());

		return userRegistrationRequest;
	}

	@GetMapping(URLMapper.CANDIDATE_PROFILE_UPDATE)
	public String candidateUpdateForm(
			@ModelAttribute(UPDATE_CANDIDATE_MODEl) UserRegistrationRequest registrationRequest, Model model,
			Authentication auth) {

		UserRegistrationRequest userRegistrationRequest = jcandidateUpdateForm(registrationRequest, model, auth);
		model.addAttribute("request", userRegistrationRequest);

		return ViewMapper.CANDIDATE_PROFILE;

	}

	@PostMapping(value = URLMapper.CANDIDATE_PROFILE_UPDATE, produces = { "application/json" })
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody boolean jupdate(Model model,
			@ModelAttribute(UPDATE_CANDIDATE_MODEl) @Valid UserRegistrationRequest registrationRequest,
			Authentication auth) {

		boolean flag = true;
		// String username = "anilshindde0151@gmail.com";

		// Long id = candidateService.getCandidateId(username);

		System.out.println("profileUpdate");

		try {

			Long id = candidateService.getCandidateId(auth.getName());

			flag = candidateService.candidateUpdate(registrationRequest, id);

		} catch (Throwable th) {
			th.printStackTrace();
			flag = false;
		}

		return flag;

	}

	@RequestMapping(value = URLMapper.CANDIDATE_PROFILE_UPDATE, method = RequestMethod.POST)
	public String update(Model model,
			@ModelAttribute(UPDATE_CANDIDATE_MODEl) @Valid UserRegistrationRequest registrationRequest,
			BindingResult result, Authentication auth) {

		System.out.println("upd");

		if (result.hasErrors()) {
			return ViewMapper.CANDIDATE_PROFILE;
		}

		// String username = "anilshindde0151@gmail.com";

		// Long id = candidateService.getCandidateId(username);

		boolean flag = jupdate(model, registrationRequest, auth);

		return "redirect:" + URLMapper.CANDIDATE_VIEW_JOBS;

	}

	public CandidateModelPrepareUtil getUtil() {
		return util;
	}

	public void setUtil(CandidateModelPrepareUtil util) {
		this.util = util;
	}

	public RecruiterService getRecruiterService() {
		return recruiterService;
	}

	public void setRecruiterService(RecruiterService recruiterService) {
		this.recruiterService = recruiterService;
	}

	public CandidateService getCandidateService() {
		return candidateService;
	}

	public void setCandidateService(CandidateService candidateService) {
		this.candidateService = candidateService;
	}

	public CandidateBOPrepareUtil getPrepareUtil() {
		return prepareUtil;
	}

	public void setPrepareUtil(CandidateBOPrepareUtil prepareUtil) {
		this.prepareUtil = prepareUtil;
	}

}
