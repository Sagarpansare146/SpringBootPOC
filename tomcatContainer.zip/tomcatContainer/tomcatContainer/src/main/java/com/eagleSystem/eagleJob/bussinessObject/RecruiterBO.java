package com.eagleSystem.eagleJob.bussinessObject;

import java.util.List;

import com.eagleSystem.eagleJob.entity.Job;

public class RecruiterBO {

	private Long id;
	private String name;
	private String Designation;
	private String email;
	private Long MobNo;
	private String username;
	private CompanyBO company;
	private List<Job> postedJobs;

	public RecruiterBO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getMobNo() {
		return MobNo;
	}

	public void setMobNo(Long mobNo) {
		MobNo = mobNo;
	}

	public CompanyBO getCompany() {
		return company;
	}

	public void setCompany(CompanyBO company) {
		this.company = company;
	}

	public List<Job> getPostedJobs() {
		return postedJobs;
	}

	public void setPostedJobs(List<Job> postedJobs) {
		this.postedJobs = postedJobs;
	}

	@Override
	public String toString() {
		return "RecruiterBO [id=" + id + ", name=" + name + ", Designation=" + Designation + ", email=" + email
				+ ", MobNo=" + MobNo + ", username=" + username + ", company=" + company + ", postedJobs=" + postedJobs
				+ "]";
	}

}
