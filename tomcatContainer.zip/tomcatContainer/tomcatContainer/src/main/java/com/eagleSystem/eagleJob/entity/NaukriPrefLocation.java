package com.eagleSystem.eagleJob.entity;

public interface NaukriPrefLocation {

	
	public String getPreferredLocations();
	
}
