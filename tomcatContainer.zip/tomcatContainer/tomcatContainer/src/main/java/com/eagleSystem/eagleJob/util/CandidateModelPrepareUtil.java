package com.eagleSystem.eagleJob.util;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.bussinessObject.CandidateBO;
import com.eagleSystem.eagleJob.bussinessObject.CandidatePrefBO;
import com.eagleSystem.eagleJob.bussinessObject.CandidateQualBO;
import com.eagleSystem.eagleJob.entity.Candidate;
import com.eagleSystem.eagleJob.entity.CandidatePreference;
import com.eagleSystem.eagleJob.entity.Qualification;

@Component
public class CandidateModelPrepareUtil {
	
	public Candidate prepareCandidateModel(CandidateBO candidateBO) {
		Candidate candidate = new Candidate();
		
		candidate.setName(candidateBO.getName());
		candidate.setEmail(candidateBO.getEmail());
		candidate.setGender(candidateBO.getGender());
		candidate.setContactNumber(candidateBO.getContactNumber());
		candidate.setCandidateAddress(candidateBO.getCandidateAddress());
		candidate.setCity(candidateBO.getCandidateCity());
		candidate.setState(candidateBO.getCandidateState());
		candidate.setDob(candidateBO.getDob());
		candidate.setUsername(candidateBO.getUsername());
		candidate.setJoinDate(new Date());
		candidate.setToken(candidateBO.getToken());
		candidate.setNotificationStatus(candidateBO.isNotificationStatus());
		
		return candidate;
	}
	
	public Qualification prepareQualModel(CandidateBO candidateBO) {
		
			Qualification qualification = new Qualification();
			
			qualification.setDegree(candidateBO.getQualification().getDegree());
			qualification.setSpecilization(candidateBO.getQualification().getSpecilization());
			qualification.setExperience(candidateBO.getQualification().getExperience());
			qualification.setMonth(candidateBO.getQualification().getMonth());
			qualification.setPassout(candidateBO.getQualification().getPassout());
			qualification.setPercentage(candidateBO.getQualification().getPercentage());
			qualification.setUniversity(candidateBO.getQualification().getUniversity());
			
		
		return qualification;
		
	}
	
	public CandidatePreference preparePrefModel(CandidateBO candidateBO) {
		
		CandidatePrefBO candidatePrefBO = candidateBO.getCandidatePreference();
		CandidatePreference cf = new CandidatePreference();
		
/*		
		String keySkill = "";
	//	String location = "";
		
		for (String ks : candidatePrefBO.getKeySkill()) {
			keySkill = keySkill + ks;
		}
		
		for (String loc : candidatePrefBO.getLocation()) {
			location = location + loc;
		}
*/		
		cf.setJobCategory(candidatePrefBO.getJobCategory());
		cf.setFunctionalArea(candidatePrefBO.getFunctionalArea());
		cf.setKeySkill(candidatePrefBO.getKeySkill());
		cf.setJobType(candidatePrefBO.getJobType());
		cf.setLocation(candidatePrefBO.getTopCities());
		// add saving code to folder and return path
		
		cf.setResume(candidatePrefBO.getResume());
		
		return cf;
		
	}

	public CandidateBO getPrepareCandidateBO(Candidate candidate) {
		
		CandidateBO candidateBO = new CandidateBO();
		
		if(!(candidate.getId() == null))
		candidateBO.setId(candidate.getId());
		candidateBO.setName(candidate.getName());
		candidateBO.setEmail(candidate.getEmail());
		candidateBO.setContactNumber(candidate.getContactNumber());
		candidateBO.setGender(candidate.getGender());
		candidateBO.setDob(candidate.getDob());
		candidateBO.setCandidateState(candidate.getState());
		candidateBO.setCandidateCity(candidate.getCity());
		candidateBO.setCandidateAddress(candidate.getCandidateAddress());
		candidateBO.setUsername(candidate.getUsername());
		candidateBO.setNotificationStatus(candidate.isNotificationStatus());
		candidateBO.setToken(candidate.getToken());
		return candidateBO;
		
	}
	
	public CandidateQualBO getPrepareQualificationBO(Qualification quali) {
		
			CandidateQualBO bo = new CandidateQualBO();
			
			bo.setQid(quali.getQid());
			bo.setDegree(quali.getDegree());
			bo.setExperience(quali.getExperience());
			bo.setMonth(quali.getMonth());
			bo.setPassout(quali.getPassout());
			bo.setPercentage(quali.getPercentage());
			bo.setSpecilization(quali.getSpecilization());
			bo.setUniversity(quali.getUniversity());
			
		
		return bo;
		
	}
	
	public CandidatePrefBO getPrepareCandidatePrefBO(CandidatePreference canPref) {
		
		CandidatePrefBO bo = new CandidatePrefBO();
		
		bo.setCpid(canPref.getCid());
		bo.setJobType(canPref.getJobType());
	//	bo.setResume(canPref.getResume());
//		System.out.println("keyskill");
//		System.out.println();
//		List<String> skill = Arrays.asList(canPref.getKeySkill().split(","));
//		List<String> loc = Arrays.asList(canPref.getLocation().split("\\s*,\\s*"));
		
		
		
		bo.setKeySkill(canPref.getKeySkill());
		bo.setTopCities(canPref.getLocation());
		bo.setFunctionalArea(canPref.getFunctionalArea());
		bo.setJobCategory(canPref.getJobCategory());
		
		return bo;
		
	}

	
}
