package com.eagleSystem.eagleJob.businessExcel;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eagleSystem.eagleJob.dao.CandidatePrefRepository;
import com.eagleSystem.eagleJob.dao.QualificationRepository;

@CrossOrigin
@RestController
public class NaukriJobDownload {
	@Autowired
	 QualificationRepository qualificationRepository;
	
	@Autowired
	CandidatePrefRepository candidatePrefRepositoryl;
	
	
	@Cacheable("NaukriJobjobCategory")
	@RequestMapping(value = "/getNaukriJobjobCategory")
    public Set<String> getJobCategory() 
	{
	
	List<String> jobC = candidatePrefRepositoryl.findDistinctjobCategory();
	Set<String> jobCategory= new HashSet<>();
	jobC.parallelStream().forEach(jc -> jobCategory.addAll(Arrays.asList(jc.split(","))));
	jobCategory.forEach(e -> e.trim());
	return jobCategory;

}
	
	@Cacheable("getNaukriJobjPassout")
	@RequestMapping(value = "/getNaukriJobjPassout")
    public Set<Integer> getNaukriJobjPassout() 
	{
	
	List<Integer> passout = qualificationRepository.findDistinctpassout();
	
	Set<Integer> pass = passout.stream().distinct().collect(Collectors.toSet());
	
	return pass;

}
	
	
}
