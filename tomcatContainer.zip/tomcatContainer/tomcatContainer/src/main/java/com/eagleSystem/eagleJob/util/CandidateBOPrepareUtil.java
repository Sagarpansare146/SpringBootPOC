package com.eagleSystem.eagleJob.util;


import org.springframework.stereotype.Component;
import com.eagleSystem.eagleJob.bussinessObject.CandidateBO;
import com.eagleSystem.eagleJob.bussinessObject.CandidatePrefBO;
import com.eagleSystem.eagleJob.bussinessObject.CandidateQualBO;
import com.eagleSystem.eagleJob.valueObject.UserRegistrationRequest;

@Component
public class CandidateBOPrepareUtil {
	
	public CandidateBO prepareCandidateBO(UserRegistrationRequest registrationRequest) {

		CandidateBO candidateBO = new CandidateBO();
		
		if(!(registrationRequest.getId() == null))
			candidateBO.setId(registrationRequest.getId());
		candidateBO.setName(registrationRequest.getName());
		candidateBO.setEmail(registrationRequest.getEmail());
		candidateBO.setDob(registrationRequest.getDob());
		candidateBO.setGender(registrationRequest.getGender());
		candidateBO.setCandidateAddress(registrationRequest.getCandidateAddress());
		candidateBO.setCandidateCity(registrationRequest.getCandidateCity());
		candidateBO.setCandidateState(registrationRequest.getCandidateState());
		candidateBO.setContactNumber(registrationRequest.getContactNumber());
		candidateBO.setUsername(registrationRequest.getUsername());
		candidateBO.setPassword(registrationRequest.getPassword());
		candidateBO.setNotificationStatus(registrationRequest.isNotificationStatus());
		candidateBO.setToken(registrationRequest.getToken());
		candidateBO.setNotificationStatus(registrationRequest.isNotificationStatus());
		return candidateBO;
	}
	
	
	
	public CandidateQualBO prepareCandidateQualBO(UserRegistrationRequest registrationRequest) {
		
		CandidateQualBO caQualBO = new CandidateQualBO();
		
		caQualBO.setDegree(registrationRequest.getDegree());
		caQualBO.setSpecilization(registrationRequest.getSpecilization());
		caQualBO.setPassout(registrationRequest.getPassout());
		caQualBO.setPercentage(registrationRequest.getPercentage());
		caQualBO.setExperience(registrationRequest.getExperience());
		caQualBO.setMonth(registrationRequest.getMonth());
		caQualBO.setUniversity(registrationRequest.getUniversity());
		
		
		return caQualBO;
	}
	
	public CandidatePrefBO prepareCanPrefBO(UserRegistrationRequest registrationRequest) {
		
		CandidatePrefBO prefBO = new CandidatePrefBO();
		
		String topCities = "";
		String jobCategory = "";
		
		for (String tc : registrationRequest.getTopCities()) {
			if(!(topCities.equals(""))) {
				
				topCities = topCities +","+ tc;
			}
			else {
				topCities = topCities + tc;
				
				
			}
		}
		
		for (String jc : registrationRequest.getJobCategory()) {
			
			if(!(jobCategory.equals(""))) {
				jobCategory = jobCategory +","+ jc;
				
				
			}
			else {
				
				jobCategory = jobCategory + jc;
			}
			
		}

		
		prefBO.setJobCategory(jobCategory);
		prefBO.setFunctionalArea(registrationRequest.getFunctionalArea());
		prefBO.setKeySkill(registrationRequest.getKeySkill());
		prefBO.setJobType(registrationRequest.getJobType());
		prefBO.setTopCities(topCities);
		
		
	//	prefBO.setResume(registrationRequest.getResume());
		
		return prefBO;
	}
	
	public UserRegistrationRequest getUserRegRequest(CandidateBO candidateBO) {
		
		UserRegistrationRequest UserReq = new UserRegistrationRequest();
		
		UserReq.setId(candidateBO.getId());
		UserReq.setName(candidateBO.getName());
		UserReq.setEmail(candidateBO.getEmail());
		UserReq.setDob(candidateBO.getDob());
		UserReq.setGender(candidateBO.getGender());
		UserReq.setCandidateAddress(candidateBO.getCandidateAddress());
		UserReq.setCandidateCity(candidateBO.getCandidateCity());
		UserReq.setCandidateState(candidateBO.getCandidateState());
		UserReq.setContactNumber(candidateBO.getContactNumber());
		UserReq.setUsername(candidateBO.getUsername());
		UserReq.setPassword(candidateBO.getPassword());
		
		UserReq.setUsername(candidateBO.getUsername());
//		UserReq.setPassword(candidateBO.getPassword());
		
		UserReq.setNotificationStatus(candidateBO.isNotificationStatus());
		UserReq.setToken(candidateBO.getToken());
		System.out.println(candidateBO.getQualification());
		System.out.println(candidateBO.getCandidatePreference());
		
		
		if(candidateBO.getCandidatePreference() != null)
		UserReq = mapCandidatePrefBO(UserReq, candidateBO);
		
		if(candidateBO.getQualification() != null)
		UserReq = mapCandidateQualBO(UserReq, candidateBO);
			
		return UserReq;
		
	}
	
	public UserRegistrationRequest mapCandidatePrefBO(UserRegistrationRequest UserReq, CandidateBO candidateBO)
	
	{

		
		
		UserReq.setJobCategory(candidateBO.getCandidatePreference().getJobCategory());
		UserReq.setFunctionalArea(candidateBO.getCandidatePreference().getFunctionalArea());
		UserReq.setJobType(candidateBO.getCandidatePreference().getJobType());
		UserReq.setKeySkill(candidateBO.getCandidatePreference().getKeySkill());
		UserReq.setTopCities((candidateBO.getCandidatePreference().getTopCities()).split(","));
	//	UserReq.setResume(candidateBO.getCandidatePreference().getResume());
		
		return UserReq;
		
	}
	
	
	public UserRegistrationRequest mapCandidateQualBO(UserRegistrationRequest UserReq, CandidateBO candidateBO)
	{
		CandidateQualBO qualBO = candidateBO.getQualification();
		
		UserReq.setDegree(qualBO.getDegree());
		
		UserReq.setSpecilization(qualBO.getSpecilization());
		UserReq.setUniversity(qualBO.getUniversity());
		UserReq.setPercentage(qualBO.getPercentage());
		UserReq.setPassout(qualBO.getPassout());
		UserReq.setMonth(qualBO.getMonth());
		UserReq.setExperience(qualBO.getExperience());
		
	return UserReq;
	}
	
}
