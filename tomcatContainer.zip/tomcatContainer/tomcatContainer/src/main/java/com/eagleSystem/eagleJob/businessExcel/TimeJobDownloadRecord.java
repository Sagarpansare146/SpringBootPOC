package com.eagleSystem.eagleJob.businessExcel;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eagleSystem.eagleJob.dao.TimesExcelRepository;




@CrossOrigin
@RestController
public class TimeJobDownloadRecord {
	
	

	@Autowired
	TimesExcelRepository timesExcelRepository;

	
	
	
	@Cacheable("TimejobCategory")
		@RequestMapping(value = "/getTimeJobCategory")
	public Set<String> getJobCategory() {
		
		List<String> jobC = timesExcelRepository.findDistinctjobCategory();
		Set<String> jobCategory= new HashSet<>();
		jobC.parallelStream().forEach(jc -> jobCategory.addAll(Arrays.asList(jc.split(","))));
		jobCategory.forEach(e -> e.trim());
		return jobCategory;

	}

}
