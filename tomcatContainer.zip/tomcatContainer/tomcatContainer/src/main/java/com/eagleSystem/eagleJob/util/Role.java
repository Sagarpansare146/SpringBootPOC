package com.eagleSystem.eagleJob.util;


public enum Role {
	candidate,
	admin,
	recruiter,
	bdm,
	subadmin,
	user,
	database
}