package com.eagleSystem.eagleJob.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagleSystem.eagleJob.entity.CustomerDownloadRecords;
import java.lang.String;
import java.util.List;

public interface CustomerDownloadRecordsRepository extends JpaRepository<CustomerDownloadRecords, Long> {
	
	List<CustomerDownloadRecords> findByCustomer(String customer);

}
