package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eagleSystem.eagleJob.entity.City;

@Repository
public interface CityRepository extends JpaRepository<City, Integer>{

	@Query("select Distinct c.city from City c")
	List<City> getAllState();
		
	@Query("select c from City c where c.state =:state")
	List<City> getCitiesByState(@Param("state") String state);
	
}
