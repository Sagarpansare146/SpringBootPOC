package com.eagleSystem.eagleJob.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class TestAspect extends AbstractAppPointcut {

	private static final Logger LOGGER = LoggerFactory.getLogger(TestAspect.class);

	@Around(value = "test()")
	public Object test(ProceedingJoinPoint jp) throws Throwable {

		Object obj = null;

		System.out.println("Aspect");
		System.out.println(jp.getSignature());

		try {
			obj = jp.proceed();
		} catch (Throwable th) {
			LOGGER.info("doStuff took input - {}", jp.getSignature());
			LOGGER.error("doStuff encountered an error with value - {}   -- " + th.getMessage(), th);

		}

		return obj;

	}

}
