package com.eagleSystem.eagleJob.service.bdm;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.dao.ClientNaukriRepository;
import com.eagleSystem.eagleJob.dao.MonsterExcelRepository;
import com.eagleSystem.eagleJob.dao.NaukriExcelRepository;
import com.eagleSystem.eagleJob.dao.ShineExcelRepository;
import com.eagleSystem.eagleJob.dao.TimesExcelRepository;
import com.eagleSystem.eagleJob.entity.MonsterExcelRecord;
import com.eagleSystem.eagleJob.entity.ShineExcelRecord;
import com.eagleSystem.eagleJob.entity.TimesExcelRecord;

@Component
public class BdmService {

	@Autowired
	NaukriExcelRepository naukriExcelRepository;

	@Autowired
	ShineExcelRepository shineExcelRepository;

	@Autowired
	MonsterExcelRepository monsterExcelRepository;

	@Autowired
	TimesExcelRepository timesExcelRepository;
	
	@Autowired
	ClientNaukriRepository clientNaukriRepository;

	public List<?> getNaukriRecordsByJobCategory(String jobCategory) {
		return naukriExcelRepository.findByJobCategory(jobCategory);
	}

	public List<MonsterExcelRecord> getMonsterRecordsByJobCategory(String jobCategory) {
		return monsterExcelRepository.findByJobCategory(jobCategory);
	}

	public List<ShineExcelRecord> getShineRecordsByJobCategory(String jobCategory) {
		return shineExcelRepository.findByjobCategory(jobCategory);
	}

	public List<TimesExcelRecord> getTimesRecordsByJobCategory(String jobCategory) {
		return timesExcelRepository.findByJobCategory(jobCategory);
	}
   
	public List<?> getClientNaukriRecordsByJobCategory(String jobCategory) {
		return clientNaukriRepository.findByJobCategory(jobCategory);
	}
	
	// public List<NaukriExcelRecord> get
}
