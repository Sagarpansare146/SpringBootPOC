package com.eagleSystem.eagleJob.entity;

	import java.util.Date;

	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Table;
	

	@Entity
	@Table(name = "ClientNaukriExcelRecord")

public class ClientNaukriExcelRecord {
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private long id;

		@Column(name="Name")
		private String name;
		@Column(name="Gender")
		private String gender;
		@Column(name="Postal_Address")
		private String postalAddress;
		@Column(name="Mobile")
		private String mobile;
		@Column(name="Telephone")
		private String telephone;
		@Column(name="DOB")
		private String dob;
		@Column(name="Email_ID")
		private String emailID;
		@Column(name="Date_Of_Apply")
		private String dateOfApply;
		@Column(name="Total_Experience")
		private String totalExperience;
		@Column(name="Status")
		private String status;
		@Column(name="Resume_Title")
		private String resumeTitle;
		@Column(name="KeySkills")
		private String keySkills;
		@Column(name="FunctionalArea")
		private String functionalArea;
		@Column(name="Current_Location")
		private String currentLocation;
		@Column(name="Preferred_Locations")
		private String preferredLocations;
		@Column(name="Current_Employer")
		private String currentEmployer;
		@Column(name="Current_Designation")
		private String currentDesignation;
		@Column(name="AnnualSalary")
		private String annualSalary;
		@Column(name="UG_Course")
		private String ugCourse;
		@Column(name="UG_Specialization")
		private String ugSpecialization;
		@Column(name="UG_Institute")
		private String ugInstitute;
		
		@Column(name="Job_Category")
		private String jobCategory;
		
		private String resumePath;

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public String getPostalAddress() {
			return postalAddress;
		}

		public void setPostalAddress(String postalAddress) {
			this.postalAddress = postalAddress;
		}

		public String getMobile() {
			return mobile;
		}

		public void setMobile(String mobile) {
			this.mobile = mobile;
		}

		public String getTelephone() {
			return telephone;
		}

		public void setTelephone(String telephone) {
			this.telephone = telephone;
		}

		public String getDob() {
			return dob;
		}

		public void setDob(String dob) {
			this.dob = dob;
		}

		public String getEmailID() {
			return emailID;
		}

		public void setEmailID(String emailID) {
			this.emailID = emailID;
		}

		public String getDateOfApply() {
			return dateOfApply;
		}

		public void setDateOfApply(String dateOfApply) {
			this.dateOfApply = dateOfApply;
		}

		public String getTotalExperience() {
			return totalExperience;
		}

		public void setTotalExperience(String totalExperience) {
			this.totalExperience = totalExperience;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getResumeTitle() {
			return resumeTitle;
		}

		public void setResumeTitle(String resumeTitle) {
			this.resumeTitle = resumeTitle;
		}

		public String getKeySkills() {
			return keySkills;
		}

		public void setKeySkills(String keySkills) {
			this.keySkills = keySkills;
		}

		public String getFunctionalArea() {
			return functionalArea;
		}

		public void setFunctionalArea(String functionalArea) {
			this.functionalArea = functionalArea;
		}

		public String getCurrentLocation() {
			return currentLocation;
		}

		public void setCurrentLocation(String currentLocation) {
			this.currentLocation = currentLocation;
		}

		public String getPreferredLocations() {
			return preferredLocations;
		}

		public void setPreferredLocations(String preferredLocations) {
			this.preferredLocations = preferredLocations;
		}

		public String getCurrentEmployer() {
			return currentEmployer;
		}

		public void setCurrentEmployer(String currentEmployer) {
			this.currentEmployer = currentEmployer;
		}

		public String getCurrentDesignation() {
			return currentDesignation;
		}

		public void setCurrentDesignation(String currentDesignation) {
			this.currentDesignation = currentDesignation;
		}

		public String getAnnualSalary() {
			return annualSalary;
		}

		public void setAnnualSalary(String annualSalary) {
			this.annualSalary = annualSalary;
		}

		public String getUgCourse() {
			return ugCourse;
		}

		public void setUgCourse(String ugCourse) {
			this.ugCourse = ugCourse;
		}

		public String getUgSpecialization() {
			return ugSpecialization;
		}

		public void setUgSpecialization(String ugSpecialization) {
			this.ugSpecialization = ugSpecialization;
		}

		public String getUgInstitute() {
			return ugInstitute;
		}

		public void setUgInstitute(String ugInstitute) {
			this.ugInstitute = ugInstitute;
		}

		public String getJobCategory() {
			return jobCategory;
		}

		public void setJobCategory(String jobCategory) {
			this.jobCategory = jobCategory;
		}

		public String getResumePath() {
			return resumePath;
		}

		public void setResumePath(String resumePath) {
			this.resumePath = resumePath;
		}

		@Override
		public String toString() {
			return "NaukriExcelRecord [id=" + id + ", name=" + name + ", gender=" + gender + ", postalAddress="
					+ postalAddress + ", mobile=" + mobile + ", telephone=" + telephone + ", dob=" + dob + ", emailID="
					+ emailID + ", dateOfApply=" + dateOfApply + ", totalExperience=" + totalExperience + ", status="
					+ status + ", resumeTitle=" + resumeTitle + ", keySkills=" + keySkills + ", functionalArea="
					+ functionalArea + ", currentLocation=" + currentLocation + ", preferredLocations=" + preferredLocations
					+ ", currentEmployer=" + currentEmployer + ", currentDesignation=" + currentDesignation
					+ ", annualSalary=" + annualSalary + ", ugCourse=" + ugCourse + ", ugSpecialization=" + ugSpecialization
					+ ", ugInstitute=" + ugInstitute + ", jobCategory=" + jobCategory + ", resumePath=" + resumePath + "]";
		}
		
		
		
	}



