package com.eagleSystem.eagleJob.service;

import java.util.List;
import java.util.Map;

import com.eagleSystem.eagleJob.bussinessObject.CandidateApplicationBO;

public interface CandidateApplicationService {

	List<Long> getCandidateIdsByJobId(Long jobId);

	List<CandidateApplicationBO> getJobByCandidateId(Long candidateId);
	
	public Map<String, Object> getCandidateAppliedJobs(Long candidateId, int page, int pageSize);
	
	boolean applyJob(Long JobId, Long CandidateId);

	
}
