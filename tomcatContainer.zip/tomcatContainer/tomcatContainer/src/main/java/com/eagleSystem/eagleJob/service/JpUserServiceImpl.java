package com.eagleSystem.eagleJob.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eagleSystem.eagleJob.dao.JPUserRepository;
import com.eagleSystem.eagleJob.entity.JPUser;

@Transactional
@Service
public class JpUserServiceImpl implements JpUserService {

	@Autowired
	JPUserRepository jpUserRepository;
	
	public JPUser getUserByUsername(String username) {
		return jpUserRepository.findByUsernameIgnoreCase(username);
	}
}
