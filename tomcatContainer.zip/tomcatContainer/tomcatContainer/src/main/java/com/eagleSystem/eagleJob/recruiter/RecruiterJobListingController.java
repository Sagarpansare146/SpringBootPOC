package com.eagleSystem.eagleJob.recruiter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.eagleSystem.eagleJob.bussinessObject.RecruiterBO;
import com.eagleSystem.eagleJob.service.JobService;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.util.ViewMapper;
import com.eagleSystem.eagleJob.valueObject.ListJobRequest;


@Controller
public class RecruiterJobListingController {

	@Autowired
	JobService jobService;

//	ThreadLocal<Map<String, Object>> threadLocal = new ThreadLocal<>();
	
	@Autowired
	RecruiterService recruiterService;

	@RequestMapping(value = URLMapper.RECRUITER_POSTED_JOBS, method = RequestMethod.GET, produces = {"application/json"})
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody Map<String, Object> jLoadEmployerJobs(Model model, Authentication auth, @RequestParam(name = "page", required = false, defaultValue = "0") int page, @RequestParam(name = "pageSize", required = false, defaultValue = "20") int pageSize) {

		RecruiterBO recruiterBO = recruiterService.getRecruiterByUsername(auth.getName());

		Map<String, Object> map = new HashMap<>();
		map  = jobService.postedJobByRecruiter(recruiterBO.getId(), page, pageSize);
		
		
//		List<ListJobRequest> postedJob = (List<ListJobRequest>) map.get("request");
//		System.out.println(postedJob);
		return map;
	}
		
	
	@RequestMapping(value = URLMapper.RECRUITER_POSTED_JOBS, method = RequestMethod.GET)
	public String loadEmployerJobs(Model model, Authentication auth, @RequestParam(name = "page", required = false, defaultValue = "0") int page,
			@RequestParam(name = "pageSize",required = false, defaultValue = "20") int pageSize) {
		
		Map<String, Object> map = new HashMap<>();
	//	List<ListJobRequest> postedJob = null;
		try {
			map = jLoadEmployerJobs(model, auth, page, pageSize);
		}catch(Throwable th) {
			th.printStackTrace();
			model.addAttribute("error", "Unable to get posted Job");
		}
		
		model.addAttribute("request", map.get("request"));
		model.addAttribute("totalPages", map.get("totalPages"));
		model.addAttribute("count", map.get("totalCount"));
		model.addAttribute("currentIndex", page);
		
	//	model.addAttribute("request", postedJob);
		
//		System.out.println(threadLocal.get().get("count"));
		
		//		Recruiter employer = employerRepository.findByUsername(auth.getName());
//		System.out.println(auth.getName()+"iii");
//		model.addAttribute("jobs", jobRepository.findByEmployerId(employer.getId()));
		return ViewMapper.RECRUITER_POSTED_JOBS;
	}
}