package com.eagleSystem.eagleJob.controller.bdm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.eagleSystem.eagleJob.service.bdm.BdmService;
import com.eagleSystem.eagleJob.util.ResumeUtil;

@Controller
public class TestController {

	public static final int GOLD_NAUKRI = 1;
	public static final int SILVER_MONSTER = 2;
	public static final int PLATINUM_SHINE = 3;
	public static final int STANDARD_TIMES = 4;
	
	@Autowired
	BdmService bdmService;
	
	@Autowired
	ResumeUtil resumeUtil;
	
	@RequestMapping(value="/abcdef", produces = { "application/json" })
	@ResponseBody
	public Map<String, String> silverServerJson(@RequestParam("jobCategory") String jobCategory, @RequestParam("plan") String plan) {
	
	/*	System.out.println("output");
		List l = new ArrayList();
		switch (Integer.parseInt(plan)) {
		case 1:
			l =  bdmService.getNaukriRecordsByJobCategory(jobCategory);
			break;
		case 2:
			l =  bdmService.getMonsterRecordsByJobCategory(jobCategory);
			break;
		case 3:
			l =  bdmService.getShineRecordsByJobCategory(jobCategory);
			break;
		case 4:
			l =   bdmService.getTimesRecordsByJobCategory(jobCategory);
			break;

		default:
			l =    new ArrayList();
			break;
		}*/

		
		
		
		/*ObjectMapper mapper = new ObjectMapper();
		SingleJobRequest usrPost = null;
        try {
        	usrPost = mapper.readValue(new URL("http://naukrijob.co.in/jobDetail.json?jobId=1"), SingleJobRequest.class);
            System.out.println(usrPost);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        List l = new ArrayList();
        l.add(usrPost);
        return l;*/
		
		
	//	return (resumeUtil.check(jobCategory));
		
		return null;
	}

}