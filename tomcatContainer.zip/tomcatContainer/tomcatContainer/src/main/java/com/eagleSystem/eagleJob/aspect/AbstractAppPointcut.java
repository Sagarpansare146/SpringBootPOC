package com.eagleSystem.eagleJob.aspect;

import org.aspectj.lang.annotation.Pointcut;

public abstract class AbstractAppPointcut {
//vvb
	// @Pointcut("execution(*
	// com.eagleSystem.eagleJob.service.RecruiterServiceImpl.downloadExcelRecords(..))")
	public void downloadRecordPointcut() {
	}

	// @Pointcut("execution(*
	// com.eagleSystem.eagleJob.service.RecruiterServiceImpl.downloadResume(..))")
	public void downloadResumePointcut() {
	}

	@Pointcut("execution(* com.eagleSystem.eagleJob.service.*.*(..))")
	public void test() {

	}

	@Pointcut("execution(* com.eagleSystem.eagleJob.service.CandidateApplicationServiceImpl.applyJob(..))")
	public void applyJobPointcut() {

	}

	@Pointcut("execution(* com.eagleSystem.eagleJob.service.CandidateServiceImpl.candidateReg(..))")
	public void cadRegpointcut() {

	}

	@Pointcut("execution(* com.eagleSystem.eagleJob.service.RecruiterServiceImpl.regRecruiter(..))")
	public void RecRegpointcut() {

	}

	@Pointcut("execution(* com.eagleSystem.eagleJob.service.JobServiceImpl.updateJob(..))")
	public void UpdateJobPostPointcut() {

	}

	@Pointcut("execution(* com.eagleSystem.eagleJob.service.JobServiceImpl.postNewJob(..))")
	public void JobPostPointcut() {

	}
	
	
	@Pointcut("execution(* com.eagleSystem.eagleJob.service.RecruiterServiceImpl.gDownloadExcelRecords(..))")
	public void databaseExcelNaukriJobPointCut() {
		
	}
	
	@Pointcut("execution(* com.eagleSystem.eagleJob.service.bdm.BdmServiceImpl.downloadBdmNaukriExcelRecord(..))")
	public void databaseExcelNaukriPointCut() {
		
	}
	
	@Pointcut("execution(* com.eagleSystem.eagleJob.service.bdm.BdmClientServiceImpl.downloadBdmNaukriExcelRecord(..))")
	public void databaseClientExcelNaukriPointCut() {
		
	}
	
	@Pointcut("execution(* com.eagleSystem.eagleJob.service.bdm.BdmServiceImpl.resumeNaukriJobPath(..))")
	public void databaseResumeNaukriJobPointCut() {
		
	}
	
	@Pointcut("execution(* com.eagleSystem.eagleJob.service.bdm.BdmServiceImpl.resumeNaukriPath(..))")
	public void databaseResumeNaukriPointCut() {
		
	}
// check 4
}
