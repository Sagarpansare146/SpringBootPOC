package com.eagleSystem.eagleJob.bussinessObject;

import java.util.Date;

public class CandidateApplicationBO {

	private Long id;

	private CandidateBO candidateBO;

	private JobBO jobBO;

	private String applicationStatus;

	private Date appliedOn;

	private Date recruiterActionOn;

	public CandidateApplicationBO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public CandidateBO getCandidateBO() {
		return candidateBO;
	}

	public void setCandidateBO(CandidateBO candidateBO) {
		this.candidateBO = candidateBO;
	}

	public JobBO getJobBO() {
		return jobBO;
	}

	public void setJobBO(JobBO jobBO) {
		this.jobBO = jobBO;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public Date getAppliedOn() {
		return appliedOn;
	}

	public void setAppliedOn(Date appliedOn) {
		this.appliedOn = appliedOn;
	}

	public Date getRecruiterActionOn() {
		return recruiterActionOn;
	}

	public void setRecruiterActionOn(Date recruiterActionOn) {
		this.recruiterActionOn = recruiterActionOn;
	}

	@Override
	public String toString() {
		return "CandidateApplicationBO [id=" + id + ", candidateBO=" + candidateBO + ", jobBO=" + jobBO
				+ ", applicationStatus=" + applicationStatus + ", appliedOn=" + appliedOn + ", recruiterActionOn="
				+ recruiterActionOn + "]";
	}

}
