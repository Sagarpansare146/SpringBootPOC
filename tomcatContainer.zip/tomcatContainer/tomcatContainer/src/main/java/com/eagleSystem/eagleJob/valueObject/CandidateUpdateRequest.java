package com.eagleSystem.eagleJob.valueObject;

import java.util.Arrays;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

public class CandidateUpdateRequest {

	private Long id;
	
	@NotEmpty(message="FirstName cannot be empty")
	private String name = "";
	
	@NotEmpty(message = "email address cannot be empty")
	@Email(message="Please enter a valid email address")
	private String email = "";
	
	@NotNull(message="Mobile number cannot be empty")
	private Long contactNumber;
	
	@NotEmpty(message="candidate Address cannot be empty")
	private String candidateAddress = "";
	
	private String candidateState = "";
	
	@NotEmpty(message="city cannot be empty")
	private String candidateCity = "";
	
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private Date dob;
	
	@NotEmpty(message="Gender cannot be empty")
	private String gender = "";
	
	@NotEmpty(message="Select Your Qualification")
	private String degree = "";
	
	private String specilization = "";
	
	private String university = "";
	
	@NotNull(message="Year of passing cannot be empty")
	private Integer passout ;
	
	@NotNull(message="Percentage cannot be empty")
	private Integer percentage;
	
	private Integer experience;
	
	private Integer month;
	
	@NotEmpty(message="JobCategory cannot be empty")
	private String jobCategory = "";
	
	@NotEmpty(message="Functional Area cannot be empty")
	private String functionalArea = "";
	
	@NotNull(message="KeySkill cannot be empty")
	private String[] keySkill = {""};
	private String topCities = "";
	private String jobType = "";
	
	@NotEmpty(message="Username cannot be empty")
	private String username;
	
	@NotEmpty(message="Password cannot be empty")
	private String password;
	
	@NotNull(message="Select to upload your resume")
	private MultipartFile resume;
	
	private String isExperience;
	
	private Integer expFrom;
	
	private Integer expTo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getCandidateAddress() {
		return candidateAddress;
	}

	public void setCandidateAddress(String candidateAddress) {
		this.candidateAddress = candidateAddress;
	}

	public String getCandidateState() {
		return candidateState;
	}

	public void setCandidateState(String candidateState) {
		this.candidateState = candidateState;
	}

	public String getCandidateCity() {
		return candidateCity;
	}

	public void setCandidateCity(String candidateCity) {
		this.candidateCity = candidateCity;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getSpecilization() {
		return specilization;
	}

	public void setSpecilization(String specilization) {
		this.specilization = specilization;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public Integer getPassout() {
		return passout;
	}

	public void setPassout(Integer passout) {
		this.passout = passout;
	}

	public Integer getPercentage() {
		return percentage;
	}

	public void setPercentage(Integer percentage) {
		this.percentage = percentage;
	}

	public Integer getExperience() {
		return experience;
	}

	public void setExperience(Integer experience) {
		this.experience = experience;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public String getJobCategory() {
		return jobCategory;
	}

	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}

	public String getFunctionalArea() {
		return functionalArea;
	}

	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}

	public String[] getKeySkill() {
		return keySkill;
	}

	public void setKeySkill(String[] keySkill) {
		this.keySkill = keySkill;
	}

	public String getTopCities() {
		return topCities;
	}

	public void setTopCities(String topCities) {
		this.topCities = topCities;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public MultipartFile getResume() {
		return resume;
	}

	public void setResume(MultipartFile resume) {
		this.resume = resume;
	}

	public String getIsExperience() {
		return isExperience;
	}

	public void setIsExperience(String isExperience) {
		this.isExperience = isExperience;
	}

	public Integer getExpFrom() {
		return expFrom;
	}

	public void setExpFrom(Integer expFrom) {
		this.expFrom = expFrom;
	}

	public Integer getExpTo() {
		return expTo;
	}

	public void setExpTo(Integer expTo) {
		this.expTo = expTo;
	}

	@Override
	public String toString() {
		return "CandidateUpdateRequest [id=" + id + ", name=" + name + ", email=" + email + ", contactNumber="
				+ contactNumber + ", candidateAddress=" + candidateAddress + ", candidateState=" + candidateState
				+ ", candidateCity=" + candidateCity + ", dob=" + dob + ", gender=" + gender + ", degree=" + degree
				+ ", specilization=" + specilization + ", university=" + university + ", passout=" + passout
				+ ", percentage=" + percentage + ", experience=" + experience + ", month=" + month + ", jobCategory="
				+ jobCategory + ", functionalArea=" + functionalArea + ", keySkill=" + Arrays.toString(keySkill)
				+ ", topCities=" + topCities + ", jobType=" + jobType + ", username=" + username + ", password="
				+ password + ", resume=" + resume + ", isExperience=" + isExperience + ", expFrom=" + expFrom
				+ ", expTo=" + expTo + "]";
	}

	



}
