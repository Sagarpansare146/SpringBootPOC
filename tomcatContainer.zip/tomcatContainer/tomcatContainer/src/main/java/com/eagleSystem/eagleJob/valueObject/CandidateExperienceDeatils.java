package com.eagleSystem.eagleJob.valueObject;

import java.util.Date;

public class CandidateExperienceDeatils {
	
	private String companyName;
	private String industry;
	private int totalExperienceYear;
	private int totalExperienceMonth;
	private Long annualSalaryLakh;
	private Long annualSalaryThousand;
	private Date durationFrom;
	private Date durationTo;
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public int getTotalExperienceYear() {
		return totalExperienceYear;
	}
	public void setTotalExperienceYear(int totalExperienceYear) {
		this.totalExperienceYear = totalExperienceYear;
	}
	public int getTotalExperienceMonth() {
		return totalExperienceMonth;
	}
	public void setTotalExperienceMonth(int totalExperienceMonth) {
		this.totalExperienceMonth = totalExperienceMonth;
	}
	public Long getAnnualSalaryLakh() {
		return annualSalaryLakh;
	}
	public void setAnnualSalaryLakh(Long annualSalaryLakh) {
		this.annualSalaryLakh = annualSalaryLakh;
	}
	public Long getAnnualSalaryThousand() {
		return annualSalaryThousand;
	}
	public void setAnnualSalaryThousand(Long annualSalaryThousand) {
		this.annualSalaryThousand = annualSalaryThousand;
	}
	public Date getDurationFrom() {
		return durationFrom;
	}
	public void setDurationFrom(Date durationFrom) {
		this.durationFrom = durationFrom;
	}
	public Date getDurationTo() {
		return durationTo;
	}
	public void setDurationTo(Date durationTo) {
		this.durationTo = durationTo;
	}
	@Override
	public String toString() {
		return "CandidateExperienceDeatils [companyName=" + companyName + ", industry=" + industry
				+ ", totalExperienceYear=" + totalExperienceYear + ", totalExperienceMonth=" + totalExperienceMonth
				+ ", annualSalaryLakh=" + annualSalaryLakh + ", annualSalaryThousand=" + annualSalaryThousand
				+ ", durationFrom=" + durationFrom + ", durationTo=" + durationTo + "]";
	}

	
}
