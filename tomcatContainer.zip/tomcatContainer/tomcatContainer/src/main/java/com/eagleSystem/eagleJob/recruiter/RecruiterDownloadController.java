package com.eagleSystem.eagleJob.recruiter;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.eagleSystem.eagleJob.ExcelBuilder;
import com.eagleSystem.eagleJob.dao.JobRepository;
import com.eagleSystem.eagleJob.entity.CandidatePreference;
import com.eagleSystem.eagleJob.entity.JobPost;
import com.eagleSystem.eagleJob.service.RecruiterService;
import com.eagleSystem.eagleJob.util.URLMapper;
import com.eagleSystem.eagleJob.valueObject.CandidateExcelRecords;

@Controller
public class RecruiterDownloadController {

	@Autowired
	RecruiterService recruiterService;

	@Autowired
	JobRepository jobRepository;

	@Autowired
	ServletContext context;

	@RequestMapping(value = URLMapper.RECRUITER_EXCEL_RECORDS, method = RequestMethod.POST)
	public ModelAndView downloadExcelRecords(Authentication auth, @RequestParam("action") String action,
			@RequestParam("jobId") Long jobId, Map<String, Object> model, @RequestParam("id") Long... cadId) {

		List<CandidateExcelRecords> records = recruiterService.downloadExcelRecords(cadId, jobId);
		JobPost jobPost = jobRepository.findOne(jobId);
		model.put("request", records);
		model.put("name", jobPost.getJobProfile());

		return new ModelAndView(new ExcelBuilder(), "request", records);

	}

	@RequestMapping(value = URLMapper.RECRUITER_RESUME_DOWNLOAD, produces = "application/zip", method = RequestMethod.POST)
	public void downloadResume(HttpServletRequest request, HttpServletResponse response, Authentication auth,
			@RequestParam("action") String action, @RequestParam("jobId") Long jobId, Map<String, Object> model,
			@RequestParam("id") Long... cadId) throws IOException {

		Map<Long, CandidatePreference> map;
		response.setContentType("application/zip");
		response.setStatus(HttpServletResponse.SC_OK);
		JobPost jobPost = jobRepository.findOne(jobId);

		try {

			map = recruiterService.downloadResume(Arrays.asList(cadId), jobId);

			if (jobPost != null) {
				String name = jobPost.getJobProfile();
				response.addHeader("Content-Disposition", "attachment; filename=\"" + name + ".zip\"");
			} else {
				throw new Exception("Invalid Job");
			}

			// String downloadFolder = context.getContextPath();

			/*
			 * File file = new File(downloadFolder + File.separator + "Resume" +
			 * File.separator + "9865327845");
			 * 
			 * if (file.exists()) { String mimeType = context.getMimeType(file.getPath());
			 * 
			 * if (mimeType == null) { mimeType = "application/octet-stream"; }
			 * 
			 * response.setContentType(mimeType); response.addHeader("Content-Disposition",
			 * "attachment; NaukriJob"); response.setContentLength((int) file.length());
			 * 
			 * OutputStream os = response.getOutputStream(); FileInputStream fis = new
			 * FileInputStream(file); byte[] buffer = new byte[1024]; int b = -1;
			 * 
			 * while ((b = fis.read(buffer)) != -1) { os.write(buffer, 0, b); }
			 * 
			 * fis.close(); os.close();
			 */
			List<String> srcFiles = new ArrayList<String>();

			for (Long id : Arrays.asList(cadId)) {
				srcFiles.add("c:" + File.separator + map.get(id).getResume());
			}

			// File file = new File(context.getRealPath("/WEB-INF/downloads") +
			// File.separator + "Resume" + File.separator + "9865327845");
			OutputStream fos = response.getOutputStream();
			// FileOutputStream fos = new FileOutputStream("D:/NaukriJob.zip");
			ZipOutputStream zipOut = new ZipOutputStream(fos);
			for (String srcFile : srcFiles) {
				File fileToZip = new File(srcFile);
				if (!(fileToZip.exists())) {
					System.out.println("file not found");
				}

				FileInputStream fis = new FileInputStream(fileToZip);
				ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
				zipOut.putNextEntry(zipEntry);
				System.out.println(zipEntry);
				byte[] bytes = new byte[8096];
				int length;
				while ((length = fis.read(bytes)) >= 0) {
					zipOut.write(bytes, 0, length);

				}
				fis.close();
			}
			zipOut.close();
			fos.close();

			/*
			 * } else { System.out.println("Requested " + id + " file not found!!"); }
			 */

		} catch (IOException e) {
			System.out.println("Error:- " + e.getMessage());
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	@RequestMapping(value = "/recruiterDownload", method = RequestMethod.POST)
	public ModelAndView download(HttpServletRequest request, HttpServletResponse response, Authentication auth,
			@RequestParam("action") String action, @RequestParam("jobId") Long jobId, Map<String, Object> model,
			@RequestParam("id") Long... cadId) {

		ModelAndView mav = null;

		try {

			if (action.contains("Excel")) {
				mav = downloadExcelRecords(auth, action, jobId, model, cadId);

			} else {
				downloadResume(request, response, auth, action, jobId, model, cadId);
			}
		} catch (IOException e) {
			System.out.println("Error:- " + e.getMessage());
		}
		return mav;
	}

}
