package com.eagleSystem.eagleJob;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import com.eagleSystem.eagleJob.entity.ClientNaukriExcelRecord;

public class BusinessClientNaukri extends AbstractXlsView  {
	@Override
	protected void buildExcelDocument(Map model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String name = (String) model.get("industry");

		// change the file name
		response.setHeader("Content-Disposition", "attachment; filename=\""+ name + ".xls\"");

		@SuppressWarnings("unchecked")
		List<ClientNaukriExcelRecord> records = (List<ClientNaukriExcelRecord>) model.get("records");

		// create excel xls sheet
		Sheet sheet = workbook.createSheet("Job Post Response");

		// create header row
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("Sr. no.");
		header.createCell(1).setCellValue("Name");
		header.createCell(2).setCellValue("Gender");
		header.createCell(3).setCellValue("Postal_Address");
		header.createCell(4).setCellValue("Contact Number");
		header.createCell(5).setCellValue("Telephone");
		header.createCell(6).setCellValue("DOB");
		header.createCell(7).setCellValue("Email Id");
		header.createCell(8).setCellValue("Experience");
		header.createCell(9).setCellValue("Status");
		header.createCell(10).setCellValue("Resume_Title");
		header.createCell(11).setCellValue("Keyskill");
		header.createCell(12).setCellValue("FunctionalArea");	
		header.createCell(13).setCellValue("Current Location");
		header.createCell(14).setCellValue("Preferred_Locations");
		header.createCell(15).setCellValue("Current_Employer");
		header.createCell(16).setCellValue("Current_Designation");
		header.createCell(17).setCellValue("AnnualSalary");
		header.createCell(18).setCellValue("UG_Course");
		header.createCell(19).setCellValue("UG_Specialization");
		header.createCell(20).setCellValue("UG_Institute");
		header.createCell(21).setCellValue("Job_Category");
		
		int rowCount = 0;
		for (ClientNaukriExcelRecord course : records) {
			Row courseRow = sheet.createRow(++rowCount);
			System.out.println(rowCount);
			courseRow.createCell(0).setCellValue(rowCount);
			courseRow.createCell(1).setCellValue(course.getName());
			courseRow.createCell(2).setCellValue(course.getGender());
			courseRow.createCell(3).setCellValue(course.getPostalAddress());
			courseRow.createCell(4).setCellValue(course.getMobile());
			courseRow.createCell(5).setCellValue(course.getTelephone());
			courseRow.createCell(6).setCellValue(course.getDob());
			courseRow.createCell(7).setCellValue(course.getEmailID());
			courseRow.createCell(8).setCellValue(course.getTotalExperience());
			courseRow.createCell(9).setCellValue(course.getStatus());
			courseRow.createCell(10).setCellValue(course.getResumeTitle());
			courseRow.createCell(11).setCellValue(course.getKeySkills());
			courseRow.createCell(12).setCellValue(course.getFunctionalArea());
			courseRow.createCell(13).setCellValue(course.getCurrentLocation());
			courseRow.createCell(14).setCellValue(course.getPreferredLocations());
			courseRow.createCell(15).setCellValue(course.getCurrentEmployer());
			courseRow.createCell(16).setCellValue(course.getCurrentDesignation());
			courseRow.createCell(17).setCellValue(course.getAnnualSalary());
			courseRow.createCell(18).setCellValue(course.getUgCourse());
			courseRow.createCell(19).setCellValue(course.getUgSpecialization());
			courseRow.createCell(20).setCellValue(course.getUgInstitute());
			courseRow.createCell(21).setCellValue(course.getJobCategory());
		}

	}

}
