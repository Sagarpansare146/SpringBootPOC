package com.eagleSystem.eagleJob.aspect.bdm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.dao.AccountRepository;
import com.eagleSystem.eagleJob.dao.BdmDownloadRecordRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.BdmDownloadRecord;

@Aspect
@Component
public class BdmNaukriJobExcelDownloadAspect {
	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	BdmDownloadRecordRepository bdmDownloadRecordRepository;
	
	@Around("execution(* com.eagleSystem.eagleJob.service.RecruiterServiceImpl.bdmDownloadExcelRecords(..))")
	public Object checkBeforeDownload(ProceedingJoinPoint pjp) throws Throwable {

		System.out.println("excel aspect");

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		Account account = accountRepository.findByUsername(auth.getName());

	//	DbCustomerEntity dbCustomerEntity = dbCustomerRepository.findByUsername(auth.getName());
				
		Object obj[] = pjp.getArgs();
		Long[] cadId = (Long[]) obj[0];
		List<Long> lcadId = new ArrayList<>();
		
	/*
		Long limit = dbCustomerEntity.getExcelLimit();
		Long oldDownloadedCount = dbCustomerEntity.getExcelDataUsed();
		Long canDownloadCount = limit - oldDownloadedCount;
		Long count = (long) cadId.length;
	*/	
		
		Long limit = account.getExcelLimit();
		Long oldDownloadedCount = bdmDownloadRecordRepository.findByBdm(auth.getName()).stream().filter(e -> e.getDownloadExcelCount() != 0)
				.filter(e -> e.getDownloadDate().getDate() == new Date().getDate() ).mapToLong(e -> e.getDownloadExcelCount()).sum();
		Long oldDownloadedCount1 = bdmDownloadRecordRepository.findByBdm(auth.getName()).stream().filter(e -> e.getDownloadResumeCount() != 0)
				.filter(e -> e.getDownloadDate().getDate() == new Date().getDate() ).mapToLong(e -> e.getDownloadResumeCount()).sum();
		
		Long canDownloadCount = limit - oldDownloadedCount;
		int count = cadId.length;
		
		int downloadedCount = 0;
		if (canDownloadCount == 0 && oldDownloadedCount == limit) {
			throw new Exception("You reached your download Limit");
		} else if (canDownloadCount <= count) {

			lcadId = Arrays.stream(cadId).limit(canDownloadCount).collect(Collectors.toList());
			downloadedCount = lcadId.size();

		} else {
			downloadedCount = count;
		}

		
		Object ret = pjp.proceed();
		
		
		BdmDownloadRecord bdmDownloadRecord = new BdmDownloadRecord();
		
		bdmDownloadRecord.setBdm(auth.getName());
		bdmDownloadRecord.setCurrentExcelCount(oldDownloadedCount + downloadedCount);
		bdmDownloadRecord.setCurrentResumeCount(oldDownloadedCount1);
		bdmDownloadRecord.setDownloadDate(new Date());
		bdmDownloadRecord.setDownloadExcelCount((long) downloadedCount);
		bdmDownloadRecord.setDownloadResumeCount(0l);
		
		bdmDownloadRecordRepository.save(bdmDownloadRecord);
		
		
		/*
		dbCustomerEntity.setExcelDataUsed(oldDownloadedCount + downloadedCount);
		
		dbCustomerEntity = dbCustomerRepository.save(dbCustomerEntity);
		
		CustomerDownloadRecords custRecord = new CustomerDownloadRecords();
		
		custRecord.setCustomer(auth.getName());
		custRecord.setCurrentExcelCount(dbCustomerEntity.getExcelDataUsed());
		custRecord.setDownloadExcelCount(downloadedCount);
		custRecord.setDownloadDate(new Date());
		
		customerDownloadRecordsRepository.save(custRecord);
		*/
		return ret;

	}

}
