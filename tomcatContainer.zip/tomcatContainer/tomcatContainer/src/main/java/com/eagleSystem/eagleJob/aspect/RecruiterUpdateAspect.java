package com.eagleSystem.eagleJob.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.springframework.beans.factory.annotation.Autowired;

import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;

public class RecruiterUpdateAspect extends AbstractAppPointcut {

	@Autowired
	RecruiterRepository RecruiterRepo;

	@Around("RecRegpointcut()")
	public Object cadUpdateCheck(ProceedingJoinPoint pjp) throws Throwable {
		System.out.println("check rec");
		Recruiter recruiter = RecruiterRepo
				.findOne(((RecruiterRegistrationRequest) (pjp.getArgs())[0]).getRecruiterId());

		if (!(recruiter == null)) {
			System.out.println(recruiter.getName());
			throw new Exception("Recruiter not Registered");
		}

		return pjp.proceed();

	}

}
