package com.eagleSystem.eagleJob.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CANDIDATE_APPLICATION")
public class CandidateApplication implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Id;

	@ManyToOne
	@JoinColumn(name = "CANDIDATE_ID")
	private Candidate candidate;

	@ManyToOne
	@JoinColumn(name = "JOB_POST")
	private JobPost jobPost;

	@Column(name = "APPLICATION_STATUS")
	private String applicationStatus;

	@Column(name = "APPLIED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date appliedOn;

	@Column(name = "RECRUITER_ACTION")
	@Temporal(TemporalType.TIMESTAMP)
	private Date recruiterActionOn;


	public CandidateApplication() {
	}
	
	
	public Long getId() {
		return Id;
	}


	public void setId(Long id) {
		Id = id;
	}

	public Candidate getCandidate() {
		return candidate;
	}

	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public Date getAppliedOn() {
		return appliedOn;
	}

	public void setAppliedOn(Date appliedOn) {
		this.appliedOn = appliedOn;
	}


	public JobPost getJobPost() {
		return jobPost;
	}


	public void setJobPost(JobPost jobPost) {
		this.jobPost = jobPost;
	}


	public Date getRecruiterActionOn() {
		return recruiterActionOn;
	}


	public void setRecruiterActionOn(Date recruiterActionOn) {
		this.recruiterActionOn = recruiterActionOn;
	}


	@Override
	public String toString() {
		return "CandidateApplication [Id=" + Id + ", candidate=" + candidate + ", jobPost=" + jobPost
				+ ", applicationStatus=" + applicationStatus + ", appliedOn=" + appliedOn + ", recruiterActionOn="
				+ recruiterActionOn + "]";
	}


}