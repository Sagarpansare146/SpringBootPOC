package com.eagleSystem.eagleJob.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagleSystem.eagleJob.entity.RecruiterDownloadRecords;
import java.lang.String;
import java.util.List;

public interface RecruiterDownloadRecordsRepository extends JpaRepository<RecruiterDownloadRecords, Long>{

	List<RecruiterDownloadRecords> findByRecruiter(String recruiter);
}
