package com.eagleSystem.eagleJob.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.dao.BoosterPlanRepository;
import com.eagleSystem.eagleJob.dao.JobRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.BoosterPlan;
import com.eagleSystem.eagleJob.entity.JobPost;
import com.eagleSystem.eagleJob.entity.MasterPlan;
import com.eagleSystem.eagleJob.entity.Recruiter;

@Aspect
@Component
public class ExcelRecordAspect {

	@Autowired
	JobRepository jobRepository;

	@Autowired
	RecruiterRepository recruiterRepository;

	@Autowired
	BoosterPlanRepository bPlanRepo;

	@Around("execution(* com.eagleSystem.eagleJob.service.RecruiterServiceImpl.downloadExcelRecords(..))")
	public Object checkBeforeDownload(ProceedingJoinPoint pjp) throws Throwable {

		System.out.println("excel aspect");
		int records = 0;
		boolean flag = true;

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		Recruiter rec = recruiterRepository.findByUsername(auth.getName());

		BoosterPlan bp = rec.getBoosterPlan();
		MasterPlan mp = rec.getMasterPlan();

		int fixedLimit = 0;

		if (bp != null)
			fixedLimit = mp.getExcelRecordsLimit() + bp.getExcelRecordsLimit();

		fixedLimit = mp.getExcelRecordsLimit();

		Object obj[] = pjp.getArgs();
		Long[] cadId = (Long[]) obj[0];
		Long jobId = (Long) obj[1];

		JobPost jobPost = jobRepository.findOne(jobId);

		if (jobPost != null)
			records = cadId.length + jobPost.getExcelRecordsDownloadCount();

		System.out.println("fixed Limit is " + fixedLimit);
		System.out.println("records num " + records);

		if (records >= fixedLimit && records != 0) {
			flag = false;
			throw new Exception("You reached your download Limit");
		} else if (records == 0) {
			flag = false;
			throw new Exception("NO Records Available");
		}

		Object ret = pjp.proceed();

		if (flag) {
			jobPost.setExcelRecordsDownloadCount(records);
			jobRepository.save(jobPost);
		}

		return ret;
	}

}
