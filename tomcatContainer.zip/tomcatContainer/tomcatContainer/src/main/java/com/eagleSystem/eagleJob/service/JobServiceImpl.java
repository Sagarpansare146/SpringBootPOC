package com.eagleSystem.eagleJob.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eagleSystem.eagleJob.bussinessObject.JobBO;
import com.eagleSystem.eagleJob.dao.CandidateApplicationRepository;
import com.eagleSystem.eagleJob.dao.CandidatePrefRepository;
import com.eagleSystem.eagleJob.dao.CandidateRepository;
import com.eagleSystem.eagleJob.dao.JobRepository;
import com.eagleSystem.eagleJob.dao.QualificationRepository;
import com.eagleSystem.eagleJob.dao.RecruiterRepository;
import com.eagleSystem.eagleJob.entity.JobPost;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.util.JobBOPrepareUtil;
import com.eagleSystem.eagleJob.util.JobModelPrepareUtil;
import com.eagleSystem.eagleJob.valueObject.JobPostRequest;
import com.eagleSystem.eagleJob.valueObject.ListJobForCandidate;
import com.eagleSystem.eagleJob.valueObject.ListJobRequest;

@Transactional
@Service
public class JobServiceImpl implements JobService {

	@Autowired
	JobRepository jobRepository;
	
	@Autowired
	RecruiterRepository recruiterRepository;
	
	@Autowired
	CandidateRepository CandidateRepository;
	
	@Autowired
	CandidateService candidateService;
	
	@Autowired
	CandidateApplicationRepository candidateApplicationRepository;
	
	@Autowired
	JobBOPrepareUtil jobBOPrepareUtil;
	
	@Autowired
	JobModelPrepareUtil jobModelPrepareUtil;
	
	@Autowired
	CandidatePrefRepository canPrefRepo;
	

	@Autowired
	QualificationRepository qualRepo;

	
	public boolean postNewJob(String username, JobPostRequest request) {
	
		boolean flag = true;
		
		Recruiter recruiter = recruiterRepository.findByUsername(username);
		
		flag = postByRecruiter(recruiter, request);
		
		return flag;
	}
	
	public boolean postByRecruiter(Recruiter recruiter, JobPostRequest request) {

		boolean flag = true;

		JobBO jobBO = jobBOPrepareUtil.prepareJobBO(request);

		JobPost jobPost = jobModelPrepareUtil.prepareJobPost(jobBO);
		jobPost.setRecruiter(recruiter);

		jobPost.setExcelRecordsDownloadCount(0);
		jobPost.setResumeDownloadCount(0);
		jobPost.setApplicationCount(0l);

		try {
		jobRepository.save(jobPost);
		}catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}

	public JobBO getJobBOById(Long id) {
		
		return jobBOPrepareUtil.prepareJobBO(jobRepository.findOne(id));
		
	}
	
	public boolean updateJob(JobBO jobBO) {
		
		boolean flag = false;
			JobPost jobPost = jobModelPrepareUtil.prepareJobPost(jobBO);
				System.out.println(jobPost);
		jobRepository.save(jobPost);
		System.out.println(jobBO.getStatus());
		flag = true;
		
		return flag;
		
	}
	
	@Override
	public Map<String, Object> postedJobByRecruiter(Long recruiterId, int page, int pageSize) {

		Pageable pageRequest = new PageRequest(page, pageSize, Sort.Direction.DESC, "postedOn"); 
		
		Page<JobPost> pJobPost = jobRepository.findByRecruiterIdOrderByPostedOnDesc(recruiterId, pageRequest);
		
		List<JobPost> jobPost = new ArrayList<>();
		jobPost = pJobPost.getContent();
		Map<String, Object> map = new HashMap<>();
		
		System.out.println(jobPost);
		
		List<JobBO> jobs = new ArrayList<JobBO>();
		
		for (JobPost jp : jobPost) {
			
			JobBO job = jobBOPrepareUtil.prepareJobBO(jp);
			jobs.add(job);
		}
		
		map.put("request", prepareListJobRequest(jobs));
		map.put("totalCount", (pJobPost != null ? pJobPost.getTotalElements() : 0));
		map.put("totalPages", (pJobPost != null ? pJobPost.getTotalPages() : 0));
		
	//	System.out.println(prepareListJobRequest(jobs));
		return map;
	}


	@Override
	public Map<String, Object> allJobs(int page, int pageSize) {
	
		boolean isDeleted = false;
		Map<String, Object> map = new HashMap<>();
		Pageable request =
	            new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "postedOn");
		
		Page<JobPost> pjp = jobRepository.findByIsDeletedOrderByPostedOnDesc(isDeleted, request);
		List<ListJobForCandidate> jobs = new ArrayList<ListJobForCandidate>();
		
		List<JobPost> jobPost = pjp.getContent();
		
		int current = pjp.getNumber() + 1;
	    int begin = Math.max(1, current - 5);
	    int end = Math.min(begin + 10, pjp.getTotalPages());
	    int totalPages = pjp.getTotalPages();
		
		for (JobPost jp : jobPost) {
			
			JobBO job = jobBOPrepareUtil.prepareJobBO(jp);
			ListJobForCandidate j = prepareListJobForCand(job);
			jobs.add(j);
		}
		
		map.put("current", current);
		map.put("begin", begin);
		map.put("end", end);
		map.put("totalPages", totalPages);
		map.put("jobs", jobs);
		
		return map;
	}



	@Override
	public List<ListJobRequest> activeJobsByRercruiter(Long recruiterId, Boolean isDeleted) {

		
		List<JobPost> jobPost = jobRepository.findByRecruiterIdAndIsDeletedOrderByPostedOnDesc(recruiterId, isDeleted);
		List<JobBO> jobs = new ArrayList<JobBO>();
		
		for (JobPost jp : jobPost) {
			
			JobBO job = jobBOPrepareUtil.prepareJobBO(jp);
			jobs.add(job);
		}
		
		return prepareListJobRequest(jobs);
	}



/*	@Override
	public List<ListJobRequest> allActiveJobs(boolean isDeleted) {

		List<JobPost> jobPost = jobRepository.findByIsDeletedOrderByPostedOnDesc(isDeleted);
		List<JobBO> jobs = new ArrayList<JobBO>();
		
		for (JobPost jp : jobPost) {
			
			JobBO job = jobBOPrepareUtil.prepareJobBO(jp);
			jobs.add(job);
		}
		
		return prepareListJobRequest(jobs);
	}

*/
	public Map<String, Object> searchedJob(String keySkill, String location, String jobCategory, String functionalArea, int page, int pageSize) {

		Map<String, Object> map = new HashMap<>();
		
		String skill[] = new String[10];
				
		skill = keySkill.split(",");
		
		String a,b,c;
		
		int i = 0;
		for(String s: skill) {
			
			if(s.equalsIgnoreCase("") || s == null) {
				skill[i] = "";
			}
			else {
				skill[i] = s;
			}
			System.out.println(s);
			i++;
		}
		
		a = skill[0];
		
		try {
			b = skill[1];
		}catch(Exception e) {
			b = "";
		}
		
		try {
			c = skill[2];
		}catch(Exception e) {
			c = "";
		}
		
		Pageable request =
	            new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "postedOn");
		
		System.out.println(a + b + c);
		Page<JobPost> pjp = null;
		
		if(b.equalsIgnoreCase("")) {
		pjp = jobRepository.findByKeySkillContainingAndJobProfileContainingAndCityContainingAndIsDeleted(a, a, location, false, request);
		}else if(c.equalsIgnoreCase("")){
			pjp = jobRepository.getJobIds1(a, b, location, request);
		}else{
			pjp = jobRepository.getJobIds2(a, b, c, location, request);
		}
		
		List<JobPost> jobPost = pjp.getContent();
		
		int current = pjp.getNumber() + 1;
	    int begin = Math.max(1, current - 5);
	    int end = Math.min(begin + 10, pjp.getTotalPages());
	    int totalPages = pjp.getTotalPages();
		
		
		List<ListJobForCandidate> jobs = new ArrayList<ListJobForCandidate>();
		
		for (JobPost jp : jobPost) {
			
			JobBO job = jobBOPrepareUtil.prepareJobBO(jp);
			ListJobForCandidate j = prepareListJobForCand(job);
			jobs.add(j);
		}
		
		map.put("current", current);
		map.put("begin", begin);
		map.put("end", end);
		map.put("totalPages", totalPages);
		map.put("jobs", jobs);
		
		return map;
		
		
	}
	
	public boolean deletePostedJob(Long jobId, Long recruiterId) {
		boolean flag = true;
		
		
		JobPost jobPost = jobRepository.findByIdAndRecruiterId(jobId, recruiterId);
		
		jobPost.setUpdatedOn(new Date());
		jobPost.setStatus("Deactive");
		jobPost.setDeleted(true);
		
		try {
			
		jobRepository.save(jobPost);

		}catch(Exception e) {
			e.printStackTrace();
			flag = false;
		}
		
		return flag;
	}
	
	public Map<String, Object> getJobForYou(Long candidateId, String keySkill, String location, String jobCategory, String functionalArea, String[] topCities, int page, int pageSize) {
		
		Map<String, Object> map = new HashMap<>();
		String skill[] = new String[10];
		
		skill = keySkill.split(",");
		
		String a,b,c;
		
		int i = 0;
		for(String s: skill) {
			
			if(s.equalsIgnoreCase("") || s == null) {
				skill[i] = "";
			}
			else {
				skill[i] = s;
			}
			System.out.println(s);
			i++;
		}
		
		a = skill[0];
		
		try {
			b = skill[1];
		}catch(Exception e) {
			b = "";
		}
		
		try {
			c = skill[2];
		}catch(Exception e) {
			c = "";
		}
		
		String[] category = jobCategory.split(",");
		
		System.out.println(a + b + c);
		System.out.println(topCities.length);
		
		Pageable request =
	            new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "postedOn");
		
		Page<JobPost> pjp = null;
		switch (category.length) {
		case 1:
			switch (topCities.length) {

			case 1:
				pjp = jobRepository.getJobforYou(category[0], category[0], topCities[0], topCities[0], topCities[0], request);
				break;

			case 2:
				pjp = jobRepository.getJobforYou(category[0], category[0], topCities[0], topCities[1], topCities[1], request);

				break;

			case 3:
				pjp = jobRepository.getJobforYou(category[0], category[0], topCities[0], topCities[1], topCities[2], request);
				
				break;

			default:
				break;
			}
			break;

		case 2:
			switch (topCities.length) {

			case 1:
				pjp = jobRepository.getJobforYou(category[0], category[1], topCities[0], topCities[0], topCities[0], request);
				
				break;

			case 2:
				pjp = jobRepository.getJobforYou(category[0], category[1], topCities[0], topCities[1], topCities[1], request);
				break;

			case 3:
				pjp = jobRepository.getJobforYou(category[0], category[1], topCities[0], topCities[1], topCities[2], request);

				break;

			default:
				break;
			}
			break;
		
	/*	case 3:
			switch (topCities.length) {

			case 1:
				
				break;

			case 2:
				
				break;

			case 3:
				
				break;

			default:
				break;
			}
			break;*/
		
		default:
		
			break;

		}		
		if(category.length <=1 && topCities.length <= 1) {
			pjp = jobRepository.getJobforYou(category[0], category[0], topCities[0], topCities[0], topCities[0], request);
		}
		else if(category.length <=1 && topCities.length == 2) {
			System.out.println("query");
			pjp = jobRepository.getJobforYou(category[0], category[0], topCities[0], topCities[1], topCities[1], request);
		}
		else if(category.length <=1 && topCities.length > 2) {
			System.out.println("query");
			pjp = jobRepository.getJobforYou(category[0], category[0], topCities[0], topCities[1], topCities[2], request);
		}
		else if(category.length >1 && topCities.length > 2) {
			System.out.println("query1");
			pjp = jobRepository.getJobforYou(category[0], category[1], topCities[0], topCities[1], topCities[2], request);
		}
		else if(category.length >1 && topCities.length > 2) {
			pjp = jobRepository.getJobforYou(category[0], category[1], topCities[0], topCities[1], topCities[2], request);
		}
		 
		List<ListJobForCandidate> jobs1;
		
		List<Long> jobIds = new ArrayList<Long>();
		
		jobIds = candidateApplicationRepository.getAllAppliedJobIds(candidateId);
		
		System.out.println(jobIds);
		
		
		
		List<JobPost> jobPost = pjp.getContent();
		
		int current = pjp.getNumber() + 1;
	    int begin = Math.max(1, current - 5);
	    int end = Math.min(begin + 10, pjp.getTotalPages());
	    int totalPages = pjp.getTotalPages();
		
		
		List<ListJobForCandidate> jobs = new ArrayList<>();
		for (JobPost jp : jobPost) {
			
			JobBO jobBO = jobBOPrepareUtil.prepareJobBO(jp);
			
			ListJobForCandidate jobRequest = prepareListJobForCand(jobBO);
			
			if(!(jobIds.contains(jobRequest.getPostId())))
			jobs.add(jobRequest);
		}
		
		map.put("current", current);
		map.put("begin", begin);
		map.put("end", end);
		map.put("totalPages", totalPages);
		map.put("jobs", jobs);
		return map;
		
		
	}
	
	public Map<String, Object> getJobByCity(String location, int page, int pageSize) {
		
		boolean isDeleted = false;
		
		Pageable request =
	            new PageRequest(page - 1, pageSize, Sort.Direction.DESC, "postedOn");
		
		Page<JobPost> pjp = jobRepository.findByCityAndIsDeletedOrderByPostedOnDesc(location, isDeleted, request);
		
		Map<String, Object> map = new HashMap<>();
		
		List<JobPost> jobPost = pjp.getContent();
	
		int current = pjp.getNumber() + 1;
	    int begin = Math.max(1, current - 5);
	    int end = Math.min(begin + 10, pjp.getTotalPages());
	    int totalPages = pjp.getTotalPages();
		
		List<ListJobForCandidate> jobs = new ArrayList<ListJobForCandidate>();
		
		
		for (JobPost jp : jobPost) {
			
			JobBO job = jobBOPrepareUtil.prepareJobBO(jp);
			ListJobForCandidate j = prepareListJobForCand(job);
			jobs.add(j);
		}
		
		
		map.put("current", current);
		map.put("begin", begin);
		map.put("end", end);
		map.put("totalPages", totalPages);
		map.put("jobs", jobs);
		return map;
	
	}
	
	public ListJobForCandidate prepareListJobForCand(JobBO jobBO) {
		
		ListJobForCandidate jobRequest = new ListJobForCandidate();
		
		jobRequest.setPostId(jobBO.getPostId());
		jobRequest.setJobProfile(jobBO.getJobProfile());
		jobRequest.setExperienceFrom(jobBO.getExperienceFrom());
		jobRequest.setExperienceTo(jobBO.getExperienceTo());
		jobRequest.setCompanyName(jobBO.getCompanyName());
		jobRequest.setLocation(jobBO.getCity());
		jobRequest.setPostedOn(jobBO.getPostedOn());
		
		
	/*	String keySkill1 = "";	
			for (String ks : jobBO.getKeySkill()) {
				keySkill1 = keySkill1 + ks;
			}
	*/
		jobRequest.setKeySkill(jobBO.getKeySkill());
		
		return jobRequest;
	}
	
	
	public List<ListJobRequest> prepareListJobRequest(List<JobBO> jobBO) {
		
		List<ListJobRequest> jobs = new ArrayList<ListJobRequest>();
		
		for (JobBO jobReq : jobBO ) {
			
			ListJobRequest job = jobBOPrepareUtil.PrepareListJobRequest(jobReq);
			
			jobs.add(job);
		}
		
		return jobs;
	}
	
	
	public List<ListJobForCandidate> recommondedJobs(Date d1, Date d2) {
		List<JobPost> job = jobRepository.findByPostedOnGreaterThan(d2);
		List<Long> ids = new ArrayList<>();
		
		for(JobPost jp : job) {
			ids.add(jp.getId());
		}
		
		List<ListJobForCandidate> jobs = prepareObject(job, ids);
		return jobs;
	}
	
	
	
public List<ListJobForCandidate> prepareObject(List<JobPost> jobPost, List<Long> jobIds) {
		
		
		List<ListJobForCandidate> jobs1 = new ArrayList<>();
		for (JobPost jp : jobPost) {
						
			JobBO jobBO = jobBOPrepareUtil.prepareJobBO(jp);
			
			ListJobForCandidate jobRequest = prepareListJobForCand(jobBO);
			
			for(Long id : jobIds) {
				JobPost jp1 = jobRepository.findOne(id);
				JobBO jobBO1 = jobBOPrepareUtil.prepareJobBO(jp1);
				
				ListJobForCandidate jobRequest1 = prepareListJobForCand(jobBO1);
				
				jobs1.add(jobRequest1);
				
				if(!(jobBO.getPostId() == id)) {
					jobRequest.setApplied(false);
				}else {
				jobRequest.setApplied(true);
				}
			}
			
			
		}
		
		return jobs1;
	}

	/*	@Override
	public Map<String, Object> getJobForYou(String inputSearch, String location, Integer page) {
	
		Pageable pageable = new PageRequest(0, 10,Sort.Direction.ASC, "title");
		
		List<Long> ids = caRepository.findCandidateIdsByJobPost(jobId);
		Map<String, Object> mapIds = new ConcurrentHashMap<String, Object>();
		mapIds.put("ids", ids);
		
		int totalPages = (ids.size()/10);
		System.out.println(totalPages);
		
		mapIds.put("totalPages", totalPages);
		
		return mapIds;
	}
*/
	

	public JobBOPrepareUtil getJobBOPrepareUtil() {
		return jobBOPrepareUtil;
	}



	public JobRepository getJobRepository() {
		return jobRepository;
	}



	public void setJobRepository(JobRepository jobRepository) {
		this.jobRepository = jobRepository;
	}



	public void setJobBOPrepareUtil(JobBOPrepareUtil jobBOPrepareUtil) {
		this.jobBOPrepareUtil = jobBOPrepareUtil;
	}



	public JobModelPrepareUtil getJobModelPrepareUtil() {
		return jobModelPrepareUtil;
	}



	public void setJobModelPrepareUtil(JobModelPrepareUtil jobModelPrepareUtil) {
		this.jobModelPrepareUtil = jobModelPrepareUtil;
	}



	public CandidateRepository getCandidateRepository() {
		return CandidateRepository;
	}



	public void setCandidateRepository(CandidateRepository candidateRepository) {
		CandidateRepository = candidateRepository;
	}



	public CandidateApplicationRepository getCandidateApplicationRepository() {
		return candidateApplicationRepository;
	}



	public void setCandidateApplicationRepository(CandidateApplicationRepository candidateApplicationRepository) {
		this.candidateApplicationRepository = candidateApplicationRepository;
	}
	
}
