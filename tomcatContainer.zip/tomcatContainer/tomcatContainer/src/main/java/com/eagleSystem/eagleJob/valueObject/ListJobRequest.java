package com.eagleSystem.eagleJob.valueObject;

import java.util.Date;

public class ListJobRequest {

	private Long postId;
	private String jobProfile = "";
	private Date postedOn = new Date();
	private String Status = "";
	private Long responseCount = 0l;
	private String location;
	
	public ListJobRequest() {
		super();
	}


	public Long getPostId() {
		return postId;
	}


	public void setPostId(Long postId) {
		this.postId = postId;
	}


	public String getJobProfile() {
		return jobProfile;
	}


	public void setJobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}


	public Date getPostedOn() {
		return postedOn;
	}


	public void setPostedOn(Date postedOn) {
		this.postedOn = postedOn;
	}


	public String getStatus() {
		return Status;
	}


	public void setStatus(String status) {
		Status = status;
	}


	public Long getResponseCount() {
		return responseCount;
	}


	public void setResponseCount(Long responseCount) {
		this.responseCount = responseCount;
	}


	
	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	@Override
	public String toString() {
		return "ListJobRequest [postId=" + postId + ", jobProfile=" + jobProfile + ", postedOn=" + postedOn
				+ ", Status=" + Status + ", responseCount=" + responseCount + ", location=" + location + "]";
	}


	
}
