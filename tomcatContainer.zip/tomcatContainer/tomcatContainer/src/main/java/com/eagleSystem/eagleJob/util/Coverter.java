package com.eagleSystem.eagleJob.util;

import com.eagleSystem.eagleJob.entity.SubAdmin;
import com.eagleSystem.eagleJob.valueObject.CreateSubadmin;

public class Coverter {
	
	public SubAdmin converSubAdmin(CreateSubadmin subadmin) {
		
		SubAdmin sbentity = new SubAdmin();
		
		if(subadmin.getId() != 0)
		sbentity.setId(subadmin.getId());
		sbentity.setName(subadmin.getName());
		sbentity.setContactNumber(subadmin.getContactNumber());
		sbentity.setEmail(subadmin.getEmail());
		sbentity.setLocation(subadmin.getLocation());
		sbentity.setUsername(subadmin.getUsername());
		sbentity.setPassword(subadmin.getPassword());
		return sbentity;
	
	
	
	}

}
