package com.eagleSystem.eagleJob.valueObject;

public class CandidateExcelRecords {

	private Long id;
	private String name = "";
	private String keySkill = "";
	private String experience ="";
	private String month ="";
	private String location = "";
	private Long annualCTC;
	
	private String email = "";
	private Long contactNumber;
	private String candidateCity = "";
	private String gender = "";
	private String degree = "";
	private String specilization = "";
	private String university = "";
	private Integer passout;
	private Float percentage;
	private String jobCategory = "";

		
	public CandidateExcelRecords() {
		super();
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getKeySkill() {
		return keySkill;
	}


	public void setKeySkill(String keySkill) {
		this.keySkill = keySkill;
	}

	

	public String getExperience() {
		return experience;
	}


	public void setExperience(String experience) {
		this.experience = experience;
	}


	public String getMonth() {
		return month;
	}


	public void setMonth(String month) {
		this.month = month;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public Long getAnnualCTC() {
		return annualCTC;
	}


	public void setAnnualCTC(Long annualCTC) {
		this.annualCTC = annualCTC;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Long getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}


	public String getCandidateCity() {
		return candidateCity;
	}


	public void setCandidateCity(String candidateCity) {
		this.candidateCity = candidateCity;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getDegree() {
		return degree;
	}


	public void setDegree(String degree) {
		this.degree = degree;
	}


	public String getSpecilization() {
		return specilization;
	}


	public void setSpecilization(String specilization) {
		this.specilization = specilization;
	}


	public String getUniversity() {
		return university;
	}


	public void setUniversity(String university) {
		this.university = university;
	}


	public Integer getPassout() {
		return passout;
	}


	public void setPassout(Integer passout) {
		this.passout = passout;
	}


	public Float getPercentage() {
		return percentage;
	}


	public void setPercentage(Float percentage) {
		this.percentage = percentage;
	}


	public String getJobCategory() {
		return jobCategory;
	}


	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}


	@Override
	public String toString() {
		return "CandidateExcelRecords [id=" + id + ", name=" + name + ", keySkill=" + keySkill + ", experience="
				+ experience + ", month=" + month + ", location=" + location + ", annualCTC=" + annualCTC + ", email="
				+ email + ", contactNumber=" + contactNumber + ", candidateCity=" + candidateCity + ", gender=" + gender
				+ ", degree=" + degree + ", specilization=" + specilization + ", university=" + university
				+ ", passout=" + passout + ", percentage=" + percentage + ", jobCategory=" + jobCategory + "]";
	}

	
	
}
