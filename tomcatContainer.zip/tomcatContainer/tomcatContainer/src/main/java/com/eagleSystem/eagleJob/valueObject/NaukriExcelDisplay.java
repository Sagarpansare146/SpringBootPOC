package com.eagleSystem.eagleJob.valueObject;

public class NaukriExcelDisplay {


	private Long id;
	private String name;
	private String totalExpInYear;
	private String location;
	private String annualSalary;
	private String jobCategory;
	private String keySkill;
	private String qualification;
	private String preferredLocations;
	private String currentlocation;
	private String gender;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getTotalExpInYear() {
		return totalExpInYear;
	}
	public void setTotalExpInYear(String totalExpInYear) {
		this.totalExpInYear = totalExpInYear;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getJobCategory() {
		return jobCategory;
	}
	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}
	public String getKeySkill() {
		return keySkill;
	}
	public void setKeySkill(String keySkill) {
		this.keySkill = keySkill;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getPreferredLocations() {
		return preferredLocations;
	}
	public void setPreferredLocations(String preferredLocations) {
		this.preferredLocations = preferredLocations;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(String annualSalary) {
		this.annualSalary = annualSalary;
	}

	public String getCurrentlocation() {
		return currentlocation;
	}

	public void setCurrentlocation(String currentlocation) {
		this.currentlocation = currentlocation;
	}

	@Override
	public String toString() {
		return "NaukriExcelDisplay [id=" + id + ", name=" + name + ", totalExpInYear=" + totalExpInYear + ", location="
				+ location + ", annualSalary=" + annualSalary + ", jobCategory=" + jobCategory + ", keySkill="
				+ keySkill + ", qualification=" + qualification + ", preferredLocations=" + preferredLocations
				+ ", currentlocation=" + currentlocation + ", gender=" + gender + "]";
	}

	
	
}
