package com.eagleSystem.eagleJob;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.RequestCache;
import org.springframework.security.web.savedrequest.SavedRequest;
import org.springframework.stereotype.Service;

import com.eagleSystem.eagleJob.util.Role;
import com.eagleSystem.eagleJob.util.URLMapper;

@Service
public class LoginSuccessHandler implements AuthenticationSuccessHandler {

	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

	private RequestCache requestCache = new HttpSessionRequestCache();

	String URL = "";

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException {
		System.out.println("LoginSucess");
		SavedRequest savedRequest = requestCache.getRequest(request, response);

		URL = request.getRequestURI();

		if (savedRequest == null) {
			clearAuthenticationAttributes(request);
			response.setContentType("application/json");
			Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
			for (GrantedAuthority grantedAuthority : authorities) {
				if (Role.candidate.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
					response.setHeader("Role", "candidate");
					break;
				} else if (Role.recruiter.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
					response.setHeader("Role", "recruiter");
					break;
				} else if (Role.bdm.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
					response.setHeader("Role", "bdm");
					break;
				}
				else if (Role.subadmin.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
					response.setHeader("Role", "subadmin");
					break;
				}
				else if (Role.user.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
					response.setHeader("Role", "user");
					break;
				}
				
				else if (Role.database.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
					response.setHeader("Role", "database");
					break;
				}
				
			}
			return;
		}

		handle(request, response, authentication);
		clearAuthenticationAttributes(request);
	}

	protected void handle(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
			throws IOException {
		String targetUrl = determineTargetUrl(authentication);

		if (response.isCommitted()) {
			System.out.println("Response has already been committed. Unable to redirect to " + targetUrl);
			return;
		}

		redirectStrategy.sendRedirect(request, response, targetUrl);
	}

	/**
	 * Builds the target URL according to the logic defined in the main class
	 * Javadoc.
	 */
	public String determineTargetUrl(Authentication authentication) {
		boolean isCandidate = false;
		boolean isEmployer = false;
		boolean isAdmin = false;
		boolean isbdm = false;
		boolean issubadmin = false;
		boolean isuser = false;
		boolean isdatabase = false;
		
		Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
		for (GrantedAuthority grantedAuthority : authorities) {
			if (Role.candidate.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {

				System.out.println("url check");
				System.out.println("URL :" + URL);

				isCandidate = true;
				break;
			} else if (Role.recruiter.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
				isEmployer = true;
				break;
			} else if (Role.admin.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
				isAdmin = true;
				break;
			}
			else if (Role.bdm.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
				isbdm = true;
				break;
			}
			else if (Role.subadmin.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
				issubadmin = true;
				break;
			}
			else if (Role.user.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
				isuser = true;
				break;
			}
			else if (Role.database.name().equalsIgnoreCase(grantedAuthority.getAuthority())) {
				isdatabase = true;
				break;
			}
			
		}
		if (isCandidate) {
			return URLMapper.CANDIDATE_VIEW_JOBS;
		} else if (isEmployer) {
			return URLMapper.RECRUITER_JOB_POST;
		} else if (isEmployer) {
			return URLMapper.RECRUITER_JOB_POST;
		} else if (isAdmin) {
			return "/adminIndex";
		}
			else if (isbdm) {
				return URLMapper.BDM_BDM_HOME;
		} 

			else if (issubadmin) {
				return URLMapper.SUBADMIN_SUBADMIN_INDEX;
		}
		
			else if (isuser) {
				return "/userhome";
		}
		
			else if (isdatabase) {
				return "/databaseIndex";
		}
		
			else {
			throw new IllegalStateException();
		}
	}

	protected void clearAuthenticationAttributes(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session == null) {
			return;
		}
		session.removeAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);
	}

	public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
		this.redirectStrategy = redirectStrategy;
	}

	protected RedirectStrategy getRedirectStrategy() {
		return redirectStrategy;
	}

	public RequestCache getRequestCache() {
		return requestCache;
	}

	public void setRequestCache(RequestCache requestCache) {
		this.requestCache = requestCache;
	}

}