package com.eagleSystem.eagleJob.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagleSystem.eagleJob.entity.JPUser;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;

public interface JPUserRepository extends JpaRepository<JPUser, Long> {

	JPUser findByUsernameIgnoreCase(String username);
	JPUser findByUsername(String username);
	

}