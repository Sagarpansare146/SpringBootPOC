package com.eagleSystem.eagleJob.controller.subAdmin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.eagleSystem.eagleJob.dao.AccountRepository;
import com.eagleSystem.eagleJob.dao.DBCustomerRepository;
import com.eagleSystem.eagleJob.entity.Account;
import com.eagleSystem.eagleJob.entity.DbCustomerEntity;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.service.subAdmin.SubAdminServiceImpl;

@Controller
public class SubAdminManagementController 
{
	
	@Autowired
	SubAdminServiceImpl subAdminServiceImpl;
	
	@Autowired
	DBCustomerRepository dbCustomerRepository;

	@Autowired
	AccountRepository accountRepository;
	
	
	@GetMapping(value = "/subadminDBAList", produces = {"application/json"})
	public @ResponseBody Map<String, Object> customerReport() throws Exception {
		Map<String, Object> DBCustList= new HashMap<>();
		DBCustList.put("data" , subAdminServiceImpl.getCustomerReport());
		return DBCustList;
		
	}
	
	@GetMapping(value = "/subadminDBAccoun", produces = {"application/json"})
	public @ResponseBody List<DbCustomerEntity> getBDMCustomerReport(@RequestParam("id") Long id) throws Exception
	{
		
		return subAdminServiceImpl.getBDMCustomerReport(id);
	}
	
	@GetMapping(value = "/subadminDBAccou", produces = {"application/json"})
	public @ResponseBody Recruiter recruiterProfile(@RequestParam("id") Long id) throws Exception 
	{
		
		return subAdminServiceImpl.getRecruiterProfile(id);
	}
	

	@GetMapping(value = "/subadminDBAcco", produces = {"application/json"})
	public @ResponseBody boolean changePassword(@RequestParam("id") Long id,
			@RequestParam("role") String role,
			@RequestParam("password") String password) throws Exception {
		
		return subAdminServiceImpl.changePassword(id, role, password);
	}
	
	@GetMapping(value = "/subadminEmpRoleList", produces = {"application/json"})
	public @ResponseBody Map<String, Object> getAllUsersByRole(@RequestParam("role") String role, 
			@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "pageSize",required = false, defaultValue = "100") int pageSize) throws Exception {
		
		return subAdminServiceImpl.getAllUsersByRole(role, page, pageSize);
		
	}            
	
	@GetMapping(value = "/subadminDBAccn", produces = {"application/json"})
	public @ResponseBody Map<String, Object> searchUsersByNameAndRole(@RequestParam("name") String name,
			@RequestParam("role") String role, 
			@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "pageSize",required = false, defaultValue = "100") int pageSize) throws Exception {
		
		return subAdminServiceImpl.searchUsersByNameAndRole(name, role, page, pageSize);
		
	}
	
	@GetMapping(value = "/subadmindisableUser", produces = {"application/json"})
	public @ResponseBody boolean disableUser(@RequestParam("id") Long id,
			@RequestParam("role") String role,
			@RequestParam("status") int status) throws Exception {
		
		return subAdminServiceImpl.disable(id, role, status);
	}
	
	@GetMapping(value = "/subadminBDMList", produces = {"application/json"})
	public @ResponseBody Map<String, Object> getBDMList() throws Exception {
		Map<String, Object> bdmlist= new HashMap<>();
		bdmlist.put("data" , subAdminServiceImpl.getBDMReport());
		return bdmlist;
	}
	
	/*@GetMapping(value = "", produces = {"application/json"})
	public @ResponseBody List<DbCustomerEntity> getDbCustInBDMReport(@RequestParam("id") Long id) throws Exception {
		
		return subAdminServiceImpl.getDbCustInBDMReport(id);
	}*/
	
	@GetMapping(value = "/subadminMonthlyReport", produces = {"application/json"})
	public @ResponseBody Map<String, Object> getDbRecruiterInBDMReport(@RequestParam("id") Long id) throws Exception {
		Map<String, Object> bdmAllReport= new HashMap<>();
		bdmAllReport.put("data" , subAdminServiceImpl.getDbRecruiterInBDMReport(id));
		return bdmAllReport;
		 
	}

	@GetMapping(value = "/subadminAccountDetail", produces = {"application/json"})
	public @ResponseBody Account getAccountDetails(@RequestParam("id") Long id) throws Exception {
		
		return accountRepository.findOne(id);
	}

	
}
