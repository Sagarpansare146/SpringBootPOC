  package com.eagleSystem.eagleJob.util;

import org.springframework.stereotype.Component;

import com.eagleSystem.eagleJob.bussinessObject.CompanyBO;
import com.eagleSystem.eagleJob.bussinessObject.RecruiterBO;
import com.eagleSystem.eagleJob.entity.Company;
import com.eagleSystem.eagleJob.entity.Recruiter;
import com.eagleSystem.eagleJob.valueObject.RecruiterRegistrationRequest;

@Component
public class RecruiterBOPrepareUtil {

	public RecruiterBO prepareRecruiterBO(RecruiterRegistrationRequest request) {
		
		RecruiterBO recruiterBO = new RecruiterBO();
		
		if(!(request.getRecruiterId() == null))
		recruiterBO.setId(request.getRecruiterId());
		recruiterBO.setName(request.getRecruiterName());
		recruiterBO.setDesignation(request.getDesignation());
		recruiterBO.setEmail(request.getEmail());
		recruiterBO.setMobNo(request.getMobNo());
		recruiterBO.setUsername(request.getUsername());
		
		return recruiterBO;
		
	}
	
	public CompanyBO prepareCompanyBO(RecruiterRegistrationRequest request) {
		
		CompanyBO companyBO = new CompanyBO();
		
		companyBO.setName(request.getCompanyName());
		companyBO.setType(request.getCompanyType());
		companyBO.setGSTNO(request.getGSTNO());
		companyBO.setCity(request.getCity());
		companyBO.setState(request.getState());
		companyBO.setAddress(request.getCompanyAddress());
		
		//companyBO.setDiscription();
		
		return companyBO;
	}
	
	public RecruiterBO getRecruiterBO(Recruiter recruiter) {
		
		RecruiterBO recruiterBO = new RecruiterBO();
		
		recruiterBO.setId(recruiter.getId());
		recruiterBO.setName(recruiter.getName());
		recruiterBO.setEmail(recruiter.getEmail());
		recruiterBO.setDesignation(recruiter.getDesignation());
		recruiterBO.setMobNo(recruiter.getMobNo());
		recruiterBO.setUsername(recruiter.getUsername());
		
		return recruiterBO;
	}
	
	public CompanyBO getCompanyBO(Company company ) {

		CompanyBO companyBO = new CompanyBO();
		
		companyBO.setId(company.getId());
		companyBO.setName(company.getName());
		companyBO.setType(company.getType());
		companyBO.setState(company.getState());
		companyBO.setCity(company.getCity());
		companyBO.setAddress(company.getAddress());
		companyBO.setGSTNO(company.getGSTNO());
		
//		companyBO.setDiscription(company.getDiscription());
		
		return companyBO;
		
	}
	
	public RecruiterRegistrationRequest getRecruiterRequestData(RecruiterBO recruiterBO) {
		
		RecruiterRegistrationRequest request = new RecruiterRegistrationRequest();
		
		request.setRecruiterId(recruiterBO.getId());
		request.setRecruiterName(recruiterBO.getName());
		request.setEmail(recruiterBO.getEmail());
		request.setDesignation(recruiterBO.getDesignation());
		request.setMobNo(recruiterBO.getMobNo());
		request.setUsername(recruiterBO.getUsername());
		
		request.setCompanyName(recruiterBO.getCompany().getName());
		request.setCompanyType(recruiterBO.getCompany().getType());
		request.setState(recruiterBO.getCompany().getState());
		request.setCity(recruiterBO.getCompany().getCity());
		request.setCompanyAddress(recruiterBO.getCompany().getAddress());
		request.setGSTNO(recruiterBO.getCompany().getGSTNO());
		
		return request;
	}
	
}
