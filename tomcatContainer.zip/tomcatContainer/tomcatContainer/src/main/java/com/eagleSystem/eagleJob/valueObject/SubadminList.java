package com.eagleSystem.eagleJob.valueObject;

public class SubadminList {
	
	private int id;
	private String name;
	private String location;
	private boolean action;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public boolean isAction() {
		return action;
	}
	public void setAction(boolean action) {
		this.action = action;
	}
	@Override
	public String toString() {
		return "SubadminList [id=" + id + ", name=" + name + ", location=" + location + ", action=" + action + "]";
	}

	
	
}
