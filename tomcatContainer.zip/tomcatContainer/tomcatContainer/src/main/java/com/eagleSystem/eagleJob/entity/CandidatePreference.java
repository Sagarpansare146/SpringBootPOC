package com.eagleSystem.eagleJob.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="CANDIDATE_PREFERENCE")
public class CandidatePreference implements Serializable {
	
	@Id
	@Column(name = "CANDIDATE_ID")
	@GeneratedValue(generator = "foreign_gen")
	@GenericGenerator(name="foreign_gen", strategy = "foreign", parameters=
	@Parameter(name="property", value="candidate"))
	private Long cid;

	@Column(name="KEYSKILL")
	private String keySkill;
	
	@Column(name = "JOBCATEGORY")
	private String jobCategory;
	
	@Column(name = "FUNCTIONALAREA")
	private String functionalArea;
	
	@Column(name="JOBTYPE")
	private String jobType;
	
	@Column(name="LOCATION")
	private String location;
	
	@Column(name="RESUME")
	private String resume;
	
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Candidate candidate;
	
	public CandidatePreference() {
	}

	public Long getCid() {
		return cid;
	}

	public void setCid(Long cpid) {
		this.cid = cpid;
	}

	public String getKeySkill() {
		return keySkill;
	}

	public void setKeySkill(String keySkill) {
		this.keySkill = keySkill;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	
	public String getResume() {
		return resume;
	}

	public void setResume(String resume) {
		this.resume = resume;
	}
	

	public Candidate getCandidate() {
		return candidate;
	}

	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}

	
	public String getJobCategory() {
		return jobCategory;
	}

	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}

	public String getFunctionalArea() {
		return functionalArea;
	}

	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}

	
	
	@Override
	public String toString() {
		return "CandidatePreference [cid=" + cid + ", keySkill=" + keySkill + ", jobCategory=" + jobCategory
				+ ", functionalArea=" + functionalArea + ", jobType=" + jobType + ", location=" + location + ", resume="
				+ resume + ", candidate=" + candidate + "]";
	}
	
}
