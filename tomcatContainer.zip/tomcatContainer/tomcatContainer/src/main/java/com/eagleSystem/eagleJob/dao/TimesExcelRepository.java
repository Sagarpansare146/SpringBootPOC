package com.eagleSystem.eagleJob.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.eagleSystem.eagleJob.entity.ShineExcelRecord;
import com.eagleSystem.eagleJob.entity.TimesExcelRecord;

public interface TimesExcelRepository extends JpaRepository<TimesExcelRecord, Long> {

	List<TimesExcelRecord> findByJobCategory(String jobCategory);
	
	@Query("SELECT DISTINCT p.jobCategory FROM TimesExcelRecord p")
	List<String> findDistinctjobCategory();
	
	
}
