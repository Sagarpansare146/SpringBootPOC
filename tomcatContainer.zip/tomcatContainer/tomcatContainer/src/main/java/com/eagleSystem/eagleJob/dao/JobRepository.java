package com.eagleSystem.eagleJob.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.eagleSystem.eagleJob.entity.JobPost;

public interface JobRepository extends JpaRepository<JobPost, Long> {

	JobPost findById(Long jobId);

	List<JobPost> findByRecruiterIdAndIsDeletedOrderByPostedOnDesc(Long recruiterId,boolean isDeleteds);

	Page<JobPost> findByIsDeletedOrderByPostedOnDesc(boolean isDeleted, Pageable pageable);	
	
	Page<JobPost> findByKeySkillContainingAndJobProfileContainingAndCityContainingAndIsDeleted(String keySkill1, String jobProfile, String location, boolean isDeleted, Pageable pageable);
	
	@Query("SELECT jp FROM JobPost jp WHERE ((((jp.keySkill like %?1% OR jp.keySkill like %?2%) OR (jp.jobProfile like %?1% or jp.jobProfile like %?2% )) And jp.city = ?3) And jp.isDeleted = 0)")
	Page<JobPost> getJobIds1(String keySkill1, String keySkill2, String location, Pageable pageable);

	@Query("SELECT jp FROM JobPost jp WHERE ((((jp.keySkill like %?1% OR jp.keySkill like %?2% OR jp.keySkill like %?3%) OR (jp.jobProfile like %?1% OR jp.jobProfile like %?2%  OR jp.jobProfile like %?3% )) And jp.city = ?4) And jp.isDeleted = 0)")
	Page<JobPost> getJobIds2(String keySkill1, String keySkill2, String keySkill3, String location, Pageable pageable);
	
	@Query(value = "SELECT jp FROM JobPost jp WHERE (((jp.jobCategory like %?1% or jp.jobCategory like %?2%) And (jp.city like %?3% or jp.city like %?4% or jp.city like %?5%)) And jp.isDeleted = 0) ")
	Page<JobPost> getJobforYou(String category, String category1, String topCities1, String topCities2, String topCities3, Pageable pageable);
	
	
	Page<JobPost> findByRecruiterIdOrderByPostedOnDesc(Long recruiterId, Pageable pageRequest);
	
	JobPost findByIdAndRecruiterId(Long jobId, Long recruiterId);
	
	Page<JobPost> findByCityAndIsDeletedOrderByPostedOnDesc(String city, boolean isDeleteds, Pageable pageable);
	
	List<JobPost> findByPostedOnGreaterThan(Date d2);

	List<JobPost> findByRecruiterIdOrderByPostedOnDesc(Long id);
	
	}
