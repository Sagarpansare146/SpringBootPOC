$(document).ready(function() {
    var sds = document.getElementById("dum1");
    if(sds == null){
        alert("You are using a free package.\n You are not allowed to remove the tag.\n");
        $("#selection").hide();
    }
    var sdss = document.getElementById("dumdiv1");
    if(sdss == null){
        alert("You are using a free package.\n You are not allowed to remove the tag.\n");
        $("#selection").hide();
    }
})

var handles = ["SELECT CATEGORY","Acount and Finance","Automotive Auto Skills","Business / Administrative Skills",
               "Engineering Skills","Human Resource / Recruitment Skills","Jobs By IT Skills",
			   "Language / Subject Skills","Media / Entertainment Skills","Marketing Skills","Medical / Healthcare Skills",
			   "Networking Skills","Other Skills"];                           
                                        

$(function() {
  var options = '';
  for (var i = 0; i < handles.length; i++) {
      options += '<option value="' + handles[i] + '">' + handles[i] + '</option>';
  }
  $('#listBox1').html(options);
});
function selct_district1($val)
{
    if($val=='SELECT CATEGORY') {
   var options = '';
  $('#secondlist1').html(options);
  }
 if($val=='Acount and Finance') {
   var andhra = ["Accounting Jobs","Accounting Software Jobs","Accounts Jobs","Asset Management Jobs","Auditing Jobs",
   "Balance Sheet Jobs","Business Analytics Jobs"," Business Awareness Jobs","CA JobsCash Flow Management Jobs",
                                    "CFA Jobs","Corporate Tax Jobs","Cost Analysis Jobs","Cost Center Report Analysis Job",
									"Data Analysis Jobs","Debt Management Jobs","Finance Jobs","Financial Advising Jobs",
									"Financial Analysis Jobs","Financial Concepts Jobs "," Financial Data Jobs",
									"Financial Management Jobs","Financial Modeling Jobs","Financial Planning Jobs",
									"Financial Reporting Jobs","Financial Statement Analysis Jobs","Financial Statements Jobs",
									"Financial Systems Jobs","Forecasting Jobs","GAAP Jobs","IFRS Jobs","Income Tax Jobs",
									"Interest Calculations Jobs","Invoices Jobs","Journal Entry Jobs","Liaisoning Jobs",
									"MS Excel Jobs","Payroll Jobs","Performance Management Jobs",
									"Processing and ReconcilingQuantitative Analysis Jobs","Relationship Management Jobs",
									"SOX Compliance Jobs","Tax Analysis Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < andhra.length; i++) {
      options += '<option value="' + andhra[i] + '">' + andhra[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  if ($val=='Automotive Auto Skills') {
    var ap = ["Brake Repair Jobs ","Car Engine Servicing Jobs","Diesel Engine Repair Jobs ","Engine Repair Jobs ",
	"Jobs in Auto Service Center","Mechanical Jobs ","Petrol Engine Repair Jobs","Car Driver Jobs","Truck Driver Jobs",
	"Vehicle Repair Jobs","Bus Driver Jobs","Vehicle Operating Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < ap.length; i++) {
      options += '<option value="' + ap[i] + '">' + ap[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  if ($val=='Business / Administrative Skills') {
    var assam = ["Administration Jobs","Advertising Jobs","Business Administration Jobs","Business Analysis Jobs",
	"Business Informatics Jobs","Clerical Jobs","Client Relations Jobs"," Contract Management Jobs","Data Analyst Jobs",
	" Environmental Management Jobs"," Event Coordination Jobs ","Event Management Jobs","Hospital Administration Jobs",
	" Hotel Management Jobs","Human Resource Management Jobs","Information Management Jobs","Key Accounts Management Jobs",
	"Knowledge Management Jobs","Legal Familiarity Jobs ","Maintaining Office Records Jobs","Management Jobs",
	"Management Trainee Jobs","Marketing Operations Jobs"," Office Administration Jobs","Office Management Jobs",
	"Oral Communication Jobs","Order Processing Jobs ","Project Management Jobs","Public Management Jobs",
	"Retail Marketing Jobs","Sales Jobs","Securities Jobs","Supply Chain Management Jobs","Wealth Management Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < assam.length; i++) {
      options += '<option value="' + assam[i] + '">' + assam[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  if ($val=='Marketing Skills') {
    var bihar = ["Ad Agency Jobs","Brand Management Jobs","rand Marketing Jobs ","Business Design Jobs",
	"Business Development Jobs","Client Support Jobs","Communication Jobs","Content Writing Jobs","Customer Care Jobs",
	"Customer Relations Jobs","Customer Service Jobs","Digital Marketing Jobs","Direct Marketing Jobs","Fundraising Jobs",
	"Inside Sales Jobs","International Marketing Jobs","Market Research Jobs","Marketing Strategy Jobs","Marketing Jobs",
	"Merchandising Jobs","Mobile Marketing Jobs","National Marketing Jobs","Online Marketing Jobs","Outside Sales Jobs",
	"Price Quoting Jobs","Product Demonstration Jobs","Product Promotion Jobs","Product Research Jobs",
	"Project Coordination Jobs","Promotion Jobs","Public Relations Jobs","Sales Presentations Jobs"," Sales Support Jobs",
	"Sales Tracking Jobs","SEO Jobs","Social Media Marketing Jobs","Social Research Jobs","Technical Support Jobs",
	"Test Marketing Jobs"," Vendor Management Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < bihar.length; i++) {
      options += '<option value="' + bihar[i] + '">' + bihar[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  if ($val=='Engineering Skills') {
    var Chhattisgarh = ["Aeronautical Engineering Jobs","Aerospace Engineering Jobs","Architectural Engineering Jobs",
	"Civil Engineering Jobs","Computer Engineering Jobs","Electrical Engineering Jobs","Electronics Engineering Jobs",
	"Engineering Physics Jobs","Financial Engineering Jobs","Industrial Engineering Jobs","IT Engineering Jobs",
	"Materials Engineering Jobs","Mechanical Engineering Jobs","Medical Engineering Jobs","Metallurgical Engineering Jobs",
	"Petroleum Engineering Jobs","Polymer Fiber Engineering Jobs","Software Engineering Jobs","Textile Engineering Jobs",
	"Wireless Engineering Jobs","Core Java Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < Chhattisgarh.length; i++) {
      options += '<option value="' + Chhattisgarh[i] + '">' + Chhattisgarh[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  if ($val=='Human Resource / Recruitment Skills') {
    var dadra = ["Candidate Search Jobs"," Candidate Sourcing Jobs"," Employee Development Jobs",
	"Labor Relations Specialist Jobs ","Placement Management Jobs"," Talent Acquisition Manager Jobs",
	"Talent Management Systems Jobs","Talent Planning Jobs HR VP Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < dadra.length; i++) {
      options += '<option value="' + dadra[i] + '">' + dadra[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  if ($val=='Jobs By IT Skills') {
    var daman = [".Net Jobs","Adobe Flash Player Jobs","AJAX Jobs","Android Jobs","Apache Tomcat Jobs",
	"Apache Web Server Jobs","ASP.NET Jobs","Assembly Language Jobs","Auto CAD Jobs","Automation Testing Jobs","C Jobs",
	"C# Jobs","C++ Jobs","CAD CAM Jobs","CAE Jobs","Data Structures Jobs","Dhtml Jobs"," DOS Jobs","ERP Jobs",
	"Ethernet Jobs","Firewall Jobs","Flash Jobs","Fortran Jobs","HTML Jobs","iPhone Jobs ","IT Support Jobs","J++ Jobs",
	"J2Ee Jobs","J2Me Jobs","J2Se Jobs","Java Jobs","Java Trainee Jobs","Java2D Jobs","Javascript Jobs","Linux Jobs",
	"Mac Jobs","Manual Testing Jobs","Mobile Application Jobs","Multimedia Jobs","MySQL Jobs","Online Jobs","Oracle Jobs",
	" OS Programming Jobs","Pascal Jobs","PHP Jobs","Python Jobs","SAP Jobs","Selenium Jobs ","SharePoint Jobs",
	"Shell Scripting Jobs","Silverlight Jobs","Simulation Programming Jobs","Software Testing Jobs","SQL Job",
	"sSql Server Jobs"," Sybase Jobs","Symbian C++ Jobs","Symbian Jobs","Syncml Jobs","Talent Acquisition Jobs",
	" Automation TIBCO Jobs"," Unix Jobs"," VB.NET Jobs"," VBScript Jobs"," Visual Basic Jobs","Visual C++ Jobs",
	" Visual Foxpro Jobs","Web Designing Jobs","Web Developer Jobs","Web Server Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < daman.length; i++) {
      options += '<option value="' + daman[i] + '">' + daman[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  if ($val=='Language / Subject Skills') {
    var delhi = ["American Studies Jobs","Applied Arts Jobs","Applied Finance Jobs","Applied Mathematics Jobs",
	"Applied Science Jobs","Art Jobs","Asian Studies Jobs","Biochemistry Jobs","Bioinformatics Jobs",
	"Biomedical Science Jobs","Combined Studies Jobs","Economic Science Jobs","English Grammar jobs",
	"Environmental Science Jobs","Fine Arts Jobs","General Studies Jobs","Geology Jobs","Hispanic Studies Jobs",
	"Integrated Studies Jobs","International Studies Jobs","Liberal Studies Jobs","Professional Studies Jobs",
	"Social Science Jobs","Social Studies Jobs","Studies Jobs","Theological Studies Jobs","Yoga Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < delhi.length; i++) {
      options += '<option value="' + delhi[i] + '">' + delhi[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  if ($val=='Media / Entertainment Skills') {
    var goa = ["3D Max Jobs	","Acting Jobs","Adobe Illustrator Jobs","Adobe Pagemaker Jobs","Adobe Photoshop Jobs",
	"Documentation Jobs","Drama Jobs","Dramatic art Jobs","News Reporting Jobs","Film Editing Jobs","Graphic Design Jobs",
	"Video Editing Jobs","Video production Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < goa.length; i++) {
      options += '<option value="' + goa[i] + '">' + goa[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  if ($val=='Medical / Healthcare Skills') {
    var gujarat = ["Biosystems Jobs","BPT Jobs","Clinical Research Jobs","Dental Medicine Jobs","Dental Science Jobs",
	"Dental Surgery Jobs","Dentist Jobs","Diet Jobs","Health Administration Jobs","Health Informatics Jobs",
	"Homeopathy Jobs","GYM Jobs","MedicineMicrobiology Jobs","PharmacyMLT Jobs","Nursing Jobs","OPD Jobs",
	"Para Medical Jobs","Physiotherapist Jobs","Psychology jobs","Surgeon Jobs","Therapists jobs","Veterinary Jobs",
	"Veterinary Surgeon Jobs"," X-Ray Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < gujarat.length; i++) {
      options += '<option value="' + gujarat[i] + '">' + gujarat[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  if ($val=='Networking Skills') {
    var haryana = ["CDMA Jobs","GSM Jobs","VLSI Jobs","VMS Jobs","VOIP Jobs","VPN Jobs","VSAT Jobs","VSS Clearcase Jobs",
	"VxWorks Jobs","WAN Jobs","WAP Jobs","WCF Jobs","CCNA Jobs","Computer Networking Jobs","Computer Hardware Jobs",
	"Desktop Support Technician Jobs","Fibre Optics Jobs","Embeded Technology Jobs","A Level Jobs","O Level Jobs",
	"CSC ECE Jobs","Web/HTTP Jobs","Network Security Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < haryana.length; i++) {
      options += '<option value="' + haryana[i] + '">' + haryana[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  
  if ($val=='Other Skills') {
    var himachal = ["Abap Jobs","B2B Jobs","Back-Office Operations Jobs","Blackberry Jobs","Building Construction Jobs",
	"Coaching Jobs","Commerce Jobs","Computer Operator Jobs","Engineering Construction Jobs"," Content Writer Jobs",
	"Cooking Jobs","Counseling Jobs","Criminal Justice Jobs","CRM Jobs","CSS Jobs","Dance Jobs","Data Entry Jobs",
	"Data Warehousing Jobs","Db2 JobsDbase Jobs","DCA Jobs","Dcom Jobs","Dhcp Jobs"," DNS Jobs"," Email Marketing Jobs",
	"Embedded C Jobs","Google Adwords Jobs"," Google Analytics Jobs","Hadoop Jobs "," Journalism Jobs",
	"Nuclear Engineer Jobs","Nutrition Jobs","Photography Jobs","SAP Hr Jobs","SAP Retail Jobs","SAP Security Jobs",
	"SAP Sem Jobs","SAP Srm Jobs","Social Welfare Jobs","Tally Jobs","Textile Designing Jobs"];
   $(function() {
  var options = '';
  for (var i = 0; i < himachal.length; i++) {
      options += '<option value="' + himachal[i] + '">' + himachal[i] + '</option>';
  }
  $('#secondlist1').html(options);
  });
  }
  
  
}