// Events
$('.dropdown-container')
	.on('click', '.a3', function() {
    	$('.exp').toggle();
	})
	.on('input', '.experience', function() {
    	var target = $(this);
    	var search = target.val().toLowerCase();
    
    	if (!search) {
            $('li').show();
            return false;
        }
    
    	$('li').each(function() {
        	var text = $(this).text().toLowerCase();
            var match = text.indexOf(search) > -1;
            $(this).toggle(match);
        });
	})
	.on('change', '[type="checkbox"]', function() {
    	var numChecked = $('[type="checkbox"]:checked').length;
    	$('.quantity3').text(numChecked || 'Any');
	});

// JSON of States for demo purposes
var usExp = [
    { name: 'Fresher', abbreviation: 'AL'},
    { name: '0 to 1 Year', abbreviation: 'AK'},
    { name: '1 to 2 Year ', abbreviation: 'AS'},
    { name: '2 to 3 Year', abbreviation: 'AZ'},
    { name: '3 to 4 Year', abbreviation: 'AR'},
    { name: '4 to 5 Year', abbreviation: 'CA'},
    { name: '5 to 6 Year', abbreviation: 'CO'},
    { name: '6 to 7 Year', abbreviation: 'CT'},
    { name: '7 to 8 Year', abbreviation: 'DE'},
    { name: '8 to 9 Year', abbreviation: 'DC'},
    { name: '9 to 10 Year', abbreviation: 'FM'},
    { name: '10 to 11 Year', abbreviation: 'FL'},
    { name: '11 to 12 Year', abbreviation: 'GA'},
    { name: '12 to 13 Year', abbreviation: 'GU'},
    { name: '13 to 14 Year', abbreviation: 'HI'},
    { name: '14 to 15 Year', abbreviation: 'ID'},
    { name: '15 to 16 Year', abbreviation: 'IL'},
    { name: '16 to 17 Year', abbreviation: 'IN'},
    { name: '17 to 18 Year', abbreviation: 'IA'},
    { name: '18 to 19 Year', abbreviation: 'KS'},
    { name: '19 to 20 Year', abbreviation: 'KY'},
    { name: '20 Year', abbreviation: 'LA'}
   
];

// <li> template
var stateTemplate2 = _.template(
    '<li>' +
    	'<input name="<%= abbreviation %>" type="checkbox">' +
    	'<label for="<%= abbreviation %>"><%= capName2 %></label>' +
    '</li>'
);

// Populate list with states
_.each(usExp, function(s) {
    s.capName2 = _.startCase(s.name.toLowerCase());
    $('ul').append(stateTemplate2(s));
});