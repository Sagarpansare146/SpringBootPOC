// Events
$('.dropdown-container')
	.on('click', '.a2', function() {
    	$('.salary').toggle();
	})
	.on('input', '.salary1', function() {
    	var target = $(this);
    	var search = target.val().toLowerCase();
    
    	if (!search) {
            $('li').show();
            return false;
        }
    
    	$('li').each(function() {
        	var text = $(this).text().toLowerCase();
            var match = text.indexOf(search) > -1;
            $(this).toggle(match);
        });
	})
	.on('change', '[type="checkbox"]', function() {
    	var numChecked = $('[type="checkbox"]:checked').length;
    	$('.quantity2').text(numChecked || 'Any');
	});

// JSON of States for demo purposes
var usSalary = [
   
   
    { name: 'up to 2 Lakh', abbreviation: 'upto2'},
    { name: '3 To 5 Lakh', abbreviation: '3To5'},
    { name: '6 To 8 Lakh', abbreviation: '6To8'},
    { name: '9 To 12 Lakh', abbreviation: '9To12'},
    { name: '13 To 16 Lakh', abbreviation: '13To16' },
    { name: '17 To 25 Lakh', abbreviation: '17To25'},
    { name: '>25 Lakh', abbreviation: '25' }
];

// <li> template
var stateTemplate1 = _.template(
    '<li>' +
    	'<input name="<%= abbreviation %>" type="checkbox">' +
    	'<label for="<%= abbreviation %>"><%= capName1 %></label>' +
    '</li>'
);

// Populate list with states
_.each(usSalary, function(s) {
    s.capName1 = _.startCase(s.name.toLowerCase());
    $('ul').append(stateTemplate1(s));
});