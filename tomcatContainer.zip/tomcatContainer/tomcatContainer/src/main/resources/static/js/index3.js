// Events
$('.dropdown-container')
	.on('click', '.a4', function() {
    	$('.industry').toggle();
	})
	.on('input', '.industry1', function() {
    	var target = $(this);
    	var search = target.val().toLowerCase();
    
    	if (!search) {
            $('li').show();
            return false;
        }
    
    	$('li').each(function() {
        	var text = $(this).text().toLowerCase();
            var match = text.indexOf(search) > -1;
            $(this).toggle(match);
        });
	})
	.on('change', '[type="checkbox"]', function() {
    	var numChecked = $('[type="checkbox"]:checked').length;
    	$('.quantity4').text(numChecked || 'Any');
	});

// JSON of States for demo purposes
var usind = [
   
   
	{ abbreviation: 'accounting'    , name :'Accounting , Finance,Banking ,Tax'},
	{ abbreviation: 'advertising'    , name :'Advertising ,PR,MR,Event Management'},
	{ abbreviation: 'agriculture'    , name :'Agriculture ,Dairy,Forestry,Fishing'},
	{ abbreviation: 'aviation'    , name :'Aviation ,Aerospace'},
	{ abbreviation: 'architecture'    , name :'Architecture , Interior Design'},
	{ abbreviation: 'beverages'    , name :'Beverages ,Liquor,FMCG'},
	{ abbreviation: 'bpo'    , name :'BPO ,Call Centre ,KPO,Analytics'},
	{ abbreviation: 'construction'    , name :'Construction ,Site & Engineering,Cement ,Metals'},
	{ abbreviation: 'civil'    , name :'Civil Construction Design  Engineering'},
	{ abbreviation: 'consultancy'    , name :'Consultancy ,placement'},
	{ abbreviation: 'courier'    , name :'Courier ,Transportation, Freight , Warehousing'},
	{ abbreviation: 'education'    , name :'Education ,Teaching ,Training,Class'},
	{ abbreviation: 'export'    , name :'Export -Import,supply chain,Warehouse,Store,Dispatch'},
	{ abbreviation: 'government'    , name :'Government , PSI,STC,STI,MPSC,UPSC. '},
	{ abbreviation: 'hr'    , name :'HR Recruitment,Executive,Generalist,admin'},
	{ abbreviation: 'hardware'    , name :'IT Software - Hardware and Networking  Engineer/System Admistrator'},
	{ abbreviation: 'software'    , name :'IT Software - Software Developer'},
	{ abbreviation: 'testing'    , name :'IT Software - Testing ,QC'},
	{ abbreviation: 'design'    , name :'Manufacture Design  Engineering '},
	{ abbreviation: 'electronics'    , name :'Manufacture Electronics ,Electrical'},
	{ abbreviation: 'food'    , name :'Manufacture Food Processing,Food & Packaged Food'},
	{ abbreviation: 'instrumenatation'    , name :'Manufacture Instrumenatation /Automation'},
	{ abbreviation: 'mechanical'    , name :'Manufacture Mechanical ,Automobile'},
	{ abbreviation: 'production'    , name :'Manufacture Production ,Quality,maintaince'},
	{ abbreviation: 'equipment'    , name :'Manufacture Equipment ,PLC,SCADA, Automation'},
	{ abbreviation: 'chemical'    , name :'Manufacture Chemical ,Oil and Gas , Energy , Power ,PetroChemical '},
	{ abbreviation: 'pharma'    , name :'Manufacture Pharma ,chemist, Biotech, Microbiology,Pharmaceutical'},
	{ abbreviation: 'real'    , name :'Real Estate,Property'},
	{ abbreviation: 'scientist'    , name :'R&D ,Scientist'},
	{ abbreviation: 'sales'    , name :'Sales ,Marketing,Busness Development'},
	{ abbreviation: 'service'    , name :'Service ,Installation,Repair'},
	{ abbreviation: 'telecom'    , name :'Telecom ,ISP'},
	{ abbreviation: 'textiles'    , name :'Textiles ,Garments,Accessories,fashion'},
	{ abbreviation: 'travel'    , name :'Travel ,Hotels,Restaurants,Airlines,Railways'},
	{ abbreviation: 'training'    , name :'Training & Development'},
	{ abbreviation: 'other'    , name :'Other'}

];

// <li> template
var stateTemplate3 = _.template(
    '<li>' +
    	'<input name="<%= abbreviation %>" type="checkbox">' +
    	'<label for="<%= abbreviation %>"><%= capName3 %></label>' +
    '</li>'
);

// Populate list with states
_.each(usind, function(s) {
    s.capName3 = _.startCase(s.name.toLowerCase());
    $('ul').append(stateTemplate3(s));
});