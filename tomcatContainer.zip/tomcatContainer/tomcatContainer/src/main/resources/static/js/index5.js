// Events
$('.dropdown-container')
	.on('click', '.a6', function() {
    	$('.Date').toggle();
	})
	.on('input', '.Date1', function() {
    	var target = $(this);
    	var search = target.val().toLowerCase();
    
    	if (!search) {
            $('li').show();
            return false;
        }
    
    	$('li').each(function() {
        	var text = $(this).text().toLowerCase();
            var match = text.indexOf(search) > -1;
            $(this).toggle(match);
        });
	})
	.on('change', '[type="checkbox"]', function() {
    	var numChecked = $('[type="checkbox"]:checked').length;
    	$('.quantity6').text(numChecked || 'Any');
	});

// JSON of States for demo purposes
var usQuali = [
   
   
	{ abbreviation: 'Below' , name :'10+2 or Below'}
	
	
];

// <li> template
var stateTemplate4 = _.template4(
    '<li>' +
    	'<input name="<%= abbreviation %>" type="checkbox">' +
    	'<label for="<%= abbreviation %>"><%= capName4 %></label>' +
    '</li>'
);

// Populate list with states
_.each(usQuali, function(s) {
    s.capName4 = _.startCase(s.name.toLowerCase());
    $('ul').append(stateTemplate4(s));
});