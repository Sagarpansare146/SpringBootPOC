// Events
$('.dropdown-container')
	.on('click', '.a1', function() {
    	$('.location').toggle();
	})
	.on('input', '.loc', function() {
    	var target = $(this);
    	var search = target.val().toLowerCase();
    
    	if (!search) {
            $('li').show();
            return false;
        }
    
    	$('li').each(function() {
        	var text = $(this).text().toLowerCase();
            var match = text.indexOf(search) > -1;
            $(this).toggle(match);
        });
	})
	.on('change', '[type="checkbox"]', function() {
    	var numChecked = $('[type="checkbox"]:checked').length;
    	$('.quantity1').text(numChecked || 'Any');
	});

// JSON of States for demo purposes
var usCity = [
	 { name: 'Agra' , abbreviation: 'Agra'},
	 { name: 'Ahmedabad' , abbreviation: 'Ahmedabad'},
	 { name: 'Allahabad' , abbreviation: 'Allahabad'},
	 { name: 'Amritsar' , abbreviation: 'Amritsar'},
	 { name: 'Anand' , abbreviation: 'Anand'},
	 { name: 'Aurangabad' , abbreviation: 'Aurangabad'},
	 { name: 'Bangalore' , abbreviation: 'Bangalore'},
	 { name: 'Bhopal' , abbreviation: 'Bhopal'},
	 { name: 'Chennai' , abbreviation: 'Chennai'},
	 { name: 'Coimbatore' , abbreviation: 'Coimbatore'},
	 { name: 'Delhi' , abbreviation: 'Delhi'},
	 { name: 'Dhanbad' , abbreviation: 'Dhanbad'},
	 { name: 'Faridabad' , abbreviation: 'Faridabad'},
	 { name: 'Ghaziabad' , abbreviation: 'Ghaziabad'},
	 { name: 'Gurugram' , abbreviation: 'Gurugram'},
	 { name: 'Gwalior' , abbreviation: 'Gwalior'},
	 { name: 'Hisar' , abbreviation: 'Hisar'},
	 { name: 'Howrah' , abbreviation: 'Howrah'},
	 { name: 'Hyderabad' , abbreviation: 'Hyderabad'},
	 { name: 'Indore' , abbreviation: 'Indore'},
	 { name: 'Jabalpur' , abbreviation: 'Jabalpur'},
	 { name: 'Jaipur' , abbreviation: 'Jaipur'},
	 { name: 'Jodhpur' , abbreviation: 'Jodhpur'},
	 { name: 'Kalyan-Dombivali' , abbreviation: 'Kalyan-Dombivali'},
	 { name: 'Kanpur' , abbreviation: 'Kanpur'},
	 { name: 'Kolkata' , abbreviation: 'Kolkata'},
	 { name: 'Kota' , abbreviation: 'Kota'},
	 { name: 'Lucknow' , abbreviation: 'Lucknow'},
	 { name: 'Ludhiana' , abbreviation: 'Ludhiana'},
	 { name: 'Madurai' , abbreviation: 'Madurai'},
	 { name: 'Meerut' , abbreviation: 'Meerut'},
	 { name: 'Motihari' , abbreviation: 'Motihari'},
	 { name: 'Mumbai' , abbreviation:  'Mumbai'},
	 { name: 'Nagpur' , abbreviation:'Nagpur'},
	 { name: 'Nashik' , abbreviation: 'Nashik'},
	 { name: 'Navi Mumbai' , abbreviation: 'Navi Mumbai'},
	 { name: 'Patna' , abbreviation: 'Patna'},
	 { name: 'Pimpri-Chinchwad' , abbreviation: 'Pimpri-Chinchwad'},
	 { name: 'Pune' , abbreviation: 'Pune'},
	 { name: 'Raipur' , abbreviation: 'Raipur'},
	 { name: 'Rajkot' , abbreviation: 'Rajkot'},
	 { name: 'Ranchi' , abbreviation: 'Ranchi'},
	 { name: 'Srinagar' , abbreviation: 'Srinagar'},
	 { name: 'Surat' , abbreviation: 'Surat'},
	 { name: 'Thane' , abbreviation: 'Thane'},
	 { name: 'Vadodara' , abbreviation: 'Vadodara'},
	 { name: 'Varanasi' , abbreviation: 'Varanasi'},
	 { name: 'Vasai-Virar' , abbreviation: 'Vasai-Virar'},
	 { name: 'Vijayawada' , abbreviation: 'Vijayawada'},
	 { name: 'Visakhapatnam' , abbreviation: 'Visakhapatnam'}

];


// <li> template
var stateTemplate = _.template(
    '<li>' +
    	'<input name="<%= abbreviation %>" type="checkbox">' +
    	'<label for="<%= abbreviation %>"><%= capName %></label>' +
    '</li>'
);


// Populate list with states
_.each(usCity, function(s) {
    s.capName = _.startCase(s.name.toLowerCase());
    $('ul').append(stateTemplate(s));
    /*if($("ul").length<50)
    {
    	$('ul').append(stateTemplate(s));
    }else{
    	break;
    }*/

});



