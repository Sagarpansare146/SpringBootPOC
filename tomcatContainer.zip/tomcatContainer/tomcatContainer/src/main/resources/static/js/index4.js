// Events
$('.dropdown-container')
	.on('click', '.a5', function() {
    	$('.qualification').toggle();
	})
	.on('input', '.qualification1', function() {
    	var target = $(this);
    	var search = target.val().toLowerCase();
    
    	if (!search) {
            $('li').show();
            return false;
        }
    
    	$('li').each(function() {
        	var text = $(this).text().toLowerCase();
            var match = text.indexOf(search) > -1;
            $(this).toggle(match);
        });
	})
	.on('change', '[type="checkbox"]', function() {
    	var numChecked = $('[type="checkbox"]:checked').length;
    	$('.quantity').text(numChecked || 'Any');
	});

// JSON of States for demo purposes
var usQuali = [
   
   
	{ abbreviation: 'Below' , name :'10+2 or Below'}, 
	{ abbreviation: 'BArch' , name :'B.Arch'},
	{ abbreviation: 'BBABMS' , name :'BBA/BMS'},
	{ abbreviation: 'BEd' , name :'B.Ed '},
	{ abbreviation: 'BPharma' , name :'B.Pharma '}, 
	{ abbreviation: 'BSc' , name :'B.Sc'}, 
	{ abbreviation: 'BEBTech' , name :'BE/B.Tech'}, 
	{ abbreviation: 'BA' , name :'BA'}, 
	{ abbreviation: 'BCA' , name :'BCA'}, 
	{ abbreviation: 'Bcom' , name :'Bcom '},
	{ abbreviation: 'BDS' , name :'BDS'}, 
	{ abbreviation: 'BHM' , name :'BHM'},
	{ abbreviation: 'BVSC' , name :'BVSC'}, 
	{ abbreviation: 'CA' , name :'CA'},
	{ abbreviation: 'CFA' , name :'CFA'},
	{ abbreviation: 'CS' , name :'CS'},
	{ abbreviation: 'CWACMA' , name :'CWA/CMA'},
	{ abbreviation: 'Diploma' , name :'Diploma'},
	{ abbreviation: 'IntegratedPG' , name :'Integrated PG'},
	{ abbreviation: 'LLM' , name :'LLM'},
	{ abbreviation: 'LLB' , name :'LLB'},
	{ abbreviation: 'MA' , name :'MA'},
	{ abbreviation: 'MCA' , name :'MCA'},
	{ abbreviation: 'Mcom' , name :'Mcom'},
	{ abbreviation: 'MEd' , name :'M.Ed '},
	{ abbreviation: 'MPharm' , name :'M.Pharma'},
	{ abbreviation: 'Msc' , name :'M.Sc '},
	{ abbreviation: 'Mtech' , name :'M.Tech'},
	{ abbreviation: 'MBA' , name :'MBA/PGDM'},
	{ abbreviation: 'MBSS' , name :'MBSS '},
	{ abbreviation: 'MDS' , name :'MDS '},
	{ abbreviation: 'MDMS' , name :'MD/MS '},
	{ abbreviation: 'MMH' , name :'MMH '},
	{ abbreviation: 'MPhill' , name :'MPhill'},
	{ abbreviation: 'MVSC' , name :'MVSC'},
	{ abbreviation: 'PGDiploma' , name :'PG Diploma'}, 
	{ abbreviation: 'PHDoctorate' , name :'Ph.D/Doctorate '},
	{ abbreviation: 'other' , name :'other'}

];

// <li> template
var stateTemplate4 = _.template4(
    '<li>' +
    	'<input name="<%= abbreviation %>" type="checkbox">' +
    	'<label for="<%= abbreviation %>"><%= capName4 %></label>' +
    '</li>'
);

// Populate list with states
_.each(usQuali, function(s) {
    s.capName4 = _.startCase(s.name.toLowerCase());
    $('ul').append(stateTemplate4(s));
});